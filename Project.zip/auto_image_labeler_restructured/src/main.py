from flask import Flask
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

def create_app():
    """Create and configure the Flask application."""
    app = Flask(__name__)
    app.secret_key = os.urandom(24)
    
    # Register blueprints
    from src.routes.main import main_bp
    app.register_blueprint(main_bp)
    
    # Create upload directory if it doesn't exist
    os.makedirs('/tmp/uploads', exist_ok=True)
    
    return app

app = create_app()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
