import json
import os
import numpy as np
from datetime import datetime
from pycocotools import mask as mask_util

from src.formatters.base import BaseFormatter

class COCOFormatter(BaseFormatter):
    """
    Formatter for converting model predictions to COCO JSON format.
    """
    
    def __init__(self):
        """
        Initialize the COCO formatter.
        """
        super().__init__()
        self.dataset = {
            "info": {
                "description": "Dataset labeled with Automated Image Labeling System",
                "url": "",
                "version": "1.0",
                "year": datetime.now().year,
                "contributor": "Automated Image Labeling System",
                "date_created": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            "licenses": [
                {
                    "id": 1,
                    "name": "Unknown",
                    "url": ""
                }
            ],
            "images": [],
            "annotations": [],
            "categories": []
        }
        self.image_id = 0
        self.annotation_id = 0
        self.categories = {}
    
    def _ensure_category(self, class_id, class_name):
        """
        Ensure the category exists in the dataset.
        
        Args:
            class_id: Class ID
            class_name: Class name
            
        Returns:
            Category ID
        """
        if class_name not in self.categories:
            category_id = len(self.categories) + 1
            self.categories[class_name] = category_id
            self.dataset["categories"].append({
                "id": category_id,
                "name": class_name,
                "supercategory": "object"
            })
        return self.categories[class_name]
    
    def format_semantic_segmentation(self, predictions, image_info):
        """
        Format semantic segmentation predictions to COCO format.
        
        Args:
            predictions: Semantic segmentation predictions
            image_info: Image metadata
            
        Returns:
            List of COCO annotations
        """
        mask = predictions['mask']
        classes = predictions['classes']
        class_names = predictions['class_names']
        
        # Add image to dataset
        self.image_id += 1
        self.dataset["images"].append({
            "id": self.image_id,
            "license": 1,
            "file_name": image_info["filename"],
            "height": image_info["height"],
            "width": image_info["width"],
            "date_captured": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        
        annotations = []
        
        # Process each class in the mask
        for i, class_id in enumerate(classes):
            # Ensure category exists
            category_id = self._ensure_category(class_id, class_names[i])
            
            # Create binary mask for this class
            binary_mask = (mask == class_id).astype(np.uint8)
            
            # Skip if no pixels for this class
            if np.sum(binary_mask) == 0:
                continue
            
            # Encode mask
            encoded_mask = mask_util.encode(np.asfortranarray(binary_mask))
            encoded_mask['counts'] = encoded_mask['counts'].decode('utf-8')
            
            # Calculate area and bounding box
            area = float(np.sum(binary_mask))
            bbox = mask_util.toBbox(encoded_mask).tolist()
            
            # Create annotation
            self.annotation_id += 1
            annotation = {
                "id": self.annotation_id,
                "image_id": self.image_id,
                "category_id": category_id,
                "segmentation": encoded_mask,
                "area": area,
                "bbox": bbox,
                "iscrowd": 0
            }
            
            annotations.append(annotation)
            self.dataset["annotations"].append(annotation)
        
        return annotations
    
    def format_instance_segmentation(self, predictions, image_info):
        """
        Format instance segmentation predictions to COCO format.
        
        Args:
            predictions: Instance segmentation predictions
            image_info: Image metadata
            
        Returns:
            List of COCO annotations
        """
        boxes = predictions['boxes']
        masks = predictions['masks']
        labels = predictions['labels']
        scores = predictions['scores']
        class_names = predictions['class_names']
        
        # Add image to dataset
        self.image_id += 1
        self.dataset["images"].append({
            "id": self.image_id,
            "license": 1,
            "file_name": image_info["filename"],
            "height": image_info["height"],
            "width": image_info["width"],
            "date_captured": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        
        annotations = []
        
        # Process each instance
        for i in range(len(boxes)):
            # Ensure category exists
            category_id = self._ensure_category(labels[i], class_names[i])
            
            # Get mask for this instance
            binary_mask = masks[i].astype(np.uint8)
            
            # Skip if no pixels for this instance
            if np.sum(binary_mask) == 0:
                continue
            
            # Encode mask
            encoded_mask = mask_util.encode(np.asfortranarray(binary_mask))
            encoded_mask['counts'] = encoded_mask['counts'].decode('utf-8')
            
            # Calculate area
            area = float(np.sum(binary_mask))
            
            # Create annotation
            self.annotation_id += 1
            annotation = {
                "id": self.annotation_id,
                "image_id": self.image_id,
                "category_id": category_id,
                "segmentation": encoded_mask,
                "area": area,
                "bbox": boxes[i],
                "iscrowd": 0,
                "score": scores[i]
            }
            
            annotations.append(annotation)
            self.dataset["annotations"].append(annotation)
        
        return annotations
    
    def format_bounding_box(self, predictions, image_info):
        """
        Format bounding box predictions to COCO format.
        
        Args:
            predictions: Bounding box predictions
            image_info: Image metadata
            
        Returns:
            List of COCO annotations
        """
        boxes = predictions['boxes']
        labels = predictions['labels']
        scores = predictions['scores']
        class_names = predictions['class_names']
        
        # Add image to dataset
        self.image_id += 1
        self.dataset["images"].append({
            "id": self.image_id,
            "license": 1,
            "file_name": image_info["filename"],
            "height": image_info["height"],
            "width": image_info["width"],
            "date_captured": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        
        annotations = []
        
        # Process each bounding box
        for i in range(len(boxes)):
            # Ensure category exists
            category_id = self._ensure_category(labels[i], class_names[i])
            
            # Calculate area
            box = boxes[i]
            area = (box[2] - box[0]) * (box[3] - box[1])
            
            # Create annotation
            self.annotation_id += 1
            annotation = {
                "id": self.annotation_id,
                "image_id": self.image_id,
                "category_id": category_id,
                "bbox": box,
                "area": area,
                "iscrowd": 0,
                "score": scores[i]
            }
            
            annotations.append(annotation)
            self.dataset["annotations"].append(annotation)
        
        return annotations
    
    def format(self, predictions, image_info):
        """
        Convert model predictions to COCO format.
        
        Args:
            predictions: Model prediction results
            image_info: Dictionary containing image metadata
                        (filename, width, height, etc.)
            
        Returns:
            Formatted annotations in COCO format
        """
        prediction_type = predictions.get('type', '')
        
        if prediction_type == 'semantic_segmentation':
            return self.format_semantic_segmentation(predictions, image_info)
        elif prediction_type == 'instance_segmentation':
            return self.format_instance_segmentation(predictions, image_info)
        elif prediction_type == 'bounding_box':
            return self.format_bounding_box(predictions, image_info)
        else:
            raise ValueError(f"Unsupported prediction type: {prediction_type}")
    
    def save(self, annotations, output_dir):
        """
        Save the COCO annotations to the specified output directory.
        
        Args:
            annotations: Formatted annotations (not used, as we use self.dataset)
            output_dir: Directory to save the annotations
            
        Returns:
            Path to the saved annotations file
        """
        os.makedirs(output_dir, exist_ok=True)
        output_file = os.path.join(output_dir, 'instances.json')
        
        with open(output_file, 'w') as f:
            json.dump(self.dataset, f)
        
        return output_file
