from abc import ABC, abstractmethod
import torch
import numpy as np

class BaseInference(ABC):
    """
    Base abstract class for all inference models.
    Defines the common interface that all inference models must implement.
    """
    
    def __init__(self, device=None):
        """
        Initialize the inference model.
        
        Args:
            device: The device to run inference on ('cuda' or 'cpu').
                   If None, will use CUDA if available.
        """
        if device is None:
            self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        else:
            self.device = device
        
        self.model = None
        self.class_names = None
    
    @abstractmethod
    def load_model(self):
        """
        Load the pre-trained model.
        Must be implemented by subclasses.
        """
        pass
    
    @abstractmethod
    def preprocess(self, image):
        """
        Preprocess the input image for the model.
        
        Args:
            image: Input image (numpy array or PIL Image)
            
        Returns:
            Preprocessed image tensor
        """
        pass
    
    @abstractmethod
    def predict(self, image):
        """
        Run inference on the input image.
        
        Args:
            image: Input image (numpy array or PIL Image)
            
        Returns:
            Prediction results in a standardized format
        """
        pass
    
    @abstractmethod
    def postprocess(self, outputs):
        """
        Process the raw model outputs into a standardized format.
        
        Args:
            outputs: Raw model outputs
            
        Returns:
            Processed outputs in a standardized format
        """
        pass
    
    def __call__(self, image):
        """
        Convenience method to run the full inference pipeline.
        
        Args:
            image: Input image (numpy array or PIL Image)
            
        Returns:
            Processed prediction results
        """
        if self.model is None:
            self.load_model()
        
        preprocessed = self.preprocess(image)
        outputs = self.predict(preprocessed)
        results = self.postprocess(outputs)
        
        return results
