import torch
import torchvision
from torchvision.models.detection import fasterrcnn_resnet50_fpn
import numpy as np
from PIL import Image
import torchvision.transforms as transforms

from src.inference.base import BaseInference

class BoundingBoxDetection(BaseInference):
    """
    Bounding box detection inference using Faster R-CNN model.
    """
    
    def __init__(self, device=None, score_threshold=0.7):
        """
        Initialize the bounding box detection model.
        
        Args:
            device: The device to run inference on ('cuda' or 'cpu').
                   If None, will use CUDA if available.
            score_threshold: Confidence threshold for detections.
        """
        super().__init__(device)
        self.score_threshold = score_threshold
        # COCO classes that Faster R-CNN was trained on
        self.class_names = [
            '__background__', 'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus',
            'train', 'truck', 'boat', 'traffic light', 'fire hydrant', 'N/A', 'stop sign',
            'parking meter', 'bench', 'bird', 'cat', 'dog', 'horse', 'sheep', 'cow',
            'elephant', 'bear', 'zebra', 'giraffe', 'N/A', 'backpack', 'umbrella', 'N/A', 'N/A',
            'handbag', 'tie', 'suitcase', 'frisbee', 'skis', 'snowboard', 'sports ball',
            'kite', 'baseball bat', 'baseball glove', 'skateboard', 'surfboard', 'tennis racket',
            'bottle', 'N/A', 'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl',
            'banana', 'apple', 'sandwich', 'orange', 'broccoli', 'carrot', 'hot dog', 'pizza',
            'donut', 'cake', 'chair', 'couch', 'potted plant', 'bed', 'N/A', 'dining table',
            'N/A', 'N/A', 'toilet', 'N/A', 'tv', 'laptop', 'mouse', 'remote', 'keyboard', 'cell phone',
            'microwave', 'oven', 'toaster', 'sink', 'refrigerator', 'N/A', 'book',
            'clock', 'vase', 'scissors', 'teddy bear', 'hair drier', 'toothbrush'
        ]
    
    def load_model(self):
        """
        Load the pre-trained Faster R-CNN model.
        """
        self.model = fasterrcnn_resnet50_fpn(pretrained=True)
        self.model.eval()
        self.model.to(self.device)
    
    def preprocess(self, image):
        """
        Preprocess the input image for the model.
        
        Args:
            image: Input image (numpy array or PIL Image)
            
        Returns:
            Preprocessed image tensor
        """
        if isinstance(image, np.ndarray):
            image = Image.fromarray(image)
        
        # Ensure the image is in RGB format
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        # Convert to tensor (Faster R-CNN doesn't need normalization)
        transform = transforms.ToTensor()
        input_tensor = transform(image)
        
        # Add batch dimension
        input_batch = input_tensor.unsqueeze(0).to(self.device)
        
        return input_batch
    
    def predict(self, input_batch):
        """
        Run inference on the preprocessed input.
        
        Args:
            input_batch: Preprocessed input tensor
            
        Returns:
            Raw model outputs
        """
        with torch.no_grad():
            outputs = self.model(input_batch)
        
        return outputs
    
    def postprocess(self, outputs):
        """
        Process the raw model outputs into a standardized format.
        
        Args:
            outputs: Raw model outputs (list of dictionaries)
            
        Returns:
            Dictionary containing:
                - 'boxes': List of bounding boxes [x1, y1, x2, y2]
                - 'labels': List of class indices
                - 'scores': List of confidence scores
                - 'class_names': List of class names
        """
        # Extract the first (and only) batch item
        output = outputs[0]
        
        # Get tensors from output dictionary
        boxes = output['boxes'].cpu().numpy()
        labels = output['labels'].cpu().numpy()
        scores = output['scores'].cpu().numpy()
        
        # Filter by confidence threshold
        keep = scores >= self.score_threshold
        boxes = boxes[keep]
        labels = labels[keep]
        scores = scores[keep]
        
        # Get class names for the detected objects
        class_names = [self.class_names[label] for label in labels]
        
        return {
            'boxes': boxes.tolist(),
            'labels': labels.tolist(),
            'scores': scores.tolist(),
            'class_names': class_names,
            'type': 'bounding_box'
        }
