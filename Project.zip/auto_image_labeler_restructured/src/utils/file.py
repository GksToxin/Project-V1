import os
import shutil
import uuid
import zipfile
from datetime import datetime

def create_temp_dir():
    """
    Create a temporary directory for storing uploaded images and results.
    
    Returns:
        Path to the temporary directory
    """
    temp_dir = os.path.join('/tmp', f'auto_labeler_{uuid.uuid4().hex}')
    os.makedirs(temp_dir, exist_ok=True)
    return temp_dir

def create_dataset_structure(base_dir):
    """
    Create the standard dataset directory structure.
    
    Args:
        base_dir: Base directory for the dataset
        
    Returns:
        Dictionary containing paths to the dataset directories
    """
    # Create main directories
    images_dir = os.path.join(base_dir, 'images')
    annotations_dir = os.path.join(base_dir, 'annotations')
    
    os.makedirs(images_dir, exist_ok=True)
    os.makedirs(annotations_dir, exist_ok=True)
    
    return {
        'base_dir': base_dir,
        'images_dir': images_dir,
        'annotations_dir': annotations_dir
    }

def save_uploaded_images(uploaded_files, images_dir):
    """
    Save uploaded image files to the images directory.
    
    Args:
        uploaded_files: List of uploaded file objects
        images_dir: Directory to save the images
        
    Returns:
        List of saved image paths
    """
    saved_paths = []
    
    for uploaded_file in uploaded_files:
        # Generate a safe filename
        original_filename = uploaded_file.filename
        filename = os.path.basename(original_filename)
        
        # Save the file
        save_path = os.path.join(images_dir, filename)
        uploaded_file.save(save_path)
        saved_paths.append(save_path)
    
    return saved_paths

def create_zip_archive(source_dir, output_path=None):
    """
    Create a ZIP archive of the specified directory.
    
    Args:
        source_dir: Directory to archive
        output_path: Path for the output ZIP file (optional)
        
    Returns:
        Path to the created ZIP file
    """
    if output_path is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = f"{source_dir}_{timestamp}.zip"
    
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(source_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, os.path.dirname(source_dir))
                zipf.write(file_path, arcname)
    
    return output_path

def cleanup_temp_dir(temp_dir):
    """
    Clean up a temporary directory.
    
    Args:
        temp_dir: Path to the temporary directory
    """
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
