# Automated Image Labeling System - Usage Guide

This guide provides step-by-step instructions for using the Automated Image Labeling System, a web-based application that allows you to automatically label images using pre-trained vision models.

## Table of Contents

1. [System Overview](#system-overview)
2. [Getting Started](#getting-started)
3. [Uploading Images](#uploading-images)
4. [Selecting Labeling Options](#selecting-labeling-options)
5. [Processing Images](#processing-images)
6. [Viewing Results](#viewing-results)
7. [Downloading Labeled Dataset](#downloading-labeled-dataset)
8. [Starting a New Session](#starting-a-new-session)
9. [Troubleshooting](#troubleshooting)
10. [Advanced Usage](#advanced-usage)

## System Overview

The Automated Image Labeling System uses pre-trained vision models from torchvision to automatically label images. The system supports three types of labeling:

- **Semantic Segmentation**: Assigns a class label to each pixel in the image (using DeepLabV3)
- **Instance Segmentation**: Identifies individual object instances and their boundaries (using Mask R-CNN)
- **Bounding Boxes**: Detects objects and provides rectangular bounding boxes (using Faster R-CNN)

The system can output annotations in two standard formats:

- **COCO**: A JSON-based format widely used for object detection, segmentation, and captioning
- **YOLO**: A text-based format commonly used in real-time object detection systems

## Getting Started

To use the Automated Image Labeling System:

1. Ensure you have a modern web browser (Chrome, Firefox, Safari, or Edge)
2. Navigate to the application URL
3. The system will present a user-friendly interface with three tabs: Upload Images, Process Images, and Results

## Uploading Images

1. On the initial screen, you'll see the "Upload Images" tab active by default
2. Click the "Choose Files" button to open your file explorer
3. Select one or more image files (supported formats: JPG, PNG, JPEG, BMP, TIFF)
4. You can select multiple files by holding Ctrl (or Cmd on Mac) while clicking
5. After selecting your images, click the "Upload Images" button
6. A progress bar will appear showing the upload status
7. Once the upload is complete, you'll see a success message with the number of images uploaded
8. The system will automatically advance to the "Process Images" tab

## Selecting Labeling Options

In the "Process Images" tab, you'll need to select your preferred labeling type and output format:

### Label Type Options:

- **Semantic Segmentation**: Best for scene understanding where you need to know what class each pixel belongs to
- **Instance Segmentation**: Best for identifying individual objects and their precise boundaries
- **Bounding Boxes**: Best for object detection with rectangular regions around objects

### Output Format Options:

- **COCO**: Choose this format if you need detailed annotations with metadata, or if you're using tools that expect COCO format
- **YOLO**: Choose this format for simpler text-based annotations, or if you're using YOLO-based detection systems

Select your preferred options by clicking the corresponding radio buttons.

## Processing Images

1. After selecting your labeling type and output format, click the "Process Images" button
2. A progress indicator will appear, showing that processing is underway
3. Processing time depends on the number of images and the selected labeling type
   - Semantic segmentation is typically the fastest
   - Instance segmentation is the most computationally intensive
4. The system will process all uploaded images using the selected model
5. Once processing is complete, the system will automatically advance to the "Results" tab

## Viewing Results

The "Results" tab displays the labeled images with visualizations:

1. Each image is displayed in a card with the original filename as the header
2. For each image, you'll see:
   - The original image on the left
   - The labeled image with visualizations on the right
3. For instance segmentation and bounding box detection, a table below the images shows:
   - Detected class names
   - Confidence scores
   - Bounding box coordinates

The visualizations use different colors to distinguish between classes or object instances.

## Downloading Labeled Dataset

1. In the "Results" tab, click the "Download Labeled Dataset" button
2. Your browser will download a ZIP file containing:
   - A folder named "images" with all your original images
   - A folder named "annotations" with the labeled data in your chosen format:
     - For COCO format: A single JSON file named "instances.json"
     - For YOLO format: A "labels" folder with one .txt file per image, plus a "classes.txt" file

## Starting a New Session

To start a new labeling session:

1. Click the "Start New Session" button in the "Results" tab
2. This will clear all current data and return you to the "Upload Images" tab
3. You can now begin a new labeling session with different images or settings

## Troubleshooting

### Common Issues:

- **Upload Fails**: Ensure your images are in supported formats and not too large (under 10MB each)
- **Processing Takes Too Long**: Try using fewer images or selecting bounding box detection instead of segmentation
- **No Objects Detected**: The pre-trained models recognize common objects; try images with everyday objects

### Error Messages:

- If you encounter an error message, it will appear in a red alert box
- Most errors include specific information about what went wrong
- If you encounter persistent errors, try refreshing the page or starting a new session

## Advanced Usage

### Working with the Downloaded Dataset:

- **COCO Format**: The instances.json file can be used with tools like the COCO API, Detectron2, or MMDetection
- **YOLO Format**: The label files can be used directly with YOLOv3, YOLOv4, or YOLOv5 training pipelines

### Best Practices:

- For best results, use clear images with good lighting and minimal background clutter
- The pre-trained models work best on common objects they were trained on (people, animals, vehicles, furniture, etc.)
- If you need to label specific domain objects not covered by the pre-trained models, consider fine-tuning custom models

---

This completes the usage guide for the Automated Image Labeling System. If you have any questions or need further assistance, please refer to the system documentation or contact support.
