# System Architecture Document

## Overview
The Automated Image Labeling System is designed to provide a web-based interface for users to upload images and generate labeled datasets using pre-trained vision models. The system supports multiple labeling types (semantic segmentation, instance segmentation, and bounding boxes) and output formats (COCO and YOLO).

## Core Components

### 1. Inference Module
This module handles the processing of images using pre-trained models from torchvision.

- **Semantic Segmentation**: Uses DeepLabV3 model to generate pixel-level class predictions
- **Instance Segmentation**: Uses Mask R-CNN to identify and segment individual object instances
- **Bounding Box Detection**: Uses Faster R-CNN to detect objects and provide bounding box coordinates

Each model is encapsulated in its own class with a common interface for prediction.

### 2. Formatters Module
This module converts model predictions into standardized annotation formats.

- **COCO Formatter**: Converts predictions to COCO JSON format
- **YOLO Formatter**: Converts predictions to YOLO text file format

Both formatters implement a common interface for consistency.

### 3. Web Interface
A Flask-based web application that provides:

- Image upload functionality
- Model and format selection
- Results visualization
- Dataset download

### 4. Utils Module
Contains shared utilities for:

- Image processing
- File handling
- Data validation
- Visualization helpers

## Data Flow

1. **Input**: User uploads images through the web interface
2. **Processing**: 
   - Images are stored temporarily
   - Selected inference model processes images
   - Predictions are converted to the selected format
3. **Output**: 
   - Labeled dataset is packaged
   - User can download the complete dataset

## Directory Structure

```
auto_image_labeler/
├── src/
│   ├── inference/           # Model inference implementations
│   │   ├── __init__.py
│   │   ├── base.py          # Base inference interface
│   │   ├── semantic.py      # Semantic segmentation (DeepLabV3)
│   │   ├── instance.py      # Instance segmentation (Mask R-CNN)
│   │   └── detection.py     # Object detection (Faster R-CNN)
│   │
│   ├── formatters/          # Output format converters
│   │   ├── __init__.py
│   │   ├── base.py          # Base formatter interface
│   │   ├── coco.py          # COCO JSON formatter
│   │   └── yolo.py          # YOLO text formatter
│   │
│   ├── utils/               # Utility functions
│   │   ├── __init__.py
│   │   ├── image.py         # Image processing utilities
│   │   ├── file.py          # File handling utilities
│   │   └── visualization.py # Result visualization
│   │
│   ├── routes/              # Flask routes
│   │   ├── __init__.py
│   │   └── main.py          # Main application routes
│   │
│   ├── static/              # Static web assets
│   │   ├── css/
│   │   ├── js/
│   │   └── images/
│   │
│   └── main.py              # Flask application entry point
│
├── venv/                    # Virtual environment
└── requirements.txt         # Project dependencies
```

## Extension Points

The system is designed to be easily extended in the future:

1. **New Model Support**: Add new model implementations to the inference module
2. **Additional Output Formats**: Implement new formatters in the formatters module
3. **Enhanced Visualization**: Extend the visualization utilities

## Dependencies

- Python 3.8+
- PyTorch and torchvision
- Flask for web interface
- OpenCV for image processing
- pycocotools for COCO format handling
