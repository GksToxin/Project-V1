# Enhanced Automated Image Labeling System

This document provides a comprehensive guide to the enhanced Automated Image Labeling System, which uses pre-trained vision models from torchvision to automatically label images with semantic segmentation, instance segmentation, or bounding boxes, and outputs in either COCO or YOLO format.

## Table of Contents
- [Overview](#overview)
- [New Advanced Features](#new-advanced-features)
- [System Architecture](#system-architecture)
- [Installation](#installation)
- [Usage Guide](#usage-guide)
- [API Documentation](#api-documentation)
- [Extending the System](#extending-the-system)
- [Troubleshooting](#troubleshooting)

## Overview

The Enhanced Automated Image Labeling System is a web-based application that allows users to automatically label images using state-of-the-art computer vision models. The system supports three types of labeling:

1. **Semantic Segmentation** - Pixel-level classification using DeepLabV3
2. **Instance Segmentation** - Object instance masks using Mask R-CNN
3. **Bounding Box Detection** - Object detection boxes using Faster R-CNN

The system can output annotations in two standard formats:

1. **COCO** - Common Objects in Context format
2. **YOLO** - You Only Look Once format

## New Advanced Features

The system has been enhanced with the following advanced features:

### Smart Class Filtering
- Select specific object classes to include in the output
- Post-filtering approach that runs inference on all classes but filters results
- Dynamic UI updates as detection results come in

### Per-Class Confidence Thresholds
- Set custom confidence thresholds for each detected class
- Global threshold control with individual class overrides
- Real-time visualization updates as thresholds are adjusted

### Interactive Correction Loop
- Review and edit predictions after initial inference
- Adjust bounding boxes and modify masks with an intuitive interface
- Change class labels and confidence scores for detected objects
- Save corrected annotations for improved dataset quality

### Object Cropping + Auto-Tagging
- Automatically crop detected objects from images
- Store cropped objects in folders organized by class
- Configure minimum confidence score and padding options
- Build classification datasets from detection results

### Pre/Post-processing Pipeline Options
- **Preprocessing options:**
  - Image resizing with configurable dimensions
  - Normalization (standard or ImageNet)
  - Grayscale conversion
  - Gaussian blur with adjustable kernel size
- **Postprocessing options:**
  - Non-maximum suppression (NMS) with configurable IoU threshold
  - Class-aware NMS
  - Mask cleanup with morphological operations

### REST API Access
- Programmatic access to labeling functionality
- Support for both file uploads and base64 encoded images
- Full parameter control matching the GUI options
- Endpoints for processing, downloading, and cleanup

### Dataset Augmentation Options
- Synchronized label transformation with image augmentation
- Horizontal and vertical flipping
- Rotation with configurable angle limits
- Color jitter (brightness, contrast, saturation)
- Noise addition (Gaussian, salt & pepper)

### Ground Truth Evaluation Mode
- Upload ground truth labels and compare against predictions
- Calculate metrics: IoU, mAP, precision, recall
- Visualization tools for comparing predictions to ground truth
- Support for both COCO and YOLO ground truth formats

### Custom Model Upload
- Upload your own PyTorch (.pth) model files
- Provide class mappings in JSON or TXT format
- Automatic model type detection
- Seamless integration with the inference pipeline

### Project Saving and Resume Support
- Save session state including uploaded images and settings
- Resume work on projects at a later time
- Export projects for backup or sharing
- Import projects from other users

### Enhanced Dynamic UI
- Dropbox-inspired multi-page workflow
- Real-time UI updates with AJAX-powered forms
- Interactive editing with canvas-based interface
- Responsive design for desktop and mobile devices
- Visual feedback with animations and transitions

## System Architecture

The system follows a modular architecture with clear separation of concerns:

```
auto_image_labeler/
├── src/                           # Source code directory
│   ├── inference/                 # Inference module
│   │   ├── __init__.py           # Factory function for creating inference models
│   │   ├── base.py               # Base abstract class for inference models
│   │   ├── semantic.py           # Semantic segmentation implementation (DeepLabV3)
│   │   ├── instance.py           # Instance segmentation implementation (Mask R-CNN)
│   │   ├── detection.py          # Bounding box detection implementation (Faster R-CNN)
│   │   ├── custom.py             # Custom model loading and inference
│   │   ├── filtering.py          # Class filtering functionality
│   │   ├── thresholds.py         # Confidence threshold management
│   │   └── processing.py         # Pre/post-processing pipeline
│   │
│   ├── formatters/               # Annotation formatter module
│   │   ├── __init__.py           # Factory function for creating formatters
│   │   ├── base.py               # Base abstract class for formatters
│   │   ├── coco.py               # COCO format converter
│   │   ├── yolo.py               # YOLO format converter
│   │   └── editor.py             # Interactive correction functionality
│   │
│   ├── utils/                    # Utility functions
│   │   ├── __init__.py
│   │   ├── image.py              # Image processing utilities
│   │   ├── file.py               # File handling utilities
│   │   ├── visualization.py      # Result visualization utilities
│   │   ├── cropping.py           # Object cropping functionality
│   │   ├── augmentation.py       # Dataset augmentation utilities
│   │   ├── evaluation.py         # Ground truth evaluation metrics
│   │   └── project.py            # Project saving and resume support
│   │
│   ├── api/                      # REST API module
│   │   ├── __init__.py
│   │   └── routes.py             # API endpoint definitions
│   │
│   ├── routes/                   # Flask routes
│   │   ├── __init__.py
│   │   ├── main.py               # Main application routes
│   │   └── edit.py               # Interactive editing routes
│   │
│   ├── templates/                # HTML templates
│   │   └── base.html             # Base template with common elements
│   │
│   ├── static/                   # Static web assets
│   │   ├── css/                  # CSS stylesheets
│   │   │   └── dynamic-ui.css    # Dynamic UI styles
│   │   ├── js/                   # JavaScript files
│   │   │   └── dynamic-ui.js     # Dynamic UI functionality
│   │   └── index.html            # Main application page
│   │
│   └── main.py                   # Flask application entry point
│
├── tests/                        # Test directory
│   └── test_modules.py           # Unit tests for modules
│
├── README.md                     # Project overview and documentation
├── usage_guide.md                # Detailed usage instructions
├── architecture.md               # System architecture documentation
└── requirements.txt              # Project dependencies
```

## Installation

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Setup
1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/auto_image_labeler.git
   cd auto_image_labeler
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run the application:
   ```bash
   python src/main.py
   ```

4. Access the web interface at http://localhost:5000

## Usage Guide

### Basic Workflow

1. **Upload Images**
   - Drag and drop images onto the upload area or click to select files
   - Multiple images can be uploaded at once
   - Supported formats: JPG, PNG, BMP

2. **Configure Labeling Options**
   - Select labeling type (semantic segmentation, instance segmentation, or bounding boxes)
   - Choose output format (COCO or YOLO)
   - Configure advanced options (class filtering, thresholds, preprocessing, etc.)

3. **Process Images**
   - Click "Process Images" to start the labeling process
   - Progress is displayed in real-time
   - Results are shown with visualizations

4. **Review and Edit Results**
   - View labeled images with detected objects
   - Edit labels using the interactive correction interface
   - Apply changes and save edited annotations

5. **Download Results**
   - Download the complete labeled dataset
   - Includes original images and annotations in the selected format

### Advanced Features Usage

#### Smart Class Filtering
1. After processing, checkboxes for each detected class appear
2. Select/deselect classes to include/exclude from results
3. Results update in real-time as classes are filtered

#### Per-Class Confidence Thresholds
1. Adjust the global threshold slider to set a baseline
2. Fine-tune individual class thresholds using class-specific sliders
3. Visualizations update as thresholds are adjusted

#### Interactive Correction Loop
1. Click "Edit Labels" on the results page
2. Select an image from the dropdown menu
3. Use the toolbar to select, move, resize, or delete objects
4. Adjust object properties (class, confidence) in the sidebar
5. Click "Apply Changes" to update the object
6. Click "Save Edits" when finished

#### Object Cropping
1. Enable object cropping in the processing options
2. Set minimum confidence score and padding
3. Cropped objects are saved in class-specific folders
4. Download the complete dataset including cropped objects

#### Pre/Post-processing Pipeline
1. Toggle preprocessing/postprocessing options
2. Configure parameters for each enabled option
3. Process images with the selected pipeline settings

#### REST API Access
See the [API Documentation](#api-documentation) section for details on using the REST API.

#### Dataset Augmentation
1. Enable augmentation in the processing options
2. Select desired augmentation types and parameters
3. Augmented images and synchronized labels are included in the output

#### Ground Truth Evaluation
1. Upload ground truth labels in COCO or YOLO format
2. Process images with the same settings used for ground truth
3. View evaluation metrics and comparison visualizations

#### Custom Model Upload
1. Click "Upload Model" in the sidebar
2. Select a PyTorch (.pth) model file
3. Optionally provide a class mapping file (JSON or TXT)
4. Select the model type if not automatically detected
5. Use the uploaded model for inference

#### Project Saving and Resume
1. Click "Save Project" after processing
2. Enter a name and description for the project
3. To resume, click "Load Project" and select from the list
4. Export projects for sharing or backup

## API Documentation

The system provides a REST API for programmatic access to labeling functionality.

### Endpoints

#### POST /api/label
Process and label images.

**Request:**
- Content-Type: `multipart/form-data` or `application/json`
- Parameters:
  - `image`: Image file or base64 encoded image
  - `label_type`: Type of labeling (`semantic`, `instance`, or `bbox`)
  - `output_format`: Output format (`coco` or `yolo`)
  - `selected_classes`: (Optional) List of class IDs to include
  - `global_threshold`: (Optional) Global confidence threshold
  - `class_thresholds`: (Optional) Per-class thresholds
  - `preprocessing_options`: (Optional) Preprocessing configuration
  - `postprocessing_options`: (Optional) Postprocessing configuration
  - `enable_cropping`: (Optional) Whether to crop objects
  - `enable_augmentation`: (Optional) Whether to augment data

**Response:**
```json
{
  "success": true,
  "session_id": "abc123",
  "results": [...],
  "download_url": "/api/download/abc123"
}
```

#### GET /api/download/{session_id}
Download labeled dataset.

**Response:**
- Content-Type: `application/zip`
- Body: ZIP file containing labeled dataset

#### POST /api/cleanup/{session_id}
Clean up temporary files.

**Response:**
```json
{
  "success": true
}
```

### Example Usage

```python
import requests
import json
import base64
from PIL import Image
import io

# Prepare image
image = Image.open("example.jpg")
buffered = io.BytesIO()
image.save(buffered, format="JPEG")
img_str = base64.b64encode(buffered.getvalue()).decode()

# API request
url = "http://localhost:5000/api/label"
payload = {
    "image": img_str,
    "label_type": "instance",
    "output_format": "coco",
    "global_threshold": 0.5
}

response = requests.post(url, json=payload)
result = response.json()

# Download results
if result["success"]:
    download_url = result["download_url"]
    download_response = requests.get(f"http://localhost:5000{download_url}")
    with open("labeled_dataset.zip", "wb") as f:
        f.write(download_response.content)
```

## Extending the System

The modular architecture makes it easy to extend the system with new features:

### Adding New Model Types
1. Create a new class in the `inference` module that inherits from `InferenceModel`
2. Implement the required methods for inference and result processing
3. Register the new model in the factory function in `__init__.py`

### Adding New Output Formats
1. Create a new class in the `formatters` module that inherits from `AnnotationFormatter`
2. Implement the required methods for converting predictions to the new format
3. Register the new formatter in the factory function in `__init__.py`

### Adding New Preprocessing/Postprocessing Steps
1. Add new functions to the `processing.py` module
2. Update the UI to include controls for the new options
3. Integrate the new steps into the processing pipeline

## Troubleshooting

### Common Issues

#### Images not uploading
- Check that image formats are supported (JPG, PNG, BMP)
- Ensure images are not too large (max 10MB per image)
- Verify that you have sufficient disk space

#### Processing fails
- Check the console for error messages
- Ensure you have sufficient memory for the selected models
- Try processing fewer images at once

#### Custom models not working
- Verify that the model is a valid PyTorch (.pth) file
- Ensure the class mapping format is correct
- Check that the model architecture is compatible

#### API requests failing
- Verify the endpoint URL and request format
- Check that all required parameters are provided
- Ensure the server is running and accessible

### Getting Help
If you encounter issues not covered here, please:
1. Check the console for error messages
2. Review the logs in the `logs` directory
3. Submit an issue on the GitHub repository with detailed information
