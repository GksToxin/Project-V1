import os
import sys
import unittest
from PIL import Image
import numpy as np
import torch

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.inference.semantic import SemanticSegmentation
from src.inference.instance import InstanceSegmentation
from src.inference.detection import BoundingBoxDetection
from src.formatters.coco import COCOFormatter
from src.formatters.yolo import YOLOFormatter

class TestInferenceModels(unittest.TestCase):
    """Test cases for inference models."""
    
    def setUp(self):
        """Set up test environment."""
        # Create a simple test image (100x100 RGB)
        self.test_image = Image.new('RGB', (100, 100), color='white')
        # Draw some shapes to make it more interesting
        from PIL import ImageDraw
        draw = ImageDraw.Draw(self.test_image)
        draw.rectangle([20, 20, 80, 80], fill='blue')
        draw.ellipse([30, 30, 70, 70], fill='red')
    
    def test_semantic_segmentation(self):
        """Test semantic segmentation model."""
        model = SemanticSegmentation(device='cpu')
        results = model(self.test_image)
        
        # Check that results have the expected format
        self.assertIn('mask', results)
        self.assertIn('classes', results)
        self.assertIn('class_names', results)
        self.assertIn('type', results)
        self.assertEqual(results['type'], 'semantic_segmentation')
        
        # Check mask dimensions
        self.assertEqual(results['mask'].shape, (100, 100))
    
    def test_instance_segmentation(self):
        """Test instance segmentation model."""
        model = InstanceSegmentation(device='cpu')
        results = model(self.test_image)
        
        # Check that results have the expected format
        self.assertIn('boxes', results)
        self.assertIn('masks', results)
        self.assertIn('labels', results)
        self.assertIn('scores', results)
        self.assertIn('class_names', results)
        self.assertIn('type', results)
        self.assertEqual(results['type'], 'instance_segmentation')
        
        # Check that boxes, labels, and scores have the same length
        self.assertEqual(len(results['boxes']), len(results['labels']))
        self.assertEqual(len(results['boxes']), len(results['scores']))
    
    def test_bounding_box_detection(self):
        """Test bounding box detection model."""
        model = BoundingBoxDetection(device='cpu')
        results = model(self.test_image)
        
        # Check that results have the expected format
        self.assertIn('boxes', results)
        self.assertIn('labels', results)
        self.assertIn('scores', results)
        self.assertIn('class_names', results)
        self.assertIn('type', results)
        self.assertEqual(results['type'], 'bounding_box')
        
        # Check that boxes, labels, and scores have the same length
        self.assertEqual(len(results['boxes']), len(results['labels']))
        self.assertEqual(len(results['boxes']), len(results['scores']))

class TestFormatters(unittest.TestCase):
    """Test cases for annotation formatters."""
    
    def setUp(self):
        """Set up test environment."""
        # Create a simple test image info
        self.image_info = {
            "filename": "test.jpg",
            "width": 100,
            "height": 100,
            "path": "/path/to/test.jpg"
        }
        
        # Create sample predictions for each type
        
        # Semantic segmentation
        self.semantic_pred = {
            'mask': np.zeros((100, 100), dtype=np.uint8),
            'classes': [1, 2],
            'class_names': ['person', 'car'],
            'type': 'semantic_segmentation'
        }
        # Add some regions to the mask
        self.semantic_pred['mask'][20:50, 20:50] = 1  # person
        self.semantic_pred['mask'][60:90, 60:90] = 2  # car
        
        # Instance segmentation
        self.instance_pred = {
            'boxes': [[20, 20, 50, 50], [60, 60, 90, 90]],
            'masks': np.zeros((2, 100, 100), dtype=np.uint8),
            'labels': [1, 3],
            'scores': [0.9, 0.8],
            'class_names': ['person', 'dog'],
            'type': 'instance_segmentation'
        }
        # Add some regions to the masks
        self.instance_pred['masks'][0, 20:50, 20:50] = 1  # person
        self.instance_pred['masks'][1, 60:90, 60:90] = 1  # dog
        
        # Bounding box detection
        self.bbox_pred = {
            'boxes': [[20, 20, 50, 50], [60, 60, 90, 90]],
            'labels': [1, 3],
            'scores': [0.9, 0.8],
            'class_names': ['person', 'dog'],
            'type': 'bounding_box'
        }
        
        # Create temp directory for output
        self.temp_dir = '/tmp/test_formatters'
        os.makedirs(self.temp_dir, exist_ok=True)
    
    def test_coco_formatter(self):
        """Test COCO formatter with all prediction types."""
        formatter = COCOFormatter()
        
        # Test with semantic segmentation
        semantic_annotations = formatter.format(self.semantic_pred, self.image_info)
        self.assertIsInstance(semantic_annotations, list)
        
        # Test with instance segmentation
        instance_annotations = formatter.format(self.instance_pred, self.image_info)
        self.assertIsInstance(instance_annotations, list)
        
        # Test with bounding box detection
        bbox_annotations = formatter.format(self.bbox_pred, self.image_info)
        self.assertIsInstance(bbox_annotations, list)
        
        # Test saving annotations
        output_file = formatter.save(None, self.temp_dir)
        self.assertTrue(os.path.exists(output_file))
    
    def test_yolo_formatter(self):
        """Test YOLO formatter with all prediction types."""
        formatter = YOLOFormatter()
        
        # Test with semantic segmentation
        semantic_annotations = formatter.format(self.semantic_pred, self.image_info)
        self.assertIsInstance(semantic_annotations, list)
        
        # Test with instance segmentation
        instance_annotations = formatter.format(self.instance_pred, self.image_info)
        self.assertIsInstance(instance_annotations, list)
        
        # Test with bounding box detection
        bbox_annotations = formatter.format(self.bbox_pred, self.image_info)
        self.assertIsInstance(bbox_annotations, list)
        
        # Test saving annotations
        output_dir = formatter.save(bbox_annotations, self.temp_dir)
        self.assertTrue(os.path.exists(output_dir))
        self.assertTrue(os.path.exists(os.path.join(self.temp_dir, 'classes.txt')))

if __name__ == '__main__':
    unittest.main()
