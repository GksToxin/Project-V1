# Enhanced Automated Image Labeling System - Usage Guide

This guide provides detailed instructions for using the Enhanced Automated Image Labeling System, including all advanced features and workflows.

## Getting Started

### Installation

1. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Start the application:
   ```bash
   python src/main.py
   ```

3. Access the web interface at http://localhost:5000

### Basic Workflow

The system follows a simple workflow:

1. **Upload Images** - Select or drag-and-drop images to label
2. **Configure Options** - Choose labeling type, output format, and advanced settings
3. **Process Images** - Run inference with selected models
4. **Review Results** - View and optionally edit the labeled results
5. **Download Dataset** - Get the complete labeled dataset

## Advanced Features

### Smart Class Filtering

This feature allows you to select which object classes to include in your results.

**How to use:**
1. After uploading images, select your labeling type and model
2. In the "Class Filtering" section, you'll see checkboxes for each available class
3. Select or deselect classes to include or exclude them from results
4. The system will run inference on all classes but only include selected ones in the output
5. You can change selections at any time and see results update in real-time

**Tips:**
- Use the "Select All" checkbox to quickly select or deselect all classes
- Class counts show how many instances of each class were detected
- Filtering happens post-inference, so it doesn't affect processing time

### Per-Class Confidence Thresholds

This feature lets you set custom confidence thresholds for each detected class.

**How to use:**
1. Set the global threshold using the main slider (applies to all classes by default)
2. For fine-tuning, adjust individual class thresholds in the "Class Thresholds" section
3. Each class has its own slider that overrides the global threshold
4. Results update in real-time as you adjust thresholds

**Tips:**
- Higher thresholds reduce false positives but might miss some objects
- Lower thresholds catch more objects but may include false detections
- Different classes often benefit from different threshold values
- Reset individual thresholds to the global value by clicking the reset icon

### Interactive Correction Loop

This feature allows you to review and edit predictions after initial inference.

**How to use:**
1. After processing images, click "Edit Labels" on the results page
2. Select an image from the dropdown menu to edit
3. Use the toolbar to interact with detected objects:
   - **Select Tool**: Click on objects to select them
   - **Move Tool**: Drag selected objects to reposition them
   - **Resize Tool**: Drag handles to adjust bounding box dimensions
   - **Delete Tool**: Remove unwanted objects
   - **Add Tool**: Create new bounding boxes or masks
4. Adjust object properties in the sidebar:
   - Change class labels using the dropdown
   - Adjust confidence scores with the slider
5. Click "Apply Changes" to update the selected object
6. Click "Save Edits" when finished to update the dataset

**Tips:**
- Use keyboard shortcuts for faster editing (hover over tools for hints)
- Double-click an object to quickly select and edit its properties
- Changes are not permanent until you click "Save Edits"
- The "Undo" button reverts your last action

### Object Cropping + Auto-Tagging

This feature automatically extracts detected objects and organizes them by class.

**How to use:**
1. Enable "Object Cropping" in the processing options
2. Configure cropping parameters:
   - **Minimum Score**: Only crop objects above this confidence threshold
   - **Padding**: Add extra space around objects (in pixels or percentage)
3. Process images normally
4. Cropped objects will be included in the downloaded dataset in a "crops" folder
   organized by class name

**Tips:**
- Great for creating classification datasets from detection results
- Higher minimum scores ensure better quality crops
- Add padding to include context around objects
- For instance segmentation, crops can include mask overlays

### Pre/Post-processing Pipeline Options

This feature provides control over image processing before and after inference.

**How to use:**
1. Toggle "Enable Preprocessing" to access preprocessing options:
   - **Resize**: Change image dimensions before inference
   - **Normalize**: Apply pixel normalization (standard or ImageNet)
   - **Grayscale**: Convert images to grayscale
   - **Gaussian Blur**: Apply blur with adjustable kernel size
2. Toggle "Enable Postprocessing" to access postprocessing options:
   - **Non-Maximum Suppression (NMS)**: Remove overlapping detections
   - **Class-Aware NMS**: Apply NMS separately for each class
   - **Mask Cleanup**: Apply morphological operations to masks
   - **Opening/Closing**: Remove noise or fill holes in masks

**Tips:**
- Preprocessing can improve model performance on challenging images
- Resizing to smaller dimensions speeds up inference
- NMS is particularly useful for dense object scenes
- Mask cleanup helps produce cleaner segmentation results

### REST API Access

This feature provides programmatic access to the labeling functionality.

**How to use:**
1. Send HTTP requests to the API endpoints:
   - `POST /api/label`: Process and label images
   - `GET /api/download/{session_id}`: Download labeled dataset
   - `POST /api/cleanup/{session_id}`: Clean up temporary files
2. See the API documentation in README.md for detailed request/response formats

**Example Python code:**
```python
import requests
import json
import base64
from PIL import Image
import io

# Prepare image
image = Image.open("example.jpg")
buffered = io.BytesIO()
image.save(buffered, format="JPEG")
img_str = base64.b64encode(buffered.getvalue()).decode()

# API request
url = "http://localhost:5000/api/label"
payload = {
    "image": img_str,
    "label_type": "instance",
    "output_format": "coco",
    "global_threshold": 0.5
}

response = requests.post(url, json=payload)
result = response.json()

# Download results
if result["success"]:
    download_url = result["download_url"]
    download_response = requests.get(f"http://localhost:5000{download_url}")
    with open("labeled_dataset.zip", "wb") as f:
        f.write(download_response.content)
```

### Dataset Augmentation Options

This feature generates additional training data with synchronized label transformations.

**How to use:**
1. Enable "Dataset Augmentation" in the processing options
2. Select desired augmentation types:
   - **Horizontal/Vertical Flip**: Mirror images horizontally or vertically
   - **Rotation**: Rotate images with configurable maximum angle
   - **Color Jitter**: Adjust brightness, contrast, saturation
   - **Noise**: Add Gaussian or salt & pepper noise
3. Process images normally
4. Augmented images and their labels will be included in the downloaded dataset

**Tips:**
- Augmentation can significantly increase your training data size
- All label types (boxes, masks, segmentation) are properly transformed
- Combine multiple augmentation types for more variety
- Use rotation sparingly as it can distort bounding boxes

### Ground Truth Evaluation Mode

This feature compares predictions against ground truth labels and calculates metrics.

**How to use:**
1. Click "Evaluate" on the main page
2. Upload ground truth labels in COCO or YOLO format
3. Select the same images used for ground truth
4. Configure labeling options to match those used for ground truth
5. Process images
6. View evaluation metrics and comparison visualizations

**Metrics provided:**
- For semantic segmentation: IoU, Dice coefficient, pixel accuracy
- For instance segmentation: mAP, precision, recall
- For bounding boxes: mAP, precision, recall
- Per-class and overall metrics

**Tips:**
- Ensure ground truth format matches your selected output format
- Use the same preprocessing settings as were used for ground truth
- Adjust thresholds to see how they affect metrics
- Export evaluation reports for documentation

### Custom Model Upload

This feature allows you to use your own trained PyTorch models.

**How to use:**
1. Click "Upload Model" in the sidebar
2. Select a PyTorch (.pth) model file
3. Optionally provide a class mapping file (JSON or TXT format)
4. Select the model type if not automatically detected
5. Click "Upload"
6. Your model will appear in the model selection dropdown

**Class mapping formats:**
- JSON: `{"0": "background", "1": "person", "2": "car", ...}`
- TXT: One class name per line, line number corresponds to class ID

**Tips:**
- Models should be compatible with torchvision inference patterns
- Class mapping is essential for meaningful class names
- The system attempts to detect model type automatically
- Custom models are stored for future sessions

### Project Saving and Resume Support

This feature allows you to save your work and continue later.

**How to use:**
1. After processing images, click "Save Project" in the sidebar
2. Enter a name and optional description for your project
3. Click "Save"
4. To resume work later, click "Load Project" and select from the list
5. Your images, settings, and results will be restored

**Additional options:**
- **Export Project**: Download a project as a ZIP file for backup or sharing
- **Import Project**: Upload a previously exported project
- **Delete Project**: Remove projects you no longer need

**Tips:**
- Projects save all settings, images, and results
- Regular saving prevents loss of work
- Exported projects can be shared with colleagues
- Projects are stored locally in the database

## Output Formats

### COCO Format

The COCO (Common Objects in Context) format is a JSON-based format widely used for object detection, segmentation, and captioning.

**Structure:**
```json
{
  "info": {...},
  "licenses": [...],
  "images": [
    {
      "id": 1,
      "width": 640,
      "height": 480,
      "file_name": "image1.jpg",
      ...
    },
    ...
  ],
  "annotations": [
    {
      "id": 1,
      "image_id": 1,
      "category_id": 3,
      "segmentation": [...],
      "area": 4023,
      "bbox": [x, y, width, height],
      "iscrowd": 0
    },
    ...
  ],
  "categories": [
    {
      "id": 1,
      "name": "person",
      "supercategory": "person"
    },
    ...
  ]
}
```

**Tips:**
- COCO format is ideal for complex datasets with multiple annotation types
- Supports both instance segmentation and bounding boxes
- Compatible with many training frameworks
- More verbose but more informative than YOLO

### YOLO Format

The YOLO (You Only Look Once) format is a simple text-based format primarily used for object detection.

**Structure:**
- One text file per image with the same name (e.g., image.jpg → image.txt)
- Each line represents one object: `class_id center_x center_y width height`
- Coordinates are normalized to [0, 1]

**Example:**
```
0 0.507 0.626 0.945 0.543
1 0.321 0.581 0.169 0.373
```

**Tips:**
- YOLO format is simpler and more compact than COCO
- Only supports bounding boxes natively
- Widely used for training YOLO models
- Easier to manually edit if needed

## Troubleshooting

### Common Issues

#### Images not uploading
- Check that image formats are supported (JPG, PNG, BMP)
- Ensure images are not too large (max 10MB per image)
- Verify that you have sufficient disk space

#### Processing fails
- Check the console for error messages
- Ensure you have sufficient memory for the selected models
- Try processing fewer images at once

#### Custom models not working
- Verify that the model is a valid PyTorch (.pth) file
- Ensure the class mapping format is correct
- Check that the model architecture is compatible

#### API requests failing
- Verify the endpoint URL and request format
- Check that all required parameters are provided
- Ensure the server is running and accessible

### Getting Help

If you encounter issues not covered here, please:
1. Check the console for error messages
2. Review the logs in the `logs` directory
3. Submit an issue on the GitHub repository with detailed information
