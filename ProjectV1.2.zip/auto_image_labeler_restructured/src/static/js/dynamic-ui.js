// Dynamic UI enhancements for the Automated Image Labeling System

// Global variables for dynamic UI state
let currentTab = 'upload';
let isDraggingImage = false;
let isEditingLabel = false;
let isProcessing = false;
let currentProject = null;
let thresholdUpdateTimeout = null;

// Initialize dynamic UI features
$(document).ready(function() {
    // Initialize drag and drop for image uploads
    initDragAndDrop();
    
    // Initialize dynamic form handling
    initDynamicForms();
    
    // Initialize interactive editing features
    initInteractiveEditing();
    
    // Initialize real-time UI updates
    initRealTimeUpdates();
    
    // Initialize responsive workflow transitions
    initWorkflowTransitions();
    
    // Initialize toast notifications
    initToastNotifications();
    
    // Initialize collapsible panels
    initCollapsiblePanels();
    
    // Initialize modal dialogs
    initModalDialogs();
});

// Drag and drop image uploads
function initDragAndDrop() {
    const dropZone = $('#drop-zone');
    const fileInput = $('#images');
    
    // Show drop zone on drag over
    $(document).on('dragover', function(e) {
        e.preventDefault();
        e.stopPropagation();
        if (!isProcessing) {
            dropZone.addClass('active');
        }
    });
    
    // Hide drop zone on drag leave
    $(document).on('dragleave', function(e) {
        e.preventDefault();
        e.stopPropagation();
        if (!isDraggingImage) {
            dropZone.removeClass('active');
        }
    });
    
    // Handle drop event
    dropZone.on('drop', function(e) {
        e.preventDefault();
        e.stopPropagation();
        dropZone.removeClass('active');
        
        if (!isProcessing) {
            const files = e.originalEvent.dataTransfer.files;
            if (files.length > 0) {
                // Update file input with dropped files
                fileInput.prop('files', files);
                
                // Show preview of dropped images
                showImagePreviews(files);
                
                // Trigger form validation
                validateUploadForm();
            }
        }
    });
    
    // Show preview when files are selected via file input
    fileInput.on('change', function() {
        const files = this.files;
        if (files.length > 0) {
            showImagePreviews(files);
            validateUploadForm();
        }
    });
}

// Show preview of selected images
function showImagePreviews(files) {
    const previewContainer = $('#image-previews');
    previewContainer.empty();
    
    // Limit preview to first 12 images
    const maxPreviews = Math.min(files.length, 12);
    
    for (let i = 0; i < maxPreviews; i++) {
        const file = files[i];
        if (file.type.match('image.*')) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                const preview = $(`
                    <div class="preview-item">
                        <img src="${e.target.result}" alt="${file.name}">
                        <div class="preview-filename">${file.name}</div>
                    </div>
                `);
                previewContainer.append(preview);
                
                // Add animation
                setTimeout(() => {
                    preview.addClass('show');
                }, i * 50);
            };
            
            reader.readAsDataURL(file);
        }
    }
    
    // Show count if more files than previews
    if (files.length > maxPreviews) {
        previewContainer.append(`
            <div class="preview-more">
                +${files.length - maxPreviews} more
            </div>
        `);
    }
    
    // Show preview container
    previewContainer.removeClass('d-none');
}

// Dynamic form handling
function initDynamicForms() {
    // Upload form submission with progress
    $('#upload-form').on('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const files = $('#images')[0].files;
        
        if (files.length === 0) {
            showToast('Please select at least one image file.', 'danger');
            return;
        }
        
        // Show progress and set processing state
        isProcessing = true;
        $('#upload-progress').removeClass('d-none');
        $('.progress-bar').css('width', '0%');
        
        // Disable form controls
        $('#upload-form :input').prop('disabled', true);
        
        // Upload files with AJAX
        $.ajax({
            url: '/upload',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function() {
                const xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const percent = Math.round((e.loaded / e.total) * 100);
                        $('.progress-bar').css('width', percent + '%');
                    }
                }, false);
                return xhr;
            },
            success: function(response) {
                sessionId = response.session_id;
                
                // Show success message
                showToast(`Successfully uploaded ${response.num_images} images.`, 'success');
                
                // Enable process tab and switch to it with animation
                $('#process-tab').prop('disabled', false);
                setTimeout(() => {
                    $('#process-tab').tab('show');
                }, 500);
                
                // Fetch available classes
                fetchAvailableClasses();
            },
            error: function(xhr) {
                const response = xhr.responseJSON || { error: 'An error occurred during upload.' };
                showToast(response.error, 'danger');
            },
            complete: function() {
                // Reset processing state
                isProcessing = false;
                
                // Enable form controls
                $('#upload-form :input').prop('disabled', false);
                
                // Hide progress after a delay
                setTimeout(function() {
                    $('#upload-progress').addClass('d-none');
                }, 1000);
            }
        });
    });
    
    // Process form with real-time updates
    $('#process-form').on('submit', function(e) {
        e.preventDefault();
        
        if (!sessionId) {
            showToast('No active session. Please upload images first.', 'danger');
            return;
        }
        
        // Collect form data
        const labelType = $('input[name="label_type"]:checked').val();
        const outputFormat = $('input[name="output_format"]:checked').val();
        
        // Get selected classes
        const selectedClasses = [];
        $('.class-checkbox:checked').each(function() {
            selectedClasses.push(parseInt($(this).val()));
        });
        
        // Get threshold values
        const globalThreshold = parseFloat($('#global-threshold').val());
        const classThresholds = {};
        $('.class-threshold').each(function() {
            const classId = $(this).data('class-id');
            const threshold = parseFloat($(this).val());
            classThresholds[classId] = threshold;
        });
        
        // Get preprocessing options
        const preprocessingOptions = {
            resize: $('#enable-resize').prop('checked'),
            resize_dimensions: [
                parseInt($('#resize-width').val()),
                parseInt($('#resize-height').val())
            ],
            normalize: $('#enable-normalize').prop('checked'),
            normalize_with_imagenet: $('#normalize-imagenet').prop('checked'),
            grayscale: $('#enable-grayscale').prop('checked'),
            gaussian_blur: $('#enable-blur').prop('checked'),
            blur_kernel_size: parseInt($('#blur-kernel').val())
        };
        
        // Get postprocessing options
        const postprocessingOptions = {
            apply_nms: $('#enable-nms').prop('checked'),
            nms_iou_threshold: parseFloat($('#nms-threshold').val()),
            class_aware_nms: $('#class-aware-nms').prop('checked'),
            mask_cleanup: $('#enable-mask-cleanup').prop('checked'),
            apply_opening: $('#enable-opening').prop('checked'),
            apply_closing: $('#enable-closing').prop('checked'),
            morph_kernel_size: parseInt($('#morph-kernel').val())
        };
        
        // Get cropping options
        const enableCropping = $('#enable-cropping').prop('checked');
        const cropMinScore = parseFloat($('#crop-min-score').val());
        const cropPadding = parseInt($('#crop-padding').val());
        
        // Get augmentation options
        const enableAugmentation = $('#enable-augmentation').prop('checked');
        const augmentationOptions = {
            horizontal_flip: $('#enable-horizontal-flip').prop('checked'),
            vertical_flip: $('#enable-vertical-flip').prop('checked'),
            rotation: $('#enable-rotation').prop('checked'),
            max_rotation_angle: parseInt($('#max-rotation').val()),
            color_jitter: $('#enable-color-jitter').prop('checked'),
            brightness: $('#enable-brightness').prop('checked'),
            contrast: $('#enable-contrast').prop('checked'),
            noise: $('#enable-noise').prop('checked'),
            noise_type: $('#noise-type').val()
        };
        
        // Show progress and set processing state
        isProcessing = true;
        $('#process-progress').removeClass('d-none');
        $('.progress-bar').css('width', '0%');
        
        // Disable form controls
        $('#process-form :input').prop('disabled', true);
        
        // Show processing message
        showToast('Processing images. This may take a few minutes...', 'info');
        
        // Process images with AJAX
        $.ajax({
            url: '/process',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                session_id: sessionId,
                label_type: labelType,
                output_format: outputFormat,
                selected_classes: selectedClasses,
                global_threshold: globalThreshold,
                class_thresholds: classThresholds,
                preprocessing_options: preprocessingOptions,
                postprocessing_options: postprocessingOptions,
                enable_cropping: enableCropping,
                crop_min_score: cropMinScore,
                crop_padding: cropPadding,
                enable_augmentation: enableAugmentation,
                augmentation_options: augmentationOptions
            }),
            xhr: function() {
                const xhr = new window.XMLHttpRequest();
                
                // Set up progress monitoring
                let progressInterval = setInterval(function() {
                    $.ajax({
                        url: `/progress/${sessionId}`,
                        type: 'GET',
                        success: function(progressData) {
                            if (progressData.progress) {
                                $('.progress-bar').css('width', progressData.progress + '%');
                                
                                // Update status message
                                if (progressData.status) {
                                    $('#process-status').text(progressData.status);
                                }
                                
                                // If complete, clear interval
                                if (progressData.progress >= 100) {
                                    clearInterval(progressInterval);
                                }
                            }
                        }
                    });
                }, 1000);
                
                return xhr;
            },
            success: function(response) {
                // Update download button
                $('#download-btn').attr('href', response.download_url);
                
                // Store results
                processedResults = response.results;
                
                // Display results with animation
                displayResults(processedResults);
                
                // Enable results tab and switch to it
                $('#results-tab').prop('disabled', false);
                setTimeout(() => {
                    $('#results-tab').tab('show');
                }, 500);
                
                // Show success message
                showToast('Processing complete! You can now view and download the results.', 'success');
            },
            error: function(xhr) {
                const response = xhr.responseJSON || { error: 'An error occurred during processing.' };
                showToast(response.error, 'danger');
            },
            complete: function() {
                // Reset processing state
                isProcessing = false;
                
                // Enable form controls
                $('#process-form :input').prop('disabled', false);
                
                // Hide progress after a delay
                setTimeout(function() {
                    $('#process-progress').addClass('d-none');
                }, 1000);
            }
        });
    });
    
    // Real-time threshold updates
    $('#global-threshold').on('input', function() {
        const value = $(this).val();
        $('#global-threshold-value').text(value);
        
        // Update all class thresholds to match global
        $('.class-threshold').val(value);
        $('.threshold-value').text(value);
        
        // Update visualization with debounce
        clearTimeout(thresholdUpdateTimeout);
        thresholdUpdateTimeout = setTimeout(function() {
            updateVisualizationWithThresholds();
        }, 300);
    });
    
    // Individual class threshold updates
    $(document).on('input', '.class-threshold', function() {
        const value = $(this).val();
        $(this).prev().find('.threshold-value').text(value);
        
        // Update visualization with debounce
        clearTimeout(thresholdUpdateTimeout);
        thresholdUpdateTimeout = setTimeout(function() {
            updateVisualizationWithThresholds();
        }, 300);
    });
    
    // Class filter updates
    $(document).on('change', '.class-checkbox', function() {
        // Update visualization
        updateVisualizationWithFilters();
    });
    
    // Select all classes checkbox
    $('#select-all-classes').on('change', function() {
        const isChecked = $(this).prop('checked');
        $('.class-checkbox').prop('checked', isChecked);
        
        // Update visualization
        updateVisualizationWithFilters();
    });
}

// Interactive editing features
function initInteractiveEditing() {
    // Initialize canvas events for label editing
    $('#edit-canvas').on('mousedown', handleCanvasMouseDown);
    $('#edit-canvas').on('mousemove', handleCanvasMouseMove);
    $('#edit-canvas').on('mouseup', handleCanvasMouseUp);
    
    // Tool selection
    $('#tool-select, #tool-move, #tool-resize, #tool-delete, #tool-add').on('click', function() {
        const tool = $(this).attr('id').replace('tool-', '');
        setCurrentTool(tool);
    });
    
    // Apply changes button
    $('#apply-changes').on('click', function() {
        applyObjectChanges();
        
        // Show animation
        $(this).addClass('btn-flash');
        setTimeout(() => {
            $(this).removeClass('btn-flash');
        }, 500);
    });
    
    // Save edits button with animation
    $('#save-edits-btn').on('click', function() {
        // Show spinner
        const originalText = $(this).html();
        $(this).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...');
        $(this).prop('disabled', true);
        
        // Save edits
        saveEdits().then(() => {
            // Show success animation
            $(this).html('<i class="bi bi-check-circle"></i> Saved!');
            setTimeout(() => {
                $(this).html(originalText);
                $(this).prop('disabled', false);
            }, 1500);
        }).catch(() => {
            // Show error animation
            $(this).html('<i class="bi bi-x-circle"></i> Error!');
            setTimeout(() => {
                $(this).html(originalText);
                $(this).prop('disabled', false);
            }, 1500);
        });
    });
    
    // Image selector with smooth transitions
    $('#image-selector').on('change', function() {
        const imageIndex = parseInt($(this).val());
        if (!isNaN(imageIndex) && imageIndex >= 0 && imageIndex < processedResults.length) {
            // Fade out current image
            $('#editor-container').addClass('loading');
            
            // Load new image after fade
            setTimeout(() => {
                loadImageForEditing(imageIndex);
                
                // Fade in new image
                setTimeout(() => {
                    $('#editor-container').removeClass('loading');
                }, 300);
            }, 300);
        }
    });
    
    // Real-time object property updates
    $('#object-confidence').on('input', function() {
        const value = $(this).val();
        $('#object-confidence-value').text(value);
        
        // Preview change in real-time
        previewObjectChange('confidence', value);
    });
    
    $('#box-x, #box-y, #box-width, #box-height').on('input', function() {
        // Preview change in real-time
        previewBoxChange();
    });
    
    $('#object-class').on('change', function() {
        // Preview change in real-time
        previewObjectChange('class', $(this).val());
    });
}

// Real-time UI updates
function initRealTimeUpdates() {
    // Label type change triggers class list update
    $('input[name="label_type"]').on('change', function() {
        // Show loading animation
        $('#class-filter-container').html(`
            <div class="text-center p-3">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Loading available classes...</p>
            </div>
        `);
        
        // Fetch available classes
        fetchAvailableClasses();
        
        // Update preprocessing/postprocessing options based on label type
        updateProcessingOptions($(this).val());
    });
    
    // Toggle preprocessing options
    $('#preprocessing-toggle').on('change', function() {
        const isEnabled = $(this).prop('checked');
        $('#preprocessing-options').toggleClass('d-none', !isEnabled);
    });
    
    // Toggle postprocessing options
    $('#postprocessing-toggle').on('change', function() {
        const isEnabled = $(this).prop('checked');
        $('#postprocessing-options').toggleClass('d-none', !isEnabled);
    });
    
    // Toggle cropping options
    $('#enable-cropping').on('change', function() {
        const isEnabled = $(this).prop('checked');
        $('#cropping-options').toggleClass('d-none', !isEnabled);
    });
    
    // Toggle augmentation options
    $('#enable-augmentation').on('change', function() {
        const isEnabled = $(this).prop('checked');
        $('#augmentation-options').toggleClass('d-none', !isEnabled);
    });
    
    // Real-time crop parameter updates
    $('#crop-min-score').on('input', function() {
        const value = $(this).val();
        $('#crop-min-score-value').text(value);
    });
    
    $('#crop-padding').on('input', function() {
        const value = $(this).val();
        $('#crop-padding-value').text(value);
    });
    
    // Real-time resize dimension updates
    $('#resize-width, #resize-height').on('input', function() {
        updateResizePreview();
    });
    
    // Real-time blur kernel updates
    $('#blur-kernel').on('input', function() {
        const value = $(this).val();
        $('#blur-kernel-value').text(value);
    });
    
    // Real-time NMS threshold updates
    $('#nms-threshold').on('input', function() {
        const value = $(this).val();
        $('#nms-threshold-value').text(value);
    });
    
    // Real-time morphology kernel updates
    $('#morph-kernel').on('input', function() {
        const value = $(this).val();
        $('#morph-kernel-value').text(value);
    });
    
    // Real-time rotation angle updates
    $('#max-rotation').on('input', function() {
        const value = $(this).val();
        $('#max-rotation-value').text(value);
    });
}

// Responsive workflow transitions
function initWorkflowTransitions() {
    // Tab change animations
    $('.nav-tabs .nav-link').on('click', function() {
        if (!$(this).hasClass('active') && !$(this).prop('disabled')) {
            const targetId = $(this).attr('data-bs-target');
            
            // Fade out current tab
            $('.tab-pane.active').addClass('fade-out');
            
            // Fade in new tab after delay
            setTimeout(() => {
                $('.tab-pane').removeClass('fade-out');
                $(targetId).addClass('fade-in');
                
                setTimeout(() => {
                    $(targetId).removeClass('fade-in');
                }, 300);
            }, 300);
        }
    });
    
    // New session button with confirmation
    $('#new-session-btn').on('click', function() {
        // Show confirmation modal
        $('#confirm-new-session-modal').modal('show');
    });
    
    // Confirm new session
    $('#confirm-new-session').on('click', function() {
        // Hide modal
        $('#confirm-new-session-modal').modal('hide');
        
        // Clean up current session
        if (sessionId) {
            $.ajax({
                url: `/cleanup/${sessionId}`,
                type: 'POST',
                complete: function() {
                    resetUI();
                }
            });
        } else {
            resetUI();
        }
    });
    
    // Edit labels button
    $('#edit-labels-btn').on('click', function() {
        // Enable edit tab and switch to it with animation
        $('#edit-tab').prop('disabled', false);
        
        // Show loading animation
        $('#editor-container').addClass('loading');
        
        // Initialize editor
        initializeEditor();
        
        // Switch to edit tab
        setTimeout(() => {
            $('#edit-tab').tab('show');
            
            // Remove loading after transition
            setTimeout(() => {
                $('#editor-container').removeClass('loading');
            }, 500);
        }, 300);
    });
    
    // Back to results button
    $('#back-to-results-btn').on('click', function() {
        // Switch to results tab with animation
        $('.tab-pane.active').addClass('fade-out');
        
        setTimeout(() => {
            $('#results-tab').tab('show');
            $('.tab-pane').removeClass('fade-out');
            $('#results-tab-content').addClass('fade-in');
            
            setTimeout(() => {
                $('#results-tab-content').removeClass('fade-in');
            }, 300);
        }, 300);
    });
    
    // Save project button
    $('#save-project-btn').on('click', function() {
        // Show save project modal
        $('#save-project-modal').modal('show');
    });
    
    // Load project button
    $('#load-project-btn').on('click', function() {
        // Show load project modal
        $('#load-project-modal').modal('show');
        
        // Load project list
        loadProjectList();
    });
}

// Toast notifications
function initToastNotifications() {
    // Create toast container if it doesn't exist
    if ($('#toast-container').length === 0) {
        $('body').append(`
            <div id="toast-container" class="toast-container position-fixed bottom-0 end-0 p-3"></div>
        `);
    }
}

// Show toast notification
function showToast(message, type = 'info') {
    const toastId = 'toast-' + Date.now();
    const toast = $(`
        <div id="${toastId}" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-${type} text-white">
                <strong class="me-auto">Notification</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>
    `);
    
    $('#toast-container').append(toast);
    
    const bsToast = new bootstrap.Toast(toast, {
        autohide: true,
        delay: 5000
    });
    
    bsToast.show();
    
    // Remove toast from DOM after it's hidden
    toast.on('hidden.bs.toast', function() {
        $(this).remove();
    });
}

// Collapsible panels
function initCollapsiblePanels() {
    $('.collapse-toggle').on('click', function() {
        const target = $(this).data('bs-target');
        const isCollapsed = $(target).hasClass('show');
        
        // Animate icon rotation
        if (isCollapsed) {
            $(this).find('.collapse-icon').removeClass('rotate-180');
        } else {
            $(this).find('.collapse-icon').addClass('rotate-180');
        }
    });
}

// Modal dialogs
function initModalDialogs() {
    // Custom model upload modal
    $('#upload-model-btn').on('click', function() {
        $('#upload-model-modal').modal('show');
    });
    
    // Model upload form submission
    $('#upload-model-form').on('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        // Show loading state
        $('#upload-model-btn').prop('disabled', true);
        $('#upload-model-btn').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...');
        
        // Upload model
        $.ajax({
            url: '/upload_model',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                // Show success message
                showToast('Model uploaded successfully!', 'success');
                
                // Close modal
                $('#upload-model-modal').modal('hide');
                
                // Refresh model list
                loadModelList();
            },
            error: function(xhr) {
                const response = xhr.responseJSON || { error: 'An error occurred during model upload.' };
                showToast(response.error, 'danger');
            },
            complete: function() {
                // Reset button state
                $('#upload-model-btn').prop('disabled', false);
                $('#upload-model-btn').html('Upload Model');
            }
        });
    });
    
    // Save project form submission
    $('#save-project-form').on('submit', function(e) {
        e.preventDefault();
        
        const projectName = $('#project-name').val();
        const projectDescription = $('#project-description').val();
        
        if (!projectName) {
            showToast('Please enter a project name.', 'danger');
            return;
        }
        
        // Show loading state
        $('#save-project-submit').prop('disabled', true);
        $('#save-project-submit').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...');
        
        // Save project
        $.ajax({
            url: '/save_project',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                session_id: sessionId,
                name: projectName,
                description: projectDescription
            }),
            success: function(response) {
                // Show success message
                showToast('Project saved successfully!', 'success');
                
                // Close modal
                $('#save-project-modal').modal('hide');
                
                // Update current project
                currentProject = response.project_id;
            },
            error: function(xhr) {
                const response = xhr.responseJSON || { error: 'An error occurred while saving the project.' };
                showToast(response.error, 'danger');
            },
            complete: function() {
                // Reset button state
                $('#save-project-submit').prop('disabled', false);
                $('#save-project-submit').html('Save Project');
            }
        });
    });
}

// Fetch available classes with animation
function fetchAvailableClasses() {
    if (!sessionId) return;
    
    const labelType = $('input[name="label_type"]:checked').val();
    
    $.ajax({
        url: '/get_available_classes',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            session_id: sessionId,
            label_type: labelType
        }),
        success: function(response) {
            availableClasses = response.classes || [];
            
            // Update class filters with animation
            updateClassFilters();
            
            // Update class thresholds with animation
            updateClassThresholds();
        },
        error: function(xhr) {
            const response = xhr.responseJSON || { error: 'Failed to fetch available classes.' };
            console.error(response.error);
            
            // Show error in containers
            $('#class-filter-container').html(`
                <div class="alert alert-danger">
                    Failed to load classes: ${response.error}
                </div>
            `);
            
            $('#class-thresholds-container').html(`
                <div class="alert alert-danger">
                    Failed to load classes: ${response.error}
                </div>
            `);
        }
    });
}

// Update class filter checkboxes with animation
function updateClassFilters() {
    const container = $('#class-filter-container');
    container.empty();
    
    if (availableClasses.length === 0) {
        container.html('<div class="text-center text-muted"><small>No classes available</small></div>');
        return;
    }
    
    // Create checkboxes for each class
    availableClasses.forEach(function(classInfo, index) {
        const checkbox = $(`
            <div class="form-check class-item">
                <input class="form-check-input class-checkbox" type="checkbox" id="class-${classInfo.id}" value="${classInfo.id}" checked>
                <label class="form-check-label" for="class-${classInfo.id}">
                    ${classInfo.name} <span class="badge bg-secondary">${classInfo.count}</span>
                </label>
            </div>
        `);
        
        container.append(checkbox);
        
        // Add fade-in animation
        setTimeout(() => {
            checkbox.addClass('show');
        }, index * 50);
    });
    
    // Update selected classes
    selectedClasses = availableClasses.map(c => c.id);
}

// Update class threshold sliders with animation
function updateClassThresholds() {
    const container = $('#class-thresholds-container');
    container.empty();
    
    if (availableClasses.length === 0) {
        container.html('<div class="text-center text-muted"><small>No classes available</small></div>');
        return;
    }
    
    // Get global threshold
    const globalThreshold = parseFloat($('#global-threshold').val());
    
    // Create sliders for each class
    availableClasses.forEach(function(classInfo, index) {
        const slider = $(`
            <div class="mb-2 threshold-item">
                <label for="threshold-${classInfo.id}" class="form-label d-flex justify-content-between">
                    <span>${classInfo.name}</span>
                    <span class="threshold-value">${globalThreshold}</span>
                </label>
                <input type="range" class="form-range class-threshold" id="threshold-${classInfo.id}" 
                       data-class-id="${classInfo.id}" min="0" max="1" step="0.05" value="${globalThreshold}">
            </div>
        `);
        
        container.append(slider);
        
        // Add fade-in animation
        setTimeout(() => {
            slider.addClass('show');
        }, index * 50);
    });
    
    // Add event listeners for threshold changes
    $('.class-threshold').on('input', function() {
        const value = $(this).val();
        $(this).prev().find('.threshold-value').text(value);
        
        // Update visualization with debounce
        clearTimeout(thresholdUpdateTimeout);
        thresholdUpdateTimeout = setTimeout(function() {
            updateVisualizationWithThresholds();
        }, 300);
    });
}

// Update visualization based on thresholds
function updateVisualizationWithThresholds() {
    if (!sessionId || !processedResults) return;
    
    // Get threshold values
    const globalThreshold = parseFloat($('#global-threshold').val());
    const classThresholds = {};
    $('.class-threshold').each(function() {
        const classId = $(this).data('class-id');
        const threshold = parseFloat($(this).val());
        classThresholds[classId] = threshold;
    });
    
    // Show loading overlay
    $('#results-container').addClass('loading');
    
    // Update visualization
    $.ajax({
        url: '/update_visualization',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            session_id: sessionId,
            global_threshold: globalThreshold,
            class_thresholds: classThresholds
        }),
        success: function(response) {
            // Update results
            processedResults = response.results;
            
            // Display updated results
            displayResults(processedResults);
            
            // Show success message
            showToast('Visualization updated with new thresholds.', 'success');
        },
        error: function(xhr) {
            const response = xhr.responseJSON || { error: 'Failed to update visualization.' };
            showToast(response.error, 'danger');
        },
        complete: function() {
            // Hide loading overlay
            $('#results-container').removeClass('loading');
        }
    });
}

// Update visualization based on class filters
function updateVisualizationWithFilters() {
    if (!sessionId || !processedResults) return;
    
    // Get selected classes
    const selectedClasses = [];
    $('.class-checkbox:checked').each(function() {
        selectedClasses.push(parseInt($(this).val()));
    });
    
    // Show loading overlay
    $('#results-container').addClass('loading');
    
    // Update visualization
    $.ajax({
        url: '/update_visualization',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            session_id: sessionId,
            selected_classes: selectedClasses
        }),
        success: function(response) {
            // Update results
            processedResults = response.results;
            
            // Display updated results
            displayResults(processedResults);
            
            // Show success message
            showToast('Visualization updated with selected classes.', 'success');
        },
        error: function(xhr) {
            const response = xhr.responseJSON || { error: 'Failed to update visualization.' };
            showToast(response.error, 'danger');
        },
        complete: function() {
            // Hide loading overlay
            $('#results-container').removeClass('loading');
        }
    });
}

// Display results with animation
function displayResults(results) {
    const container = $('#results-container');
    container.empty();
    
    if (results.length === 0) {
        container.html('<div class="alert alert-info">No results to display.</div>');
        return;
    }
    
    // Create result cards
    results.forEach(function(result, index) {
        const resultCard = $(`
            <div class="card mb-4 result-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span>${result.filename}</span>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-outline-primary edit-result-btn" data-index="${index}">
                            <i class="bi bi-pencil"></i> Edit
                        </button>
                        <button class="btn btn-sm btn-outline-secondary crop-result-btn" data-index="${index}">
                            <i class="bi bi-crop"></i> Crop Objects
                        </button>
                    </div>
                </div>
                <div class="card-body result-visualization">
                    ${result.visualization}
                </div>
            </div>
        `);
        
        container.append(resultCard);
        
        // Add fade-in animation
        setTimeout(() => {
            resultCard.addClass('show');
        }, index * 100);
        
        // Add event listeners for edit and crop buttons
        resultCard.find('.edit-result-btn').on('click', function() {
            const imageIndex = $(this).data('index');
            
            // Enable edit tab
            $('#edit-tab').prop('disabled', false);
            
            // Initialize editor
            initializeEditor();
            
            // Set image selector to this image
            $('#image-selector').val(imageIndex);
            
            // Load image for editing
            loadImageForEditing(imageIndex);
            
            // Switch to edit tab
            $('#edit-tab').tab('show');
        });
        
        resultCard.find('.crop-result-btn').on('click', function() {
            const imageIndex = $(this).data('index');
            
            // Show crop objects modal
            $('#crop-objects-modal').modal('show');
            
            // Set current image index
            $('#crop-objects-form').data('image-index', imageIndex);
            
            // Set image preview
            $('#crop-image-preview').html(`<img src="data:image/jpeg;base64,${result.image_data}" class="img-fluid" alt="${result.filename}">`);
            
            // Set filename
            $('#crop-filename').text(result.filename);
        });
    });
}

// Update processing options based on label type
function updateProcessingOptions(labelType) {
    // Show/hide options based on label type
    if (labelType === 'semantic') {
        // Semantic segmentation
        $('.bbox-only, .instance-only').addClass('d-none');
        $('.semantic-only').removeClass('d-none');
    } else if (labelType === 'instance') {
        // Instance segmentation
        $('.semantic-only').addClass('d-none');
        $('.bbox-only, .instance-only').removeClass('d-none');
    } else if (labelType === 'bbox') {
        // Bounding box detection
        $('.semantic-only, .instance-only').addClass('d-none');
        $('.bbox-only').removeClass('d-none');
    }
}

// Update resize preview
function updateResizePreview() {
    const width = $('#resize-width').val();
    const height = $('#resize-height').val();
    
    $('#resize-preview').text(`${width} × ${height}`);
    
    // Update aspect ratio indicator
    const aspectRatio = width / height;
    let aspectRatioText = '';
    
    if (Math.abs(aspectRatio - 1) < 0.01) {
        aspectRatioText = 'Square (1:1)';
    } else if (Math.abs(aspectRatio - 4/3) < 0.01) {
        aspectRatioText = '4:3';
    } else if (Math.abs(aspectRatio - 16/9) < 0.01) {
        aspectRatioText = '16:9';
    } else {
        aspectRatioText = aspectRatio.toFixed(2);
    }
    
    $('#resize-aspect-ratio').text(aspectRatioText);
}

// Preview object change in real-time
function previewObjectChange(property, value) {
    if (selectedObject === null) return;
    
    // Create a temporary canvas for preview
    const previewCanvas = document.createElement('canvas');
    previewCanvas.width = editCanvas.width;
    previewCanvas.height = editCanvas.height;
    const previewCtx = previewCanvas.getContext('2d');
    
    // Copy current canvas state
    previewCtx.drawImage(editCanvas, 0, 0);
    
    // Apply preview change
    if (property === 'confidence') {
        // Update confidence display
        if (editableData.type === 'bounding_box') {
            editableData.bboxes[selectedObject].score = parseFloat(value);
        } else if (editableData.type === 'instance_segmentation') {
            editableData.instances[selectedObject].score = parseFloat(value);
        }
    } else if (property === 'class') {
        // Update class
        const classId = parseInt(value);
        const className = availableClasses.find(c => c.id === classId)?.name || 'Unknown';
        
        if (editableData.type === 'bounding_box') {
            editableData.bboxes[selectedObject].label = classId;
            editableData.bboxes[selectedObject].class_name = className;
        } else if (editableData.type === 'instance_segmentation') {
            editableData.instances[selectedObject].label = classId;
            editableData.instances[selectedObject].class_name = className;
        }
    }
    
    // Redraw objects with preview
    drawObjects();
    
    // Add highlight effect
    if (editableData.type === 'bounding_box') {
        const box = editableData.bboxes[selectedObject].box;
        editCtx.save();
        editCtx.strokeStyle = 'rgba(255, 255, 0, 0.8)';
        editCtx.lineWidth = 2;
        editCtx.setLineDash([5, 5]);
        editCtx.strokeRect(box[0], box[1], box[2] - box[0], box[3] - box[1]);
        editCtx.restore();
    } else if (editableData.type === 'instance_segmentation') {
        const box = editableData.instances[selectedObject].box;
        editCtx.save();
        editCtx.strokeStyle = 'rgba(255, 255, 0, 0.8)';
        editCtx.lineWidth = 2;
        editCtx.setLineDash([5, 5]);
        editCtx.strokeRect(box[0], box[1], box[2] - box[0], box[3] - box[1]);
        editCtx.restore();
    }
}

// Preview box change in real-time
function previewBoxChange() {
    if (selectedObject === null) return;
    
    const x = parseInt($('#box-x').val());
    const y = parseInt($('#box-y').val());
    const width = parseInt($('#box-width').val());
    const height = parseInt($('#box-height').val());
    
    // Validate values
    if (isNaN(x) || isNaN(y) || isNaN(width) || isNaN(height)) return;
    if (width <= 0 || height <= 0) return;
    
    // Update box
    const newBox = [
        Math.max(0, x),
        Math.max(0, y),
        Math.min(canvas.width, x + width),
        Math.min(canvas.height, y + height)
    ];
    
    // Apply to data
    if (editableData.type === 'bounding_box') {
        editableData.bboxes[selectedObject].box = newBox;
    } else if (editableData.type === 'instance_segmentation') {
        editableData.instances[selectedObject].box = newBox;
    }
    
    // Redraw objects
    drawObjects();
    
    // Add highlight effect
    editCtx.save();
    editCtx.strokeStyle = 'rgba(255, 255, 0, 0.8)';
    editCtx.lineWidth = 2;
    editCtx.setLineDash([5, 5]);
    editCtx.strokeRect(newBox[0], newBox[1], newBox[2] - newBox[0], newBox[3] - newBox[1]);
    editCtx.restore();
}

// Load model list
function loadModelList() {
    // Show loading state
    $('#model-list').html(`
        <div class="text-center p-3">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Loading models...</p>
        </div>
    `);
    
    // Fetch models
    $.ajax({
        url: '/list_models',
        type: 'GET',
        success: function(response) {
            const models = response.models || [];
            
            if (models.length === 0) {
                $('#model-list').html(`
                    <div class="alert alert-info">
                        No custom models available. Upload a model to get started.
                    </div>
                `);
                return;
            }
            
            // Create model list
            const modelList = $('<div class="list-group"></div>');
            
            models.forEach(function(model, index) {
                const modelItem = $(`
                    <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center model-item">
                        <div>
                            <h6 class="mb-1">${model.name}</h6>
                            <small class="text-muted">Type: ${model.type}</small>
                        </div>
                        <div class="btn-group">
                            <button class="btn btn-sm btn-outline-primary select-model-btn" data-model-id="${model.id}">
                                Select
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete-model-btn" data-model-id="${model.id}">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                    </div>
                `);
                
                modelList.append(modelItem);
                
                // Add fade-in animation
                setTimeout(() => {
                    modelItem.addClass('show');
                }, index * 100);
            });
            
            $('#model-list').empty().append(modelList);
            
            // Add event listeners
            $('.select-model-btn').on('click', function() {
                const modelId = $(this).data('model-id');
                selectModel(modelId);
            });
            
            $('.delete-model-btn').on('click', function() {
                const modelId = $(this).data('model-id');
                
                // Show confirmation modal
                $('#confirm-delete-model-modal').modal('show');
                $('#confirm-delete-model').data('model-id', modelId);
            });
        },
        error: function(xhr) {
            const response = xhr.responseJSON || { error: 'Failed to load models.' };
            $('#model-list').html(`
                <div class="alert alert-danger">
                    ${response.error}
                </div>
            `);
        }
    });
}

// Load project list
function loadProjectList() {
    // Show loading state
    $('#project-list').html(`
        <div class="text-center p-3">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Loading projects...</p>
        </div>
    `);
    
    // Fetch projects
    $.ajax({
        url: '/list_projects',
        type: 'GET',
        success: function(response) {
            const projects = response.projects || [];
            
            if (projects.length === 0) {
                $('#project-list').html(`
                    <div class="alert alert-info">
                        No saved projects available. Process some images and save a project to get started.
                    </div>
                `);
                return;
            }
            
            // Create project list
            const projectList = $('<div class="list-group"></div>');
            
            projects.forEach(function(project, index) {
                const date = new Date(project.updated_at);
                const formattedDate = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
                
                const projectItem = $(`
                    <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center project-item">
                        <div>
                            <h6 class="mb-1">${project.name}</h6>
                            <small class="text-muted">Updated: ${formattedDate}</small>
                            <p class="mb-1 text-truncate" style="max-width: 400px;">${project.description || ''}</p>
                        </div>
                        <div class="btn-group">
                            <button class="btn btn-sm btn-outline-primary load-project-btn" data-project-id="${project.id}">
                                Load
                            </button>
                            <button class="btn btn-sm btn-outline-secondary export-project-btn" data-project-id="${project.id}">
                                <i class="bi bi-download"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete-project-btn" data-project-id="${project.id}">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                    </div>
                `);
                
                projectList.append(projectItem);
                
                // Add fade-in animation
                setTimeout(() => {
                    projectItem.addClass('show');
                }, index * 100);
            });
            
            $('#project-list').empty().append(projectList);
            
            // Add event listeners
            $('.load-project-btn').on('click', function() {
                const projectId = $(this).data('project-id');
                loadProject(projectId);
            });
            
            $('.export-project-btn').on('click', function() {
                const projectId = $(this).data('project-id');
                exportProject(projectId);
            });
            
            $('.delete-project-btn').on('click', function() {
                const projectId = $(this).data('project-id');
                
                // Show confirmation modal
                $('#confirm-delete-project-modal').modal('show');
                $('#confirm-delete-project').data('project-id', projectId);
            });
        },
        error: function(xhr) {
            const response = xhr.responseJSON || { error: 'Failed to load projects.' };
            $('#project-list').html(`
                <div class="alert alert-danger">
                    ${response.error}
                </div>
            `);
        }
    });
}

// Reset UI with animation
function resetUI() {
    // Reset session
    sessionId = null;
    availableClasses = [];
    selectedClasses = [];
    classThresholds = {};
    globalThreshold = 0.7;
    enableCropping = false;
    cropMinScore = 0.5;
    cropPadding = 10;
    processedResults = [];
    editableData = {};
    currentImageIndex = -1;
    selectedObject = null;
    currentProject = null;
    
    // Reset forms with animation
    $('#upload-form')[0].reset();
    $('#process-form')[0].reset();
    
    // Fade out results and previews
    $('#results-container, #image-previews').fadeOut(300, function() {
        // Clear containers
        $(this).empty().show();
    });
    
    // Reset tabs with animation
    $('#process-tab, #results-tab, #edit-tab').prop('disabled', true);
    
    // Switch to upload tab with animation
    $('.tab-pane.active').addClass('fade-out');
    setTimeout(() => {
        $('#upload-tab').tab('show');
        $('.tab-pane').removeClass('fade-out');
        $('#upload-tab-content').addClass('fade-in');
        setTimeout(() => {
            $('#upload-tab-content').removeClass('fade-in');
        }, 300);
    }, 300);
    
    // Reset alerts
    $('#upload-result, #process-result').addClass('d-none');
    
    // Reset download buttons
    $('#download-btn, #download-edited-btn').attr('href', '#');
    
    // Reset class filters and thresholds with animation
    $('#class-filter-container, #class-thresholds-container').fadeOut(300, function() {
        $(this).html('<div class="text-center text-muted"><small>Available classes will appear here after model selection</small></div>').fadeIn(300);
    });
    
    // Reset cropping options
    $('#cropping-options').addClass('d-none');
    
    // Reset editor
    $('#image-selector').empty().append('<option value="">No images available</option>');
    $('#object-properties').addClass('d-none');
    if (canvas) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
    if (editCanvas) {
        editCtx.clearRect(0, 0, editCanvas.width, editCanvas.height);
    }
    
    // Show toast notification
    showToast('Started a new session.', 'info');
}
