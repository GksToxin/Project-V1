"""
Module for evaluating predictions against ground truth labels.
"""

import numpy as np
import cv2
import json
import os
from PIL import Image
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import io
import base64

class EvaluationMetrics:
    """
    Class for computing evaluation metrics between predictions and ground truth.
    """
    
    def __init__(self, prediction_type):
        """
        Initialize the evaluation metrics calculator.
        
        Args:
            prediction_type: Type of predictions (semantic_segmentation, instance_segmentation, bounding_box)
        """
        self.prediction_type = prediction_type
    
    def evaluate(self, predictions, ground_truth):
        """
        Evaluate predictions against ground truth.
        
        Args:
            predictions: Dictionary containing prediction results
            ground_truth: Dictionary containing ground truth labels
            
        Returns:
            Dictionary with evaluation metrics
        """
        if self.prediction_type == 'semantic_segmentation':
            return self._evaluate_semantic(predictions, ground_truth)
        elif self.prediction_type == 'instance_segmentation':
            return self._evaluate_instance(predictions, ground_truth)
        elif self.prediction_type == 'bounding_box':
            return self._evaluate_bbox(predictions, ground_truth)
        else:
            return {'error': 'Unsupported prediction type'}
    
    def _evaluate_semantic(self, predictions, ground_truth):
        """Evaluate semantic segmentation predictions."""
        pred_mask = predictions.get('mask', None)
        gt_mask = ground_truth.get('mask', None)
        
        if pred_mask is None or gt_mask is None:
            return {'error': 'Missing mask data'}
        
        # Ensure masks have the same shape
        if pred_mask.shape != gt_mask.shape:
            # Resize ground truth mask to match prediction mask
            gt_mask = cv2.resize(gt_mask, (pred_mask.shape[1], pred_mask.shape[0]), 
                                interpolation=cv2.INTER_NEAREST)
        
        # Get unique classes
        classes = np.unique(np.concatenate([np.unique(pred_mask), np.unique(gt_mask)]))
        classes = classes[classes != 0]  # Remove background class
        
        # Calculate metrics for each class
        class_metrics = {}
        overall_iou = 0
        overall_dice = 0
        overall_precision = 0
        overall_recall = 0
        
        for class_id in classes:
            # Create binary masks for this class
            pred_binary = (pred_mask == class_id).astype(np.uint8)
            gt_binary = (gt_mask == class_id).astype(np.uint8)
            
            # Calculate metrics
            intersection = np.logical_and(pred_binary, gt_binary).sum()
            union = np.logical_or(pred_binary, gt_binary).sum()
            
            iou = intersection / union if union > 0 else 0
            dice = 2 * intersection / (pred_binary.sum() + gt_binary.sum()) if (pred_binary.sum() + gt_binary.sum()) > 0 else 0
            
            true_positives = intersection
            false_positives = pred_binary.sum() - intersection
            false_negatives = gt_binary.sum() - intersection
            
            precision = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0
            recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0
            
            # Store metrics for this class
            class_metrics[int(class_id)] = {
                'iou': float(iou),
                'dice': float(dice),
                'precision': float(precision),
                'recall': float(recall)
            }
            
            # Accumulate for overall metrics
            overall_iou += iou
            overall_dice += dice
            overall_precision += precision
            overall_recall += recall
        
        # Calculate overall metrics
        num_classes = len(classes)
        if num_classes > 0:
            overall_iou /= num_classes
            overall_dice /= num_classes
            overall_precision /= num_classes
            overall_recall /= num_classes
        
        # Calculate pixel accuracy
        pixel_accuracy = (pred_mask == gt_mask).sum() / pred_mask.size
        
        # Create visualization
        visualization = self._create_semantic_visualization(pred_mask, gt_mask)
        
        return {
            'overall': {
                'iou': float(overall_iou),
                'dice': float(overall_dice),
                'precision': float(precision),
                'recall': float(recall),
                'pixel_accuracy': float(pixel_accuracy)
            },
            'class_metrics': class_metrics,
            'visualization': visualization
        }
    
    def _evaluate_instance(self, predictions, ground_truth):
        """Evaluate instance segmentation predictions."""
        pred_boxes = predictions.get('boxes', [])
        pred_masks = predictions.get('masks', [])
        pred_labels = predictions.get('labels', [])
        pred_scores = predictions.get('scores', [])
        
        gt_boxes = ground_truth.get('boxes', [])
        gt_masks = ground_truth.get('masks', [])
        gt_labels = ground_truth.get('labels', [])
        
        if not pred_boxes or not gt_boxes:
            return {'error': 'Missing box data'}
        
        # Get unique classes
        all_labels = np.unique(np.concatenate([pred_labels, gt_labels]))
        
        # Calculate metrics for each class
        class_metrics = {}
        overall_map = 0
        overall_precision = 0
        overall_recall = 0
        
        for class_id in all_labels:
            # Filter predictions and ground truth for this class
            pred_indices = [i for i, label in enumerate(pred_labels) if label == class_id]
            gt_indices = [i for i, label in enumerate(gt_labels) if label == class_id]
            
            class_pred_boxes = [pred_boxes[i] for i in pred_indices]
            class_pred_scores = [pred_scores[i] for i in pred_indices]
            class_gt_boxes = [gt_boxes[i] for i in gt_indices]
            
            # Calculate mAP for this class
            ap = self._calculate_average_precision(class_pred_boxes, class_pred_scores, class_gt_boxes)
            
            # Calculate precision and recall
            if pred_masks and gt_masks:
                class_pred_masks = [pred_masks[i] for i in pred_indices]
                class_gt_masks = [gt_masks[i] for i in gt_indices]
                
                precision, recall = self._calculate_mask_precision_recall(class_pred_masks, class_gt_masks)
            else:
                precision, recall = self._calculate_box_precision_recall(class_pred_boxes, class_gt_boxes)
            
            # Store metrics for this class
            class_metrics[int(class_id)] = {
                'ap': float(ap),
                'precision': float(precision),
                'recall': float(recall)
            }
            
            # Accumulate for overall metrics
            overall_map += ap
            overall_precision += precision
            overall_recall += recall
        
        # Calculate overall metrics
        num_classes = len(all_labels)
        if num_classes > 0:
            overall_map /= num_classes
            overall_precision /= num_classes
            overall_recall /= num_classes
        
        # Create visualization
        visualization = self._create_instance_visualization(predictions, ground_truth)
        
        return {
            'overall': {
                'map': float(overall_map),
                'precision': float(overall_precision),
                'recall': float(overall_recall)
            },
            'class_metrics': class_metrics,
            'visualization': visualization
        }
    
    def _evaluate_bbox(self, predictions, ground_truth):
        """Evaluate bounding box predictions."""
        pred_boxes = predictions.get('boxes', [])
        pred_labels = predictions.get('labels', [])
        pred_scores = predictions.get('scores', [])
        
        gt_boxes = ground_truth.get('boxes', [])
        gt_labels = ground_truth.get('labels', [])
        
        if not pred_boxes or not gt_boxes:
            return {'error': 'Missing box data'}
        
        # Get unique classes
        all_labels = np.unique(np.concatenate([pred_labels, gt_labels]))
        
        # Calculate metrics for each class
        class_metrics = {}
        overall_map = 0
        overall_precision = 0
        overall_recall = 0
        
        for class_id in all_labels:
            # Filter predictions and ground truth for this class
            pred_indices = [i for i, label in enumerate(pred_labels) if label == class_id]
            gt_indices = [i for i, label in enumerate(gt_labels) if label == class_id]
            
            class_pred_boxes = [pred_boxes[i] for i in pred_indices]
            class_pred_scores = [pred_scores[i] for i in pred_indices]
            class_gt_boxes = [gt_boxes[i] for i in gt_indices]
            
            # Calculate mAP for this class
            ap = self._calculate_average_precision(class_pred_boxes, class_pred_scores, class_gt_boxes)
            
            # Calculate precision and recall
            precision, recall = self._calculate_box_precision_recall(class_pred_boxes, class_gt_boxes)
            
            # Store metrics for this class
            class_metrics[int(class_id)] = {
                'ap': float(ap),
                'precision': float(precision),
                'recall': float(recall)
            }
            
            # Accumulate for overall metrics
            overall_map += ap
            overall_precision += precision
            overall_recall += recall
        
        # Calculate overall metrics
        num_classes = len(all_labels)
        if num_classes > 0:
            overall_map /= num_classes
            overall_precision /= num_classes
            overall_recall /= num_classes
        
        # Create visualization
        visualization = self._create_bbox_visualization(predictions, ground_truth)
        
        return {
            'overall': {
                'map': float(overall_map),
                'precision': float(overall_precision),
                'recall': float(overall_recall)
            },
            'class_metrics': class_metrics,
            'visualization': visualization
        }
    
    def _calculate_average_precision(self, pred_boxes, pred_scores, gt_boxes, iou_threshold=0.5):
        """Calculate Average Precision for object detection."""
        if not pred_boxes or not gt_boxes:
            return 0.0
        
        # Sort predictions by score
        sorted_indices = np.argsort(pred_scores)[::-1]
        pred_boxes = [pred_boxes[i] for i in sorted_indices]
        pred_scores = [pred_scores[i] for i in sorted_indices]
        
        # Initialize variables
        num_predictions = len(pred_boxes)
        num_gt = len(gt_boxes)
        
        if num_gt == 0:
            return 0.0
        
        # Create arrays for true positives and false positives
        tp = np.zeros(num_predictions)
        fp = np.zeros(num_predictions)
        
        # Create array to track which ground truth boxes have been matched
        gt_matched = np.zeros(num_gt, dtype=bool)
        
        # Match predictions to ground truth
        for i in range(num_predictions):
            # Find the best matching ground truth box
            best_iou = -1
            best_gt_idx = -1
            
            for j in range(num_gt):
                if gt_matched[j]:
                    continue
                
                iou = self._calculate_iou(pred_boxes[i], gt_boxes[j])
                
                if iou > best_iou:
                    best_iou = iou
                    best_gt_idx = j
            
            # Check if the best match is good enough
            if best_iou >= iou_threshold:
                tp[i] = 1
                gt_matched[best_gt_idx] = True
            else:
                fp[i] = 1
        
        # Compute precision and recall at each detection
        tp_cumsum = np.cumsum(tp)
        fp_cumsum = np.cumsum(fp)
        
        recalls = tp_cumsum / num_gt
        precisions = tp_cumsum / (tp_cumsum + fp_cumsum)
        
        # Add sentinel values to ensure proper AP calculation
        precisions = np.concatenate(([1.0], precisions))
        recalls = np.concatenate(([0.0], recalls))
        
        # Compute average precision using the 11-point interpolation
        ap = 0.0
        for t in np.arange(0.0, 1.1, 0.1):
            if np.sum(recalls >= t) == 0:
                p = 0
            else:
                p = np.max(precisions[recalls >= t])
            ap += p / 11.0
        
        return ap
    
    def _calculate_box_precision_recall(self, pred_boxes, gt_boxes, iou_threshold=0.5):
        """Calculate precision and recall for bounding boxes."""
        if not pred_boxes or not gt_boxes:
            return 0.0, 0.0
        
        num_predictions = len(pred_boxes)
        num_gt = len(gt_boxes)
        
        if num_gt == 0:
            return 0.0, 0.0
        
        # Create array to track which ground truth boxes have been matched
        gt_matched = np.zeros(num_gt, dtype=bool)
        
        # Count true positives
        tp = 0
        
        for i in range(num_predictions):
            # Find the best matching ground truth box
            best_iou = -1
            best_gt_idx = -1
            
            for j in range(num_gt):
                if gt_matched[j]:
                    continue
                
                iou = self._calculate_iou(pred_boxes[i], gt_boxes[j])
                
                if iou > best_iou:
                    best_iou = iou
                    best_gt_idx = j
            
            # Check if the best match is good enough
            if best_iou >= iou_threshold:
                tp += 1
                gt_matched[best_gt_idx] = True
        
        # Calculate precision and recall
        precision = tp / num_predictions if num_predictions > 0 else 0.0
        recall = tp / num_gt if num_gt > 0 else 0.0
        
        return precision, recall
    
    def _calculate_mask_precision_recall(self, pred_masks, gt_masks, iou_threshold=0.5):
        """Calculate precision and recall for masks."""
        if not pred_masks or not gt_masks:
            return 0.0, 0.0
        
        num_predictions = len(pred_masks)
        num_gt = len(gt_masks)
        
        if num_gt == 0:
            return 0.0, 0.0
        
        # Create array to track which ground truth masks have been matched
        gt_matched = np.zeros(num_gt, dtype=bool)
        
        # Count true positives
        tp = 0
        
        for i in range(num_predictions):
            # Find the best matching ground truth mask
            best_iou = -1
            best_gt_idx = -1
            
            for j in range(num_gt):
                if gt_matched[j]:
                    continue
                
                # Calculate IoU between masks
                intersection = np.logical_and(pred_masks[i], gt_masks[j]).sum()
                union = np.logical_or(pred_masks[i], gt_masks[j]).sum()
                iou = intersection / union if union > 0 else 0
                
                if iou > best_iou:
                    best_iou = iou
                    best_gt_idx = j
            
            # Check if the best match is good enough
            if best_iou >= iou_threshold:
                tp += 1
                gt_matched[best_gt_idx] = True
        
        # Calculate precision and recall
        precision = tp / num_predictions if num_predictions > 0 else 0.0
        recall = tp / num_gt if num_gt > 0 else 0.0
        
        return precision, recall
    
    def _calculate_iou(self, box1, box2):
        """Calculate IoU between two bounding boxes."""
        # Convert boxes to [x1, y1, x2, y2] format if needed
        if len(box1) == 4 and len(box2) == 4:
            # Calculate intersection area
            x1 = max(box1[0], box2[0])
            y1 = max(box1[1], box2[1])
            x2 = min(box1[2], box2[2])
            y2 = min(box1[3], box2[3])
            
            intersection = max(0, x2 - x1) * max(0, y2 - y1)
            
            # Calculate union area
            box1_area = (box1[2] - box1[0]) * (box1[3] - box1[1])
            box2_area = (box2[2] - box2[0]) * (box2[3] - box2[1])
            union = box1_area + box2_area - intersection
            
            # Calculate IoU
            iou = intersection / union if union > 0 else 0
            
            return iou
        else:
            return 0.0
    
    def _create_semantic_visualization(self, pred_mask, gt_mask):
        """Create visualization for semantic segmentation evaluation."""
        # Create a colormap for visualization
        colors = [(0, 0, 0), (0, 1, 0), (1, 0, 0), (1, 1, 0)]  # black, green, red, yellow
        cmap = LinearSegmentedColormap.from_list('evaluation_cmap', colors, N=4)
        
        # Create comparison mask
        # 0: background (black)
        # 1: true positive (green)
        # 2: false positive (red)
        # 3: false negative (yellow)
        comparison = np.zeros_like(pred_mask)
        comparison[np.logical_and(pred_mask > 0, gt_mask > 0)] = 1  # true positive
        comparison[np.logical_and(pred_mask > 0, gt_mask == 0)] = 2  # false positive
        comparison[np.logical_and(pred_mask == 0, gt_mask > 0)] = 3  # false negative
        
        # Create figure
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
        
        # Plot ground truth
        axes[0].imshow(gt_mask, cmap='tab20')
        axes[0].set_title('Ground Truth')
        axes[0].axis('off')
        
        # Plot prediction
        axes[1].imshow(pred_mask, cmap='tab20')
        axes[1].set_title('Prediction')
        axes[1].axis('off')
        
        # Plot comparison
        axes[2].imshow(comparison, cmap=cmap)
        axes[2].set_title('Comparison')
        axes[2].axis('off')
        
        # Add legend
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor='green', label='True Positive'),
            Patch(facecolor='red', label='False Positive'),
            Patch(facecolor='yellow', label='False Negative')
        ]
        axes[2].legend(handles=legend_elements, loc='lower right')
        
        # Save figure to base64
        buf = io.BytesIO()
        plt.tight_layout()
        plt.savefig(buf, format='png')
        plt.close(fig)
        
        # Convert to base64
        buf.seek(0)
        img_str = base64.b64encode(buf.read()).decode('utf-8')
        
        return img_str
    
    def _create_instance_visualization(self, predictions, ground_truth):
        """Create visualization for instance segmentation evaluation."""
        # Create figure
        fig, axes = plt.subplots(1, 2, figsize=(12, 6))
        
        # Plot ground truth
        self._plot_instances(axes[0], ground_truth, 'Ground Truth')
        
        # Plot predictions
        self._plot_instances(axes[1], predictions, 'Prediction')
        
        # Save figure to base64
        buf = io.BytesIO()
        plt.tight_layout()
        plt.savefig(buf, format='png')
        plt.close(fig)
        
        # Convert to base64
        buf.seek(0)
        img_str = base64.b64encode(buf.read()).decode('utf-8')
        
        return img_str
    
    def _create_bbox_visualization(self, predictions, ground_truth):
        """Create visualization for bounding box evaluation."""
        # Create figure
        fig, axes = plt.subplots(1, 2, figsize=(12, 6))
        
        # Plot ground truth
        self._plot_boxes(axes[0], ground_truth, 'Ground Truth')
        
        # Plot predictions
        self._plot_boxes(axes[1], predictions, 'Prediction')
        
        # Save figure to base64
        buf = io.BytesIO()
        plt.tight_layout()
        plt.savefig(buf, format='png')
        plt.close(fig)
        
        # Convert to base64
        buf.seek(0)
        img_str = base64.b64encode(buf.read()).decode('utf-8')
        
        return img_str
    
    def _plot_instances(self, ax, data, title):
        """Plot instance segmentation data."""
        # Create a blank image
        height, width = 480, 640  # Default size
        if 'image_height' in data and 'image_width' in data:
            height, width = data['image_height'], data['image_width']
        
        image = np.zeros((height, width, 3), dtype=np.uint8)
        
        # Plot masks
        if 'masks' in data and data['masks']:
            for i, mask in enumerate(data['masks']):
                # Create colored mask
                color = np.random.randint(0, 255, size=3)
                colored_mask = np.zeros((height, width, 3), dtype=np.uint8)
                
                # Ensure mask has correct dimensions
                if mask.shape[:2] != (height, width):
                    mask = cv2.resize(mask, (width, height), interpolation=cv2.INTER_NEAREST)
                
                for c in range(3):
                    colored_mask[:, :, c] = np.where(mask > 0.5, color[c], 0)
                
                # Overlay mask on image
                alpha = 0.5
                image = cv2.addWeighted(image, 1, colored_mask, alpha, 0)
        
        # Plot boxes
        if 'boxes' in data and data['boxes']:
            for i, box in enumerate(data['boxes']):
                x1, y1, x2, y2 = [int(coord) for coord in box]
                cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
                
                # Add label if available
                if 'labels' in data and i < len(data['labels']):
                    label = data['labels'][i]
                    cv2.putText(image, str(label), (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        
        # Display image
        ax.imshow(image)
        ax.set_title(title)
        ax.axis('off')
    
    def _plot_boxes(self, ax, data, title):
        """Plot bounding box data."""
        # Create a blank image
        height, width = 480, 640  # Default size
        if 'image_height' in data and 'image_width' in data:
            height, width = data['image_height'], data['image_width']
        
        image = np.zeros((height, width, 3), dtype=np.uint8)
        
        # Plot boxes
        if 'boxes' in data and data['boxes']:
            for i, box in enumerate(data['boxes']):
                x1, y1, x2, y2 = [int(coord) for coord in box]
                cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
                
                # Add label if available
                if 'labels' in data and i < len(data['labels']):
                    label = data['labels'][i]
                    cv2.putText(image, str(label), (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        
        # Display image
        ax.imshow(image)
        ax.set_title(title)
        ax.axis('off')

class GroundTruthLoader:
    """
    Class for loading ground truth labels from various formats.
    """
    
    @staticmethod
    def load(file_path, format_type, image_info=None):
        """
        Load ground truth labels from a file.
        
        Args:
            file_path: Path to the ground truth file
            format_type: Format of the ground truth file (coco, yolo)
            image_info: Dictionary with image information (optional)
            
        Returns:
            Dictionary with ground truth labels
        """
        if format_type == 'coco':
            return GroundTruthLoader._load_coco(file_path, image_info)
        elif format_type == 'yolo':
            return GroundTruthLoader._load_yolo(file_path, image_info)
        else:
            return {'error': 'Unsupported format type'}
    
    @staticmethod
    def _load_coco(file_path, image_info=None):
        """Load ground truth from COCO format."""
        try:
            with open(file_path, 'r') as f:
                coco_data = json.load(f)
            
            # Find the image in the COCO dataset
            image_id = None
            if image_info and 'file_name' in image_info:
                for img in coco_data.get('images', []):
                    if img.get('file_name') == image_info['file_name']:
                        image_id = img.get('id')
                        break
            
            if image_id is None:
                return {'error': 'Image not found in COCO dataset'}
            
            # Get annotations for this image
            annotations = [ann for ann in coco_data.get('annotations', []) if ann.get('image_id') == image_id]
            
            # Get categories
            categories = {cat.get('id'): cat.get('name') for cat in coco_data.get('categories', [])}
            
            # Process annotations based on type
            if annotations and 'segmentation' in annotations[0]:
                # Instance segmentation or bounding box
                boxes = []
                masks = []
                labels = []
                class_names = []
                
                for ann in annotations:
                    # Get bounding box
                    bbox = ann.get('bbox', [0, 0, 0, 0])
                    x, y, w, h = bbox
                    boxes.append([x, y, x + w, y + h])
                    
                    # Get label
                    category_id = ann.get('category_id', 0)
                    labels.append(category_id)
                    class_names.append(categories.get(category_id, f"Class {category_id}"))
                    
                    # Get segmentation if available
                    if 'segmentation' in ann and ann['segmentation']:
                        # Convert segmentation to mask
                        if image_info and 'width' in image_info and 'height' in image_info:
                            width, height = image_info['width'], image_info['height']
                            mask = np.zeros((height, width), dtype=np.uint8)
                            
                            # Handle different segmentation formats
                            seg = ann['segmentation']
                            if isinstance(seg, list):
                                # Polygon format
                                for polygon in seg:
                                    pts = np.array(polygon).reshape(-1, 2).astype(np.int32)
                                    cv2.fillPoly(mask, [pts], 1)
                            elif isinstance(seg, dict) and 'counts' in seg and 'size' in seg:
                                # RLE format
                                from pycocotools import mask as mask_utils
                                rle = mask_utils.frPyObjects(seg, height, width)
                                mask = mask_utils.decode(rle).astype(np.uint8)
                            
                            masks.append(mask)
                
                if masks:
                    return {
                        'type': 'instance_segmentation',
                        'boxes': boxes,
                        'masks': masks,
                        'labels': labels,
                        'class_names': class_names,
                        'image_width': image_info.get('width') if image_info else None,
                        'image_height': image_info.get('height') if image_info else None
                    }
                else:
                    return {
                        'type': 'bounding_box',
                        'boxes': boxes,
                        'labels': labels,
                        'class_names': class_names,
                        'image_width': image_info.get('width') if image_info else None,
                        'image_height': image_info.get('height') if image_info else None
                    }
            
            else:
                # Semantic segmentation
                # For semantic segmentation, COCO format might not be ideal
                # This is a simplified implementation
                return {'error': 'Semantic segmentation not supported in COCO format'}
        
        except Exception as e:
            return {'error': f'Error loading COCO file: {str(e)}'}
    
    @staticmethod
    def _load_yolo(file_path, image_info=None):
        """Load ground truth from YOLO format."""
        try:
            if not image_info or 'width' not in image_info or 'height' not in image_info:
                return {'error': 'Image information required for YOLO format'}
            
            width, height = image_info['width'], image_info['height']
            
            boxes = []
            labels = []
            
            with open(file_path, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 5:
                        # YOLO format: class x_center y_center width height
                        class_id = int(parts[0])
                        x_center = float(parts[1]) * width
                        y_center = float(parts[2]) * height
                        box_width = float(parts[3]) * width
                        box_height = float(parts[4]) * height
                        
                        # Convert to [x1, y1, x2, y2] format
                        x1 = x_center - box_width / 2
                        y1 = y_center - box_height / 2
                        x2 = x_center + box_width / 2
                        y2 = y_center + box_height / 2
                        
                        boxes.append([x1, y1, x2, y2])
                        labels.append(class_id)
            
            # YOLO format doesn't include class names, so we use generic names
            class_names = [f"Class {label}" for label in labels]
            
            return {
                'type': 'bounding_box',
                'boxes': boxes,
                'labels': labels,
                'class_names': class_names,
                'image_width': width,
                'image_height': height
            }
        
        except Exception as e:
            return {'error': f'Error loading YOLO file: {str(e)}'}
