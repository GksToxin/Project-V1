"""
Module for dataset augmentation with synchronized label transformation.
"""

import os
import numpy as np
import cv2
from PIL import Image
import random
import math

class DatasetAugmenter:
    """
    Class for augmenting images and their corresponding labels.
    """
    
    def __init__(self, options=None):
        """
        Initialize the dataset augmenter with options.
        
        Args:
            options: Dictionary of augmentation options
        """
        self.options = options or {}
    
    def augment(self, image, predictions):
        """
        Apply augmentation to an image and its predictions.
        
        Args:
            image: PIL Image object
            predictions: Dictionary containing prediction results
            
        Returns:
            Tuple of (augmented_image, augmented_predictions)
        """
        # Convert PIL Image to numpy array
        image_np = np.array(image)
        
        # Create a copy of predictions to avoid modifying the original
        predictions_copy = self._deep_copy_predictions(predictions)
        
        # Apply horizontal flip
        if self.options.get('horizontal_flip', False) and random.random() < self.options.get('flip_probability', 0.5):
            image_np, predictions_copy = self._apply_horizontal_flip(image_np, predictions_copy)
        
        # Apply vertical flip
        if self.options.get('vertical_flip', False) and random.random() < self.options.get('flip_probability', 0.5):
            image_np, predictions_copy = self._apply_vertical_flip(image_np, predictions_copy)
        
        # Apply rotation
        if self.options.get('rotation', False):
            max_angle = self.options.get('max_rotation_angle', 30)
            angle = random.uniform(-max_angle, max_angle)
            image_np, predictions_copy = self._apply_rotation(image_np, predictions_copy, angle)
        
        # Apply color jitter
        if self.options.get('color_jitter', False):
            image_np = self._apply_color_jitter(image_np)
        
        # Apply brightness adjustment
        if self.options.get('brightness', False):
            factor = random.uniform(
                self.options.get('min_brightness', 0.8),
                self.options.get('max_brightness', 1.2)
            )
            image_np = self._apply_brightness(image_np, factor)
        
        # Apply contrast adjustment
        if self.options.get('contrast', False):
            factor = random.uniform(
                self.options.get('min_contrast', 0.8),
                self.options.get('max_contrast', 1.2)
            )
            image_np = self._apply_contrast(image_np, factor)
        
        # Apply noise
        if self.options.get('noise', False):
            noise_type = self.options.get('noise_type', 'gaussian')
            image_np = self._apply_noise(image_np, noise_type)
        
        # Convert back to PIL Image
        augmented_image = Image.fromarray(image_np)
        
        return augmented_image, predictions_copy
    
    def _deep_copy_predictions(self, predictions):
        """Create a deep copy of predictions dictionary."""
        result = predictions.copy()
        
        # Copy arrays
        if 'boxes' in result:
            result['boxes'] = [box.copy() if hasattr(box, 'copy') else box for box in result['boxes']]
        
        if 'masks' in result:
            result['masks'] = [mask.copy() if hasattr(mask, 'copy') else mask for mask in result['masks']]
        
        if 'labels' in result:
            result['labels'] = result['labels'].copy() if hasattr(result['labels'], 'copy') else result['labels']
        
        if 'scores' in result:
            result['scores'] = result['scores'].copy() if hasattr(result['scores'], 'copy') else result['scores']
        
        if 'class_names' in result:
            result['class_names'] = result['class_names'].copy() if hasattr(result['class_names'], 'copy') else result['class_names']
        
        if 'mask' in result:
            result['mask'] = result['mask'].copy() if hasattr(result['mask'], 'copy') else result['mask']
        
        return result
    
    def _apply_horizontal_flip(self, image, predictions):
        """Apply horizontal flip to image and update predictions."""
        # Flip image
        flipped_image = cv2.flip(image, 1)  # 1 for horizontal flip
        
        # Update predictions based on type
        prediction_type = predictions.get('type', '')
        
        if prediction_type == 'semantic_segmentation':
            if 'mask' in predictions:
                predictions['mask'] = cv2.flip(predictions['mask'], 1)
        
        elif prediction_type == 'instance_segmentation':
            if 'boxes' in predictions and len(predictions['boxes']) > 0:
                width = image.shape[1]
                for i, box in enumerate(predictions['boxes']):
                    # Flip box coordinates: [x1, y1, x2, y2] -> [width-x2, y1, width-x1, y2]
                    predictions['boxes'][i] = [width - box[2], box[1], width - box[0], box[3]]
                
                # Flip masks
                if 'masks' in predictions:
                    for i, mask in enumerate(predictions['masks']):
                        predictions['masks'][i] = cv2.flip(mask, 1)
        
        elif prediction_type == 'bounding_box':
            if 'boxes' in predictions and len(predictions['boxes']) > 0:
                width = image.shape[1]
                for i, box in enumerate(predictions['boxes']):
                    # Flip box coordinates: [x1, y1, x2, y2] -> [width-x2, y1, width-x1, y2]
                    predictions['boxes'][i] = [width - box[2], box[1], width - box[0], box[3]]
        
        return flipped_image, predictions
    
    def _apply_vertical_flip(self, image, predictions):
        """Apply vertical flip to image and update predictions."""
        # Flip image
        flipped_image = cv2.flip(image, 0)  # 0 for vertical flip
        
        # Update predictions based on type
        prediction_type = predictions.get('type', '')
        
        if prediction_type == 'semantic_segmentation':
            if 'mask' in predictions:
                predictions['mask'] = cv2.flip(predictions['mask'], 0)
        
        elif prediction_type == 'instance_segmentation':
            if 'boxes' in predictions and len(predictions['boxes']) > 0:
                height = image.shape[0]
                for i, box in enumerate(predictions['boxes']):
                    # Flip box coordinates: [x1, y1, x2, y2] -> [x1, height-y2, x2, height-y1]
                    predictions['boxes'][i] = [box[0], height - box[3], box[2], height - box[1]]
                
                # Flip masks
                if 'masks' in predictions:
                    for i, mask in enumerate(predictions['masks']):
                        predictions['masks'][i] = cv2.flip(mask, 0)
        
        elif prediction_type == 'bounding_box':
            if 'boxes' in predictions and len(predictions['boxes']) > 0:
                height = image.shape[0]
                for i, box in enumerate(predictions['boxes']):
                    # Flip box coordinates: [x1, y1, x2, y2] -> [x1, height-y2, x2, height-y1]
                    predictions['boxes'][i] = [box[0], height - box[3], box[2], height - box[1]]
        
        return flipped_image, predictions
    
    def _apply_rotation(self, image, predictions, angle):
        """Apply rotation to image and update predictions."""
        height, width = image.shape[:2]
        center = (width / 2, height / 2)
        
        # Get rotation matrix
        rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
        
        # Calculate new image dimensions
        abs_cos = abs(rotation_matrix[0, 0])
        abs_sin = abs(rotation_matrix[0, 1])
        new_width = int(height * abs_sin + width * abs_cos)
        new_height = int(height * abs_cos + width * abs_sin)
        
        # Adjust rotation matrix to take into account the translation
        rotation_matrix[0, 2] += new_width / 2 - center[0]
        rotation_matrix[1, 2] += new_height / 2 - center[1]
        
        # Rotate image
        rotated_image = cv2.warpAffine(image, rotation_matrix, (new_width, new_height))
        
        # Update predictions based on type
        prediction_type = predictions.get('type', '')
        
        if prediction_type == 'semantic_segmentation':
            if 'mask' in predictions:
                predictions['mask'] = cv2.warpAffine(predictions['mask'], rotation_matrix, (new_width, new_height))
        
        elif prediction_type == 'instance_segmentation' or prediction_type == 'bounding_box':
            if 'boxes' in predictions and len(predictions['boxes']) > 0:
                for i, box in enumerate(predictions['boxes']):
                    # Get corner points of the box
                    corners = np.array([
                        [box[0], box[1]],  # top-left
                        [box[2], box[1]],  # top-right
                        [box[2], box[3]],  # bottom-right
                        [box[0], box[3]]   # bottom-left
                    ])
                    
                    # Add ones for matrix multiplication
                    corners_homogeneous = np.hstack([corners, np.ones((4, 1))])
                    
                    # Apply rotation matrix
                    rotated_corners = np.dot(corners_homogeneous, rotation_matrix.T)
                    
                    # Get new bounding box from rotated corners
                    min_x = np.min(rotated_corners[:, 0])
                    min_y = np.min(rotated_corners[:, 1])
                    max_x = np.max(rotated_corners[:, 0])
                    max_y = np.max(rotated_corners[:, 1])
                    
                    # Update box coordinates
                    predictions['boxes'][i] = [min_x, min_y, max_x, max_y]
                
                # Rotate masks for instance segmentation
                if prediction_type == 'instance_segmentation' and 'masks' in predictions:
                    for i, mask in enumerate(predictions['masks']):
                        predictions['masks'][i] = cv2.warpAffine(mask, rotation_matrix, (new_width, new_height))
        
        return rotated_image, predictions
    
    def _apply_color_jitter(self, image):
        """Apply color jitter to image."""
        # Convert to HSV for easier color manipulation
        hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV).astype(np.float32)
        
        # Hue adjustment
        if self.options.get('hue', False):
            hue_shift = random.uniform(
                self.options.get('min_hue', -10),
                self.options.get('max_hue', 10)
            )
            hsv[:, :, 0] = (hsv[:, :, 0] + hue_shift) % 180
        
        # Saturation adjustment
        if self.options.get('saturation', False):
            saturation_factor = random.uniform(
                self.options.get('min_saturation', 0.8),
                self.options.get('max_saturation', 1.2)
            )
            hsv[:, :, 1] = np.clip(hsv[:, :, 1] * saturation_factor, 0, 255)
        
        # Value adjustment
        if self.options.get('value', False):
            value_factor = random.uniform(
                self.options.get('min_value', 0.8),
                self.options.get('max_value', 1.2)
            )
            hsv[:, :, 2] = np.clip(hsv[:, :, 2] * value_factor, 0, 255)
        
        # Convert back to RGB
        hsv = np.clip(hsv, 0, 255).astype(np.uint8)
        return cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
    
    def _apply_brightness(self, image, factor):
        """Apply brightness adjustment to image."""
        hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV).astype(np.float32)
        hsv[:, :, 2] = np.clip(hsv[:, :, 2] * factor, 0, 255)
        hsv = hsv.astype(np.uint8)
        return cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
    
    def _apply_contrast(self, image, factor):
        """Apply contrast adjustment to image."""
        mean = np.mean(image, axis=(0, 1), keepdims=True)
        adjusted = np.clip((image - mean) * factor + mean, 0, 255).astype(np.uint8)
        return adjusted
    
    def _apply_noise(self, image, noise_type):
        """Apply noise to image."""
        if noise_type == 'gaussian':
            # Gaussian noise
            mean = 0
            std = self.options.get('noise_std', 5)
            noise = np.random.normal(mean, std, image.shape).astype(np.int16)
            noisy_image = np.clip(image.astype(np.int16) + noise, 0, 255).astype(np.uint8)
            return noisy_image
        
        elif noise_type == 'salt_pepper':
            # Salt and pepper noise
            prob = self.options.get('noise_probability', 0.01)
            noisy_image = image.copy()
            
            # Salt
            salt_mask = np.random.random(image.shape[:2]) < prob / 2
            noisy_image[salt_mask] = 255
            
            # Pepper
            pepper_mask = np.random.random(image.shape[:2]) < prob / 2
            noisy_image[pepper_mask] = 0
            
            return noisy_image
        
        else:
            return image
