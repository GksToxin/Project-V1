"""
Module for cropping and auto-tagging detected objects.
"""

import os
import numpy as np
from PIL import Image

def crop_objects(image, predictions, output_dir, min_score=0.5, padding=10):
    """
    Crop detected objects from an image and save them to class-specific folders.
    
    Args:
        image: PIL Image object
        predictions: Dictionary containing prediction results
        output_dir: Base directory to save cropped objects
        min_score: Minimum confidence score for objects to crop
        padding: Padding to add around objects (in pixels)
        
    Returns:
        Dictionary with statistics about cropped objects
    """
    prediction_type = predictions.get('type', '')
    
    if prediction_type == 'semantic_segmentation':
        return {'error': 'Cropping not supported for semantic segmentation'}
    
    # Convert PIL Image to numpy array
    image_np = np.array(image)
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    stats = {
        'total_objects': 0,
        'cropped_objects': 0,
        'classes': {}
    }
    
    if prediction_type == 'instance_segmentation':
        return crop_instances(image_np, predictions, output_dir, min_score, padding, stats)
    elif prediction_type == 'bounding_box':
        return crop_bboxes(image_np, predictions, output_dir, min_score, padding, stats)
    else:
        return {'error': 'Unsupported prediction type'}

def crop_instances(image_np, predictions, output_dir, min_score, padding, stats):
    """
    Crop instance segmentation objects.
    
    Args:
        image_np: Numpy array of the image
        predictions: Instance segmentation prediction results
        output_dir: Base directory to save cropped objects
        min_score: Minimum confidence score for objects to crop
        padding: Padding to add around objects (in pixels)
        stats: Dictionary to store statistics
        
    Returns:
        Updated statistics dictionary
    """
    boxes = predictions.get('boxes', [])
    masks = predictions.get('masks', [])
    labels = predictions.get('labels', [])
    scores = predictions.get('scores', [])
    class_names = predictions.get('class_names', [])
    
    stats['total_objects'] = len(boxes)
    
    for i in range(len(boxes)):
        if i < len(masks) and i < len(labels) and i < len(scores):
            # Skip objects with low confidence
            if scores[i] < min_score:
                continue
            
            # Get class information
            label = int(labels[i])
            class_name = class_names[i] if i < len(class_names) else f"class_{label}"
            
            # Create class directory
            class_dir = os.path.join(output_dir, class_name)
            os.makedirs(class_dir, exist_ok=True)
            
            # Get bounding box
            box = [int(coord) for coord in boxes[i]]
            x1, y1, x2, y2 = box
            
            # Add padding
            x1 = max(0, x1 - padding)
            y1 = max(0, y1 - padding)
            x2 = min(image_np.shape[1], x2 + padding)
            y2 = min(image_np.shape[0], y2 + padding)
            
            # Get mask
            mask = masks[i]
            
            # Apply mask to image
            masked_image = image_np.copy()
            for c in range(3):  # RGB channels
                masked_image[:, :, c] = np.where(mask > 0.5, image_np[:, :, c], 0)
            
            # Crop the masked image
            cropped = masked_image[y1:y2, x1:x2]
            
            # Convert to PIL Image
            cropped_image = Image.fromarray(cropped)
            
            # Save cropped image
            filename = f"{class_name}_{i}_{scores[i]:.2f}.png"
            cropped_image.save(os.path.join(class_dir, filename))
            
            # Update statistics
            stats['cropped_objects'] += 1
            if class_name not in stats['classes']:
                stats['classes'][class_name] = 0
            stats['classes'][class_name] += 1
    
    return stats

def crop_bboxes(image_np, predictions, output_dir, min_score, padding, stats):
    """
    Crop bounding box objects.
    
    Args:
        image_np: Numpy array of the image
        predictions: Bounding box prediction results
        output_dir: Base directory to save cropped objects
        min_score: Minimum confidence score for objects to crop
        padding: Padding to add around objects (in pixels)
        stats: Dictionary to store statistics
        
    Returns:
        Updated statistics dictionary
    """
    boxes = predictions.get('boxes', [])
    labels = predictions.get('labels', [])
    scores = predictions.get('scores', [])
    class_names = predictions.get('class_names', [])
    
    stats['total_objects'] = len(boxes)
    
    for i in range(len(boxes)):
        if i < len(labels) and i < len(scores):
            # Skip objects with low confidence
            if scores[i] < min_score:
                continue
            
            # Get class information
            label = int(labels[i])
            class_name = class_names[i] if i < len(class_names) else f"class_{label}"
            
            # Create class directory
            class_dir = os.path.join(output_dir, class_name)
            os.makedirs(class_dir, exist_ok=True)
            
            # Get bounding box
            box = [int(coord) for coord in boxes[i]]
            x1, y1, x2, y2 = box
            
            # Add padding
            x1 = max(0, x1 - padding)
            y1 = max(0, y1 - padding)
            x2 = min(image_np.shape[1], x2 + padding)
            y2 = min(image_np.shape[0], y2 + padding)
            
            # Crop the image
            cropped = image_np[y1:y2, x1:x2]
            
            # Convert to PIL Image
            cropped_image = Image.fromarray(cropped)
            
            # Save cropped image
            filename = f"{class_name}_{i}_{scores[i]:.2f}.png"
            cropped_image.save(os.path.join(class_dir, filename))
            
            # Update statistics
            stats['cropped_objects'] += 1
            if class_name not in stats['classes']:
                stats['classes'][class_name] = 0
            stats['classes'][class_name] += 1
    
    return stats
