import os
import base64
from io import BytesIO
import numpy as np
from PIL import Image

def pil_to_base64(image):
    """
    Convert a PIL Image to a base64 encoded string.
    
    Args:
        image: PIL Image object
        
    Returns:
        Base64 encoded string
    """
    buffered = BytesIO()
    image.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue()).decode('utf-8')
    return img_str

def numpy_to_base64(image_np):
    """
    Convert a numpy array image to a base64 encoded string.
    
    Args:
        image_np: Numpy array image
        
    Returns:
        Base64 encoded string
    """
    # Convert to PIL Image
    image = Image.fromarray(image_np.astype('uint8'))
    return pil_to_base64(image)

def create_visualization_html(image, prediction, prediction_type):
    """
    Create HTML for visualizing prediction results.
    
    Args:
        image: Original image (PIL Image)
        prediction: Prediction results
        prediction_type: Type of prediction
        
    Returns:
        HTML string for visualization
    """
    from src.utils.image import (
        visualize_semantic_segmentation,
        visualize_instance_segmentation,
        visualize_bounding_boxes
    )
    
    # Convert image to numpy if needed
    if isinstance(image, Image.Image):
        image_np = np.array(image)
    else:
        image_np = image
    
    # Create visualization based on prediction type
    if prediction_type == 'semantic_segmentation':
        vis_image = visualize_semantic_segmentation(
            image_np, 
            prediction['mask']
        )
    elif prediction_type == 'instance_segmentation':
        vis_image = visualize_instance_segmentation(
            image_np,
            prediction['masks'],
            prediction['boxes'],
            prediction['labels'],
            prediction['class_names']
        )
    elif prediction_type == 'bounding_box':
        vis_image = visualize_bounding_boxes(
            image_np,
            prediction['boxes'],
            prediction['labels'],
            prediction['class_names']
        )
    else:
        raise ValueError(f"Unsupported prediction type: {prediction_type}")
    
    # Convert to base64 for embedding in HTML
    original_b64 = pil_to_base64(image) if isinstance(image, Image.Image) else numpy_to_base64(image_np)
    vis_b64 = numpy_to_base64(vis_image)
    
    # Create HTML
    html = f"""
    <div class="visualization-container">
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Original Image</div>
                    <div class="card-body">
                        <img src="data:image/png;base64,{original_b64}" class="img-fluid" alt="Original Image">
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Labeled Image</div>
                    <div class="card-body">
                        <img src="data:image/png;base64,{vis_b64}" class="img-fluid" alt="Labeled Image">
                    </div>
                </div>
            </div>
        </div>
    """
    
    # Add detection details
    if prediction_type in ['instance_segmentation', 'bounding_box']:
        html += """
        <div class="row mt-3">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">Detection Results</div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Class</th>
                                    <th>Confidence</th>
                                    <th>Bounding Box</th>
                                </tr>
                            </thead>
                            <tbody>
        """
        
        for i, (class_name, score, box) in enumerate(zip(
            prediction['class_names'], 
            prediction['scores'], 
            prediction['boxes']
        )):
            x1, y1, x2, y2 = [int(coord) for coord in box]
            html += f"""
                <tr>
                    <td>{class_name}</td>
                    <td>{score:.2f}</td>
                    <td>[{x1}, {y1}, {x2}, {y2}]</td>
                </tr>
            """
        
        html += """
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        """
    
    html += "</div>"
    
    return html
