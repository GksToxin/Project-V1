import os
import cv2
import numpy as np
from PIL import Image

def load_image(image_path):
    """
    Load an image from the specified path.
    
    Args:
        image_path: Path to the image file
        
    Returns:
        PIL Image object
    """
    return Image.open(image_path)

def get_image_info(image_path):
    """
    Get metadata for an image.
    
    Args:
        image_path: Path to the image file
        
    Returns:
        Dictionary containing image metadata
    """
    image = Image.open(image_path)
    return {
        "filename": os.path.basename(image_path),
        "width": image.width,
        "height": image.height,
        "path": image_path
    }

def visualize_semantic_segmentation(image, mask, alpha=0.5):
    """
    Create a visualization of semantic segmentation results.
    
    Args:
        image: PIL Image object
        mask: Segmentation mask as numpy array
        alpha: Transparency of the overlay
        
    Returns:
        Visualization as numpy array
    """
    # Convert PIL image to numpy array if needed
    if isinstance(image, Image.Image):
        image_np = np.array(image)
    else:
        image_np = image
    
    # Create a colormap for the mask
    num_classes = np.max(mask) + 1
    colors = np.random.randint(0, 255, size=(num_classes, 3), dtype=np.uint8)
    colors[0] = [0, 0, 0]  # Background is black
    
    # Create a colored mask
    colored_mask = colors[mask]
    
    # Blend the image and the colored mask
    visualization = cv2.addWeighted(image_np, 1-alpha, colored_mask, alpha, 0)
    
    return visualization

def visualize_instance_segmentation(image, masks, boxes, labels, class_names, alpha=0.5):
    """
    Create a visualization of instance segmentation results.
    
    Args:
        image: PIL Image object
        masks: List of instance masks
        boxes: List of bounding boxes
        labels: List of class labels
        class_names: List of class names
        alpha: Transparency of the overlay
        
    Returns:
        Visualization as numpy array
    """
    # Convert PIL image to numpy array if needed
    if isinstance(image, Image.Image):
        image_np = np.array(image)
    else:
        image_np = image
    
    # Create a copy of the image for visualization
    visualization = image_np.copy()
    
    # Generate random colors for each instance
    num_instances = len(masks)
    colors = np.random.randint(0, 255, size=(num_instances, 3), dtype=np.uint8)
    
    # Draw each instance
    for i in range(num_instances):
        # Get mask, box, and label for this instance
        mask = masks[i]
        box = boxes[i]
        label = labels[i]
        class_name = class_names[i]
        color = colors[i].tolist()
        
        # Apply colored mask
        colored_mask = np.zeros_like(image_np)
        colored_mask[mask > 0] = color
        visualization = cv2.addWeighted(visualization, 1, colored_mask, alpha, 0)
        
        # Draw bounding box
        x1, y1, x2, y2 = [int(coord) for coord in box]
        cv2.rectangle(visualization, (x1, y1), (x2, y2), color, 2)
        
        # Draw label
        cv2.putText(visualization, class_name, (x1, y1 - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
    
    return visualization

def visualize_bounding_boxes(image, boxes, labels, class_names):
    """
    Create a visualization of bounding box detection results.
    
    Args:
        image: PIL Image object
        boxes: List of bounding boxes
        labels: List of class labels
        class_names: List of class names
        
    Returns:
        Visualization as numpy array
    """
    # Convert PIL image to numpy array if needed
    if isinstance(image, Image.Image):
        image_np = np.array(image)
    else:
        image_np = image
    
    # Create a copy of the image for visualization
    visualization = image_np.copy()
    
    # Generate random colors for each class
    num_classes = max(labels) + 1 if labels else 1
    colors = np.random.randint(0, 255, size=(num_classes, 3), dtype=np.uint8)
    
    # Draw each bounding box
    for i in range(len(boxes)):
        # Get box and label for this instance
        box = boxes[i]
        label = labels[i]
        class_name = class_names[i]
        color = colors[label % len(colors)].tolist()
        
        # Draw bounding box
        x1, y1, x2, y2 = [int(coord) for coord in box]
        cv2.rectangle(visualization, (x1, y1), (x2, y2), color, 2)
        
        # Draw label
        cv2.putText(visualization, class_name, (x1, y1 - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
    
    return visualization
