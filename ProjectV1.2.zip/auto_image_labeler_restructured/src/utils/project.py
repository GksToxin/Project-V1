"""
Module for project saving and resume support.
"""

import os
import json
import sqlite3
import datetime
import shutil
from pathlib import Path

class ProjectManager:
    """
    Class for managing project saving and resuming.
    """
    
    def __init__(self, db_path, projects_dir):
        """
        Initialize the project manager.
        
        Args:
            db_path: Path to the SQLite database
            projects_dir: Directory to store project files
        """
        self.db_path = db_path
        self.projects_dir = projects_dir
        
        # Create directories if they don't exist
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        os.makedirs(projects_dir, exist_ok=True)
        
        # Initialize database
        self._init_db()
    
    def _init_db(self):
        """Initialize the database with required tables."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create projects table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            label_type TEXT,
            output_format TEXT,
            directory TEXT NOT NULL,
            status TEXT,
            metadata TEXT
        )
        ''')
        
        # Create images table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS images (
            id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            filename TEXT NOT NULL,
            path TEXT NOT NULL,
            processed BOOLEAN DEFAULT 0,
            metadata TEXT,
            FOREIGN KEY (project_id) REFERENCES projects (id)
        )
        ''')
        
        # Create settings table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            project_id TEXT NOT NULL,
            key TEXT NOT NULL,
            value TEXT,
            PRIMARY KEY (project_id, key),
            FOREIGN KEY (project_id) REFERENCES projects (id)
        )
        ''')
        
        conn.commit()
        conn.close()
    
    def create_project(self, name, description=None, label_type=None, output_format=None):
        """
        Create a new project.
        
        Args:
            name: Project name
            description: Project description
            label_type: Type of labeling (semantic, instance, bbox)
            output_format: Format of output (coco, yolo)
            
        Returns:
            Project ID
        """
        import uuid
        
        # Generate project ID
        project_id = str(uuid.uuid4())
        
        # Create project directory
        project_dir = os.path.join(self.projects_dir, project_id)
        os.makedirs(project_dir, exist_ok=True)
        
        # Create subdirectories
        os.makedirs(os.path.join(project_dir, 'images'), exist_ok=True)
        os.makedirs(os.path.join(project_dir, 'annotations'), exist_ok=True)
        
        # Get current timestamp
        timestamp = datetime.datetime.now().isoformat()
        
        # Insert project into database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
        INSERT INTO projects (id, name, description, created_at, updated_at, label_type, output_format, directory, status, metadata)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            project_id,
            name,
            description,
            timestamp,
            timestamp,
            label_type,
            output_format,
            project_dir,
            'created',
            '{}'
        ))
        
        conn.commit()
        conn.close()
        
        return project_id
    
    def get_project(self, project_id):
        """
        Get project information.
        
        Args:
            project_id: Project ID
            
        Returns:
            Dictionary with project information
        """
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM projects WHERE id = ?', (project_id,))
        row = cursor.fetchone()
        
        if not row:
            conn.close()
            return None
        
        # Convert row to dictionary
        project = dict(row)
        
        # Get project settings
        cursor.execute('SELECT key, value FROM settings WHERE project_id = ?', (project_id,))
        settings = {row['key']: json.loads(row['value']) for row in cursor.fetchall()}
        project['settings'] = settings
        
        # Get project images
        cursor.execute('SELECT * FROM images WHERE project_id = ?', (project_id,))
        images = [dict(row) for row in cursor.fetchall()]
        project['images'] = images
        
        conn.close()
        
        return project
    
    def list_projects(self):
        """
        List all projects.
        
        Returns:
            List of project dictionaries
        """
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM projects ORDER BY updated_at DESC')
        projects = [dict(row) for row in cursor.fetchall()]
        
        conn.close()
        
        return projects
    
    def update_project(self, project_id, **kwargs):
        """
        Update project information.
        
        Args:
            project_id: Project ID
            **kwargs: Fields to update
            
        Returns:
            Success status
        """
        # Get current timestamp
        timestamp = datetime.datetime.now().isoformat()
        
        # Prepare update fields
        update_fields = []
        update_values = []
        
        for key, value in kwargs.items():
            if key in ['name', 'description', 'label_type', 'output_format', 'status', 'metadata']:
                update_fields.append(f"{key} = ?")
                update_values.append(value)
        
        if not update_fields:
            return {'success': False, 'error': 'No valid fields to update'}
        
        # Add updated_at field
        update_fields.append("updated_at = ?")
        update_values.append(timestamp)
        
        # Add project_id to values
        update_values.append(project_id)
        
        # Update project in database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(f'''
        UPDATE projects
        SET {', '.join(update_fields)}
        WHERE id = ?
        ''', update_values)
        
        if cursor.rowcount == 0:
            conn.close()
            return {'success': False, 'error': 'Project not found'}
        
        conn.commit()
        conn.close()
        
        return {'success': True}
    
    def delete_project(self, project_id):
        """
        Delete a project.
        
        Args:
            project_id: Project ID
            
        Returns:
            Success status
        """
        # Get project directory
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT directory FROM projects WHERE id = ?', (project_id,))
        row = cursor.fetchone()
        
        if not row:
            conn.close()
            return {'success': False, 'error': 'Project not found'}
        
        project_dir = row[0]
        
        # Delete project from database
        cursor.execute('DELETE FROM images WHERE project_id = ?', (project_id,))
        cursor.execute('DELETE FROM settings WHERE project_id = ?', (project_id,))
        cursor.execute('DELETE FROM projects WHERE id = ?', (project_id,))
        
        conn.commit()
        conn.close()
        
        # Delete project directory
        if os.path.exists(project_dir):
            shutil.rmtree(project_dir)
        
        return {'success': True}
    
    def add_images(self, project_id, image_files):
        """
        Add images to a project.
        
        Args:
            project_id: Project ID
            image_files: List of image file paths
            
        Returns:
            List of added image IDs
        """
        import uuid
        
        # Get project directory
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT directory FROM projects WHERE id = ?', (project_id,))
        row = cursor.fetchone()
        
        if not row:
            conn.close()
            return {'error': 'Project not found'}
        
        project_dir = row[0]
        images_dir = os.path.join(project_dir, 'images')
        
        # Add images
        added_images = []
        
        for image_file in image_files:
            # Generate image ID
            image_id = str(uuid.uuid4())
            
            # Get filename
            filename = os.path.basename(image_file)
            
            # Copy image to project directory
            dest_path = os.path.join(images_dir, filename)
            shutil.copy2(image_file, dest_path)
            
            # Add image to database
            cursor.execute('''
            INSERT INTO images (id, project_id, filename, path, processed, metadata)
            VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                image_id,
                project_id,
                filename,
                dest_path,
                False,
                '{}'
            ))
            
            added_images.append(image_id)
        
        # Update project timestamp
        timestamp = datetime.datetime.now().isoformat()
        cursor.execute('UPDATE projects SET updated_at = ? WHERE id = ?', (timestamp, project_id))
        
        conn.commit()
        conn.close()
        
        return added_images
    
    def update_image(self, image_id, **kwargs):
        """
        Update image information.
        
        Args:
            image_id: Image ID
            **kwargs: Fields to update
            
        Returns:
            Success status
        """
        # Prepare update fields
        update_fields = []
        update_values = []
        
        for key, value in kwargs.items():
            if key in ['processed', 'metadata']:
                update_fields.append(f"{key} = ?")
                update_values.append(value if key != 'metadata' else json.dumps(value))
        
        if not update_fields:
            return {'success': False, 'error': 'No valid fields to update'}
        
        # Add image_id to values
        update_values.append(image_id)
        
        # Update image in database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(f'''
        UPDATE images
        SET {', '.join(update_fields)}
        WHERE id = ?
        ''', update_values)
        
        if cursor.rowcount == 0:
            conn.close()
            return {'success': False, 'error': 'Image not found'}
        
        conn.commit()
        conn.close()
        
        return {'success': True}
    
    def save_project_settings(self, project_id, settings):
        """
        Save project settings.
        
        Args:
            project_id: Project ID
            settings: Dictionary of settings
            
        Returns:
            Success status
        """
        # Check if project exists
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT id FROM projects WHERE id = ?', (project_id,))
        if not cursor.fetchone():
            conn.close()
            return {'success': False, 'error': 'Project not found'}
        
        # Save settings
        for key, value in settings.items():
            # Convert value to JSON string
            value_json = json.dumps(value)
            
            # Insert or update setting
            cursor.execute('''
            INSERT OR REPLACE INTO settings (project_id, key, value)
            VALUES (?, ?, ?)
            ''', (project_id, key, value_json))
        
        # Update project timestamp
        timestamp = datetime.datetime.now().isoformat()
        cursor.execute('UPDATE projects SET updated_at = ? WHERE id = ?', (timestamp, project_id))
        
        conn.commit()
        conn.close()
        
        return {'success': True}
    
    def get_project_settings(self, project_id, key=None):
        """
        Get project settings.
        
        Args:
            project_id: Project ID
            key: Specific setting key (optional)
            
        Returns:
            Dictionary of settings or specific setting value
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if key:
            # Get specific setting
            cursor.execute('SELECT value FROM settings WHERE project_id = ? AND key = ?', (project_id, key))
            row = cursor.fetchone()
            
            conn.close()
            
            if not row:
                return None
            
            return json.loads(row[0])
        else:
            # Get all settings
            cursor.execute('SELECT key, value FROM settings WHERE project_id = ?', (project_id,))
            settings = {row[0]: json.loads(row[1]) for row in cursor.fetchall()}
            
            conn.close()
            
            return settings
    
    def export_project(self, project_id, export_path):
        """
        Export a project to a ZIP file.
        
        Args:
            project_id: Project ID
            export_path: Path to save the exported ZIP file
            
        Returns:
            Success status
        """
        # Get project information
        project = self.get_project(project_id)
        
        if not project:
            return {'success': False, 'error': 'Project not found'}
        
        # Create temporary directory for export
        import tempfile
        temp_dir = tempfile.mkdtemp()
        
        try:
            # Copy project files
            project_dir = project['directory']
            export_dir = os.path.join(temp_dir, 'project')
            shutil.copytree(project_dir, export_dir)
            
            # Save project metadata
            metadata = {
                'id': project['id'],
                'name': project['name'],
                'description': project['description'],
                'created_at': project['created_at'],
                'updated_at': project['updated_at'],
                'label_type': project['label_type'],
                'output_format': project['output_format'],
                'status': project['status'],
                'settings': project['settings']
            }
            
            with open(os.path.join(export_dir, 'metadata.json'), 'w') as f:
                json.dump(metadata, f, indent=2)
            
            # Create ZIP file
            shutil.make_archive(export_path.rstrip('.zip'), 'zip', temp_dir)
            
            return {'success': True, 'path': export_path}
        
        except Exception as e:
            return {'success': False, 'error': str(e)}
        
        finally:
            # Clean up temporary directory
            shutil.rmtree(temp_dir)
    
    def import_project(self, zip_path):
        """
        Import a project from a ZIP file.
        
        Args:
            zip_path: Path to the ZIP file
            
        Returns:
            Project ID
        """
        # Create temporary directory for import
        import tempfile
        import uuid
        
        temp_dir = tempfile.mkdtemp()
        
        try:
            # Extract ZIP file
            shutil.unpack_archive(zip_path, temp_dir, 'zip')
            
            # Find project directory
            project_dir = os.path.join(temp_dir, 'project')
            if not os.path.exists(project_dir):
                # Try to find any directory that might contain the project
                for item in os.listdir(temp_dir):
                    if os.path.isdir(os.path.join(temp_dir, item)):
                        project_dir = os.path.join(temp_dir, item)
                        break
            
            # Load metadata
            metadata_path = os.path.join(project_dir, 'metadata.json')
            if not os.path.exists(metadata_path):
                return {'error': 'Invalid project export: metadata.json not found'}
            
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
            
            # Generate new project ID
            new_project_id = str(uuid.uuid4())
            
            # Create new project directory
            new_project_dir = os.path.join(self.projects_dir, new_project_id)
            os.makedirs(new_project_dir, exist_ok=True)
            
            # Copy project files
            for item in os.listdir(project_dir):
                if item != 'metadata.json':
                    src = os.path.join(project_dir, item)
                    dst = os.path.join(new_project_dir, item)
                    if os.path.isdir(src):
                        shutil.copytree(src, dst)
                    else:
                        shutil.copy2(src, dst)
            
            # Create missing directories
            os.makedirs(os.path.join(new_project_dir, 'images'), exist_ok=True)
            os.makedirs(os.path.join(new_project_dir, 'annotations'), exist_ok=True)
            
            # Get current timestamp
            timestamp = datetime.datetime.now().isoformat()
            
            # Insert project into database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
            INSERT INTO projects (id, name, description, created_at, updated_at, label_type, output_format, directory, status, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                new_project_id,
                metadata.get('name', 'Imported Project'),
                metadata.get('description', ''),
                metadata.get('created_at', timestamp),
                timestamp,
                metadata.get('label_type'),
                metadata.get('output_format'),
                new_project_dir,
                'imported',
                '{}'
            ))
            
            # Import settings
            settings = metadata.get('settings', {})
            for key, value in settings.items():
                cursor.execute('''
                INSERT INTO settings (project_id, key, value)
                VALUES (?, ?, ?)
                ''', (new_project_id, key, json.dumps(value)))
            
            # Import images
            images_dir = os.path.join(new_project_dir, 'images')
            for filename in os.listdir(images_dir):
                if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
                    image_id = str(uuid.uuid4())
                    image_path = os.path.join(images_dir, filename)
                    
                    cursor.execute('''
                    INSERT INTO images (id, project_id, filename, path, processed, metadata)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ''', (
                        image_id,
                        new_project_id,
                        filename,
                        image_path,
                        False,
                        '{}'
                    ))
            
            conn.commit()
            conn.close()
            
            return {'success': True, 'project_id': new_project_id}
        
        except Exception as e:
            return {'success': False, 'error': str(e)}
        
        finally:
            # Clean up temporary directory
            shutil.rmtree(temp_dir)
