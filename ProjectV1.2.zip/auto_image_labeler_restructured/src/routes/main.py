from flask import Blueprint, render_template, request, jsonify, send_file, url_for, redirect, flash
import os
import uuid
import shutil
from werkzeug.utils import secure_filename
from PIL import Image
import json

from src.inference import create_inference_model
from src.formatters import create_formatter
from src.utils.file import create_temp_dir, create_dataset_structure, create_zip_archive, cleanup_temp_dir
from src.utils.image import get_image_info, load_image
from src.utils.visualization import create_visualization_html
from src.inference.filtering import filter_predictions_by_classes
from src.inference.thresholds import apply_thresholds, get_available_classes

main_bp = Blueprint('main', __name__)

# Global variables to store session data
TEMP_DIRS = {}
SESSION_DATA = {}

@main_bp.route('/')
def index():
    """Render the main page."""
    return render_template('index.html')

@main_bp.route('/upload', methods=['POST'])
def upload_images():
    """Handle image upload and create a new labeling session."""
    if 'images' not in request.files:
        return jsonify({'error': 'No images uploaded'}), 400
    
    # Get uploaded files
    uploaded_files = request.files.getlist('images')
    if not uploaded_files or uploaded_files[0].filename == '':
        return jsonify({'error': 'No images selected'}), 400
    
    # Create a new session
    session_id = str(uuid.uuid4())
    temp_dir = create_temp_dir()
    TEMP_DIRS[session_id] = temp_dir
    SESSION_DATA[session_id] = {
        'model': None,
        'raw_predictions': {},
        'filtered_predictions': {}
    }
    
    # Create dataset structure
    dataset_dirs = create_dataset_structure(temp_dir)
    
    # Save uploaded images
    saved_images = []
    for file in uploaded_files:
        if file and file.filename:
            filename = secure_filename(file.filename)
            file_path = os.path.join(dataset_dirs['images_dir'], filename)
            file.save(file_path)
            saved_images.append(file_path)
    
    return jsonify({
        'session_id': session_id,
        'num_images': len(saved_images),
        'message': f'Successfully uploaded {len(saved_images)} images'
    })

@main_bp.route('/get_available_classes', methods=['POST'])
def get_available_classes_route():
    """Get available classes for the selected model."""
    data = request.json
    session_id = data.get('session_id')
    label_type = data.get('label_type')
    
    if not all([session_id, label_type]):
        return jsonify({'error': 'Missing required parameters'}), 400
    
    if session_id not in TEMP_DIRS:
        return jsonify({'error': 'Invalid session ID'}), 400
    
    # Get session directory
    temp_dir = TEMP_DIRS[session_id]
    dataset_dirs = {
        'base_dir': temp_dir,
        'images_dir': os.path.join(temp_dir, 'images'),
        'annotations_dir': os.path.join(temp_dir, 'annotations')
    }
    
    try:
        # Create inference model
        model = create_inference_model(label_type)
        SESSION_DATA[session_id]['model'] = model
        
        # Get first image for class detection
        image_files = [f for f in os.listdir(dataset_dirs['images_dir']) 
                      if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
        
        if not image_files:
            return jsonify({'classes': []}), 200
        
        # Process first image to get classes
        image_path = os.path.join(dataset_dirs['images_dir'], image_files[0])
        image = load_image(image_path)
        
        # Run inference
        predictions = model(image)
        SESSION_DATA[session_id]['raw_predictions'][image_files[0]] = predictions
        
        # Get available classes
        classes = get_available_classes(predictions)
        
        return jsonify({'classes': classes})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@main_bp.route('/process', methods=['POST'])
def process_images():
    """Process images with the selected model and format."""
    data = request.json
    session_id = data.get('session_id')
    label_type = data.get('label_type')
    output_format = data.get('output_format')
    selected_classes = data.get('selected_classes', [])
    global_threshold = data.get('global_threshold')
    class_thresholds = data.get('class_thresholds', {})
    
    if not all([session_id, label_type, output_format]):
        return jsonify({'error': 'Missing required parameters'}), 400
    
    if session_id not in TEMP_DIRS:
        return jsonify({'error': 'Invalid session ID'}), 400
    
    # Get session directory
    temp_dir = TEMP_DIRS[session_id]
    dataset_dirs = {
        'base_dir': temp_dir,
        'images_dir': os.path.join(temp_dir, 'images'),
        'annotations_dir': os.path.join(temp_dir, 'annotations')
    }
    
    try:
        # Create inference model if not already created
        if SESSION_DATA[session_id]['model'] is None or SESSION_DATA[session_id]['model'].type != label_type:
            model = create_inference_model(label_type)
            SESSION_DATA[session_id]['model'] = model
        else:
            model = SESSION_DATA[session_id]['model']
        
        # Create formatter
        formatter = create_formatter(output_format)
        
        # Process each image
        image_files = [f for f in os.listdir(dataset_dirs['images_dir']) 
                      if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
        
        results = []
        all_annotations = []
        
        for image_file in image_files:
            image_path = os.path.join(dataset_dirs['images_dir'], image_file)
            image = load_image(image_path)
            image_info = get_image_info(image_path)
            
            # Run inference if not already done
            if image_file not in SESSION_DATA[session_id]['raw_predictions']:
                predictions = model(image)
                SESSION_DATA[session_id]['raw_predictions'][image_file] = predictions
            else:
                predictions = SESSION_DATA[session_id]['raw_predictions'][image_file]
            
            # Apply class filtering
            filtered_predictions = filter_predictions_by_classes(predictions, selected_classes)
            
            # Apply confidence thresholds
            filtered_predictions = apply_thresholds(filtered_predictions, global_threshold, class_thresholds)
            
            # Store filtered predictions
            SESSION_DATA[session_id]['filtered_predictions'][image_file] = filtered_predictions
            
            # Format annotations
            annotations = formatter.format(filtered_predictions, image_info)
            all_annotations.extend(annotations)
            
            # Create visualization
            visualization_html = create_visualization_html(image, filtered_predictions, filtered_predictions['type'])
            
            results.append({
                'filename': image_file,
                'visualization': visualization_html
            })
        
        # Save annotations
        annotation_path = formatter.save(all_annotations, dataset_dirs['annotations_dir'])
        
        # Create ZIP archive
        zip_path = create_zip_archive(temp_dir)
        
        return jsonify({
            'success': True,
            'results': results,
            'download_url': url_for('main.download_dataset', session_id=session_id)
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@main_bp.route('/download/<session_id>', methods=['GET'])
def download_dataset(session_id):
    """Download the labeled dataset as a ZIP file."""
    if session_id not in TEMP_DIRS:
        return jsonify({'error': 'Invalid session ID'}), 400
    
    temp_dir = TEMP_DIRS[session_id]
    
    # Create ZIP archive if it doesn't exist
    zip_path = f"{temp_dir}.zip"
    if not os.path.exists(zip_path):
        zip_path = create_zip_archive(temp_dir, zip_path)
    
    return send_file(zip_path, as_attachment=True, download_name='labeled_dataset.zip')

@main_bp.route('/cleanup/<session_id>', methods=['POST'])
def cleanup_session(session_id):
    """Clean up temporary files for a session."""
    if session_id in TEMP_DIRS:
        temp_dir = TEMP_DIRS[session_id]
        cleanup_temp_dir(temp_dir)
        
        # Remove ZIP file if it exists
        zip_path = f"{temp_dir}.zip"
        if os.path.exists(zip_path):
            os.remove(zip_path)
        
        del TEMP_DIRS[session_id]
        
        # Clean up session data
        if session_id in SESSION_DATA:
            del SESSION_DATA[session_id]
        
        return jsonify({'success': True})
    
    return jsonify({'error': 'Invalid session ID'}), 400
