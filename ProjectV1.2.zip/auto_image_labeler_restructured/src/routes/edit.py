from flask import Blueprint, request, jsonify, url_for
import os
from PIL import Image
import base64
import io

from src.formatters.editor import LabelEditor
from src.utils.cropping import crop_objects
from src.utils.image import load_image, get_image_info
from src.formatters import create_formatter

edit_bp = Blueprint('edit', __name__)

@edit_bp.route('/get_editable_data', methods=['POST'])
def get_editable_data():
    """Get editable data for an image."""
    data = request.json
    session_id = data.get('session_id')
    image_index = data.get('image_index')
    
    from src.routes.main import TEMP_DIRS, SESSION_DATA
    
    if not all([session_id, image_index is not None]):
        return jsonify({'error': 'Missing required parameters'}), 400
    
    if session_id not in TEMP_DIRS or session_id not in SESSION_DATA:
        return jsonify({'error': 'Invalid session ID'}), 400
    
    # Get session data
    temp_dir = TEMP_DIRS[session_id]
    session_data = SESSION_DATA[session_id]
    
    # Get image files
    images_dir = os.path.join(temp_dir, 'images')
    image_files = [f for f in os.listdir(images_dir) 
                  if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
    
    if image_index < 0 or image_index >= len(image_files):
        return jsonify({'error': 'Invalid image index'}), 400
    
    image_file = image_files[image_index]
    image_path = os.path.join(images_dir, image_file)
    
    # Load image
    image = load_image(image_path)
    
    # Get predictions
    if image_file not in session_data['filtered_predictions']:
        return jsonify({'error': 'No predictions found for this image'}), 400
    
    predictions = session_data['filtered_predictions'][image_file]
    
    # Create label editor
    editor = LabelEditor(predictions, image)
    editable_data = editor.get_editable_data()
    
    # Add image data
    buffer = io.BytesIO()
    image.save(buffer, format='JPEG')
    image_data = base64.b64encode(buffer.getvalue()).decode('utf-8')
    editable_data['image'] = image_data
    
    return jsonify(editable_data)

@edit_bp.route('/save_edits', methods=['POST'])
def save_edits():
    """Save edits for an image."""
    data = request.json
    session_id = data.get('session_id')
    image_index = data.get('image_index')
    edits = data.get('edits')
    
    from src.routes.main import TEMP_DIRS, SESSION_DATA
    
    if not all([session_id, image_index is not None, edits]):
        return jsonify({'error': 'Missing required parameters'}), 400
    
    if session_id not in TEMP_DIRS or session_id not in SESSION_DATA:
        return jsonify({'error': 'Invalid session ID'}), 400
    
    # Get session data
    temp_dir = TEMP_DIRS[session_id]
    session_data = SESSION_DATA[session_id]
    
    # Get image files
    images_dir = os.path.join(temp_dir, 'images')
    annotations_dir = os.path.join(temp_dir, 'annotations')
    image_files = [f for f in os.listdir(images_dir) 
                  if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
    
    if image_index < 0 or image_index >= len(image_files):
        return jsonify({'error': 'Invalid image index'}), 400
    
    image_file = image_files[image_index]
    image_path = os.path.join(images_dir, image_file)
    
    # Load image
    image = load_image(image_path)
    image_info = get_image_info(image_path)
    
    # Get predictions
    if image_file not in session_data['filtered_predictions']:
        return jsonify({'error': 'No predictions found for this image'}), 400
    
    predictions = session_data['filtered_predictions'][image_file]
    
    # Create label editor
    editor = LabelEditor(predictions, image)
    
    # Apply edits
    updated_predictions = editor.apply_edits(edits)
    
    # Update session data
    session_data['filtered_predictions'][image_file] = updated_predictions
    
    # Update annotations
    output_format = session_data.get('output_format', 'coco')
    formatter = create_formatter(output_format)
    
    # Format all annotations
    all_annotations = []
    for img_file, preds in session_data['filtered_predictions'].items():
        img_path = os.path.join(images_dir, img_file)
        img_info = get_image_info(img_path)
        annotations = formatter.format(preds, img_info)
        all_annotations.extend(annotations)
    
    # Save annotations
    annotation_path = formatter.save(all_annotations, annotations_dir)
    
    # Create ZIP archive
    from src.utils.file import create_zip_archive
    zip_path = create_zip_archive(temp_dir)
    
    return jsonify({
        'success': True,
        'download_url': url_for('main.download_dataset', session_id=session_id)
    })

@edit_bp.route('/crop_objects', methods=['POST'])
def crop_objects_route():
    """Crop objects from an image."""
    data = request.json
    session_id = data.get('session_id')
    image_index = data.get('image_index')
    min_score = data.get('min_score', 0.5)
    padding = data.get('padding', 10)
    
    from src.routes.main import TEMP_DIRS, SESSION_DATA
    
    if not all([session_id, image_index is not None]):
        return jsonify({'error': 'Missing required parameters'}), 400
    
    if session_id not in TEMP_DIRS or session_id not in SESSION_DATA:
        return jsonify({'error': 'Invalid session ID'}), 400
    
    # Get session data
    temp_dir = TEMP_DIRS[session_id]
    session_data = SESSION_DATA[session_id]
    
    # Get image files
    images_dir = os.path.join(temp_dir, 'images')
    crops_dir = os.path.join(temp_dir, 'crops')
    
    # Create crops directory if it doesn't exist
    os.makedirs(crops_dir, exist_ok=True)
    
    image_files = [f for f in os.listdir(images_dir) 
                  if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
    
    if image_index < 0 or image_index >= len(image_files):
        return jsonify({'error': 'Invalid image index'}), 400
    
    image_file = image_files[image_index]
    image_path = os.path.join(images_dir, image_file)
    
    # Load image
    image = load_image(image_path)
    
    # Get predictions
    if image_file not in session_data['filtered_predictions']:
        return jsonify({'error': 'No predictions found for this image'}), 400
    
    predictions = session_data['filtered_predictions'][image_file]
    
    # Create image-specific crops directory
    image_crops_dir = os.path.join(crops_dir, os.path.splitext(image_file)[0])
    
    # Crop objects
    stats = crop_objects(image, predictions, image_crops_dir, min_score, padding)
    
    return jsonify({
        'success': True,
        'stats': stats
    })
