"""
Module for custom model loading and management.
"""

import os
import json
import torch
import torchvision
from PIL import Image
import numpy as np
from src.inference.base import InferenceModel

class CustomModelLoader:
    """
    Class for loading and managing custom PyTorch models.
    """
    
    def __init__(self, models_dir):
        """
        Initialize the custom model loader.
        
        Args:
            models_dir: Directory to store custom models
        """
        self.models_dir = models_dir
        os.makedirs(models_dir, exist_ok=True)
    
    def save_model(self, model_file, class_map_file=None, model_name=None):
        """
        Save a custom model and its class mapping.
        
        Args:
            model_file: Path to the model file (.pth)
            class_map_file: Path to the class mapping file (JSON or TXT)
            model_name: Name to save the model as (optional)
            
        Returns:
            Dictionary with model information
        """
        try:
            # Generate model name if not provided
            if not model_name:
                model_name = os.path.splitext(os.path.basename(model_file))[0]
            
            # Create model directory
            model_dir = os.path.join(self.models_dir, model_name)
            os.makedirs(model_dir, exist_ok=True)
            
            # Copy model file
            model_dest = os.path.join(model_dir, f"{model_name}.pth")
            with open(model_file, 'rb') as src, open(model_dest, 'wb') as dst:
                dst.write(src.read())
            
            # Process class mapping
            class_map = {}
            if class_map_file:
                class_map = self._load_class_map(class_map_file)
                
                # Save class mapping
                class_map_dest = os.path.join(model_dir, f"{model_name}_classes.json")
                with open(class_map_dest, 'w') as f:
                    json.dump(class_map, f, indent=2)
            
            # Create model info
            model_info = {
                'name': model_name,
                'path': model_dest,
                'class_map': class_map,
                'class_map_path': os.path.join(model_dir, f"{model_name}_classes.json") if class_map else None
            }
            
            # Save model info
            info_path = os.path.join(model_dir, f"{model_name}_info.json")
            with open(info_path, 'w') as f:
                json.dump(model_info, f, indent=2)
            
            return model_info
        
        except Exception as e:
            return {'error': f'Error saving model: {str(e)}'}
    
    def load_model(self, model_name):
        """
        Load a custom model by name.
        
        Args:
            model_name: Name of the model to load
            
        Returns:
            Dictionary with model and class mapping
        """
        try:
            # Get model directory
            model_dir = os.path.join(self.models_dir, model_name)
            if not os.path.exists(model_dir):
                return {'error': f'Model {model_name} not found'}
            
            # Load model info
            info_path = os.path.join(model_dir, f"{model_name}_info.json")
            if not os.path.exists(info_path):
                return {'error': f'Model info for {model_name} not found'}
            
            with open(info_path, 'r') as f:
                model_info = json.load(f)
            
            # Load model file
            model_path = model_info.get('path')
            if not os.path.exists(model_path):
                return {'error': f'Model file {model_path} not found'}
            
            # Load class mapping
            class_map = {}
            class_map_path = model_info.get('class_map_path')
            if class_map_path and os.path.exists(class_map_path):
                with open(class_map_path, 'r') as f:
                    class_map = json.load(f)
            
            # Load PyTorch model
            model = torch.load(model_path, map_location=torch.device('cpu'))
            
            return {
                'model': model,
                'class_map': class_map,
                'info': model_info
            }
        
        except Exception as e:
            return {'error': f'Error loading model: {str(e)}'}
    
    def list_models(self):
        """
        List all available custom models.
        
        Returns:
            List of model information dictionaries
        """
        models = []
        
        try:
            # Get all subdirectories in models_dir
            for model_name in os.listdir(self.models_dir):
                model_dir = os.path.join(self.models_dir, model_name)
                if os.path.isdir(model_dir):
                    # Check for model info file
                    info_path = os.path.join(model_dir, f"{model_name}_info.json")
                    if os.path.exists(info_path):
                        with open(info_path, 'r') as f:
                            model_info = json.load(f)
                        models.append(model_info)
            
            return models
        
        except Exception as e:
            return {'error': f'Error listing models: {str(e)}'}
    
    def delete_model(self, model_name):
        """
        Delete a custom model.
        
        Args:
            model_name: Name of the model to delete
            
        Returns:
            Success status
        """
        try:
            # Get model directory
            model_dir = os.path.join(self.models_dir, model_name)
            if not os.path.exists(model_dir):
                return {'error': f'Model {model_name} not found'}
            
            # Delete all files in the directory
            for file_name in os.listdir(model_dir):
                file_path = os.path.join(model_dir, file_name)
                if os.path.isfile(file_path):
                    os.remove(file_path)
            
            # Delete the directory
            os.rmdir(model_dir)
            
            return {'success': True}
        
        except Exception as e:
            return {'error': f'Error deleting model: {str(e)}'}
    
    def _load_class_map(self, class_map_file):
        """
        Load class mapping from a file.
        
        Args:
            class_map_file: Path to the class mapping file (JSON or TXT)
            
        Returns:
            Dictionary with class mapping
        """
        # Check file extension
        ext = os.path.splitext(class_map_file)[1].lower()
        
        if ext == '.json':
            # Load JSON file
            with open(class_map_file, 'r') as f:
                return json.load(f)
        
        elif ext == '.txt':
            # Load TXT file (one class per line)
            class_map = {}
            with open(class_map_file, 'r') as f:
                for i, line in enumerate(f):
                    class_name = line.strip()
                    if class_name:
                        class_map[i] = class_name
            return class_map
        
        else:
            raise ValueError(f'Unsupported class map file format: {ext}')

class CustomModel(InferenceModel):
    """
    Class for running inference with custom PyTorch models.
    """
    
    def __init__(self, model, class_map=None, model_type='detection'):
        """
        Initialize the custom model.
        
        Args:
            model: PyTorch model
            class_map: Dictionary mapping class IDs to class names
            model_type: Type of model (detection, segmentation, instance)
        """
        self.model = model
        self.class_map = class_map or {}
        self.model_type = model_type
        self.type = self._map_model_type(model_type)
        
        # Set model to evaluation mode
        self.model.eval()
    
    def __call__(self, image):
        """
        Run inference on an image.
        
        Args:
            image: PIL Image object
            
        Returns:
            Dictionary with prediction results
        """
        # Convert PIL Image to tensor
        tensor = self._preprocess_image(image)
        
        # Run inference
        with torch.no_grad():
            outputs = self.model(tensor)
        
        # Process outputs based on model type
        if self.type == 'bounding_box':
            return self._process_detection_output(outputs, image)
        elif self.type == 'semantic_segmentation':
            return self._process_segmentation_output(outputs, image)
        elif self.type == 'instance_segmentation':
            return self._process_instance_output(outputs, image)
        else:
            return {'error': 'Unsupported model type'}
    
    def _preprocess_image(self, image):
        """
        Preprocess image for model input.
        
        Args:
            image: PIL Image object
            
        Returns:
            Tensor for model input
        """
        # Convert to tensor
        from torchvision import transforms
        
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        
        tensor = transform(image).unsqueeze(0)  # Add batch dimension
        
        return tensor
    
    def _process_detection_output(self, outputs, image):
        """
        Process detection model outputs.
        
        Args:
            outputs: Model outputs
            image: Original PIL Image
            
        Returns:
            Dictionary with detection results
        """
        # Handle different output formats
        if isinstance(outputs, dict):
            # Format like Faster R-CNN output
            boxes = outputs.get('boxes', [])
            labels = outputs.get('labels', [])
            scores = outputs.get('scores', [])
        elif isinstance(outputs, (list, tuple)) and len(outputs) >= 3:
            # Format like [boxes, labels, scores]
            boxes, labels, scores = outputs[:3]
        else:
            # Try to extract from generic output
            boxes = []
            labels = []
            scores = []
            
            # Attempt to find relevant tensors
            for key, value in outputs.items() if isinstance(outputs, dict) else enumerate(outputs):
                if isinstance(value, torch.Tensor):
                    if value.dim() == 2 and value.shape[1] == 4:
                        boxes = value
                    elif value.dim() == 1:
                        if 'score' in str(key).lower():
                            scores = value
                        elif 'label' in str(key).lower() or 'class' in str(key).lower():
                            labels = value
        
        # Convert tensors to lists
        boxes = boxes.cpu().numpy().tolist() if isinstance(boxes, torch.Tensor) else boxes
        labels = labels.cpu().numpy().tolist() if isinstance(labels, torch.Tensor) else labels
        scores = scores.cpu().numpy().tolist() if isinstance(scores, torch.Tensor) else scores
        
        # Get class names
        class_names = [self.class_map.get(str(label), f"Class {label}") for label in labels]
        
        return {
            'type': 'bounding_box',
            'boxes': boxes,
            'labels': labels,
            'scores': scores,
            'class_names': class_names
        }
    
    def _process_segmentation_output(self, outputs, image):
        """
        Process semantic segmentation model outputs.
        
        Args:
            outputs: Model outputs
            image: Original PIL Image
            
        Returns:
            Dictionary with segmentation results
        """
        # Handle different output formats
        if isinstance(outputs, dict):
            # Format like DeepLabV3 output
            mask = outputs.get('out', None)
        elif isinstance(outputs, torch.Tensor):
            # Direct tensor output
            mask = outputs
        else:
            # Try to find mask tensor
            mask = None
            for key, value in outputs.items() if isinstance(outputs, dict) else enumerate(outputs):
                if isinstance(value, torch.Tensor) and value.dim() >= 3:
                    mask = value
                    break
        
        if mask is None:
            return {'error': 'Could not extract mask from model output'}
        
        # Get class predictions
        if mask.dim() == 4:  # [batch, classes, height, width]
            mask = mask[0]  # Remove batch dimension
            mask = torch.argmax(mask, dim=0)  # Get class with highest probability
        
        # Convert to numpy
        mask = mask.cpu().numpy()
        
        # Get unique classes
        classes = np.unique(mask)
        classes = classes[classes != 0]  # Remove background class
        
        # Get class names
        class_names = [self.class_map.get(str(cls), f"Class {cls}") for cls in classes]
        
        return {
            'type': 'semantic_segmentation',
            'mask': mask,
            'classes': classes.tolist(),
            'class_names': class_names
        }
    
    def _process_instance_output(self, outputs, image):
        """
        Process instance segmentation model outputs.
        
        Args:
            outputs: Model outputs
            image: Original PIL Image
            
        Returns:
            Dictionary with instance segmentation results
        """
        # Handle different output formats
        if isinstance(outputs, dict):
            # Format like Mask R-CNN output
            boxes = outputs.get('boxes', [])
            masks = outputs.get('masks', [])
            labels = outputs.get('labels', [])
            scores = outputs.get('scores', [])
        elif isinstance(outputs, (list, tuple)) and len(outputs) >= 4:
            # Format like [boxes, masks, labels, scores]
            boxes, masks, labels, scores = outputs[:4]
        else:
            # Try to extract from generic output
            boxes = []
            masks = []
            labels = []
            scores = []
            
            # Attempt to find relevant tensors
            for key, value in outputs.items() if isinstance(outputs, dict) else enumerate(outputs):
                if isinstance(value, torch.Tensor):
                    if value.dim() == 2 and value.shape[1] == 4:
                        boxes = value
                    elif value.dim() >= 3:
                        masks = value
                    elif value.dim() == 1:
                        if 'score' in str(key).lower():
                            scores = value
                        elif 'label' in str(key).lower() or 'class' in str(key).lower():
                            labels = value
        
        # Convert tensors to lists/numpy arrays
        boxes = boxes.cpu().numpy().tolist() if isinstance(boxes, torch.Tensor) else boxes
        
        if isinstance(masks, torch.Tensor):
            if masks.dim() == 4:  # [batch, instances, height, width]
                masks = masks.squeeze(0)  # Remove batch dimension
            
            # Convert to binary masks
            masks = masks.cpu().numpy() > 0.5
        
        labels = labels.cpu().numpy().tolist() if isinstance(labels, torch.Tensor) else labels
        scores = scores.cpu().numpy().tolist() if isinstance(scores, torch.Tensor) else scores
        
        # Get class names
        class_names = [self.class_map.get(str(label), f"Class {label}") for label in labels]
        
        return {
            'type': 'instance_segmentation',
            'boxes': boxes,
            'masks': masks,
            'labels': labels,
            'scores': scores,
            'class_names': class_names
        }
    
    def _map_model_type(self, model_type):
        """
        Map model type string to internal type.
        
        Args:
            model_type: User-provided model type
            
        Returns:
            Internal model type
        """
        model_type = model_type.lower()
        
        if model_type in ['detection', 'bbox', 'bounding_box', 'object_detection']:
            return 'bounding_box'
        elif model_type in ['segmentation', 'semantic', 'semantic_segmentation']:
            return 'semantic_segmentation'
        elif model_type in ['instance', 'instance_segmentation', 'mask']:
            return 'instance_segmentation'
        else:
            # Try to infer from model architecture
            model_name = self.model.__class__.__name__.lower()
            
            if 'mask' in model_name or 'rcnn' in model_name:
                return 'instance_segmentation'
            elif 'segmentation' in model_name or 'deeplab' in model_name or 'fcn' in model_name:
                return 'semantic_segmentation'
            elif 'detection' in model_name or 'faster' in model_name or 'yolo' in model_name:
                return 'bounding_box'
            else:
                # Default to bounding box
                return 'bounding_box'
