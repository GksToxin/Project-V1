"""
Module for filtering inference results based on class selection.
"""

def filter_predictions_by_classes(predictions, selected_classes):
    """
    Filter prediction results to include only selected classes.
    
    Args:
        predictions: Dictionary containing prediction results
        selected_classes: List of class indices to keep
        
    Returns:
        Filtered prediction results
    """
    prediction_type = predictions.get('type', '')
    
    if not selected_classes:
        # If no classes are selected, return all predictions
        return predictions
    
    if prediction_type == 'semantic_segmentation':
        return filter_semantic_segmentation(predictions, selected_classes)
    elif prediction_type == 'instance_segmentation':
        return filter_instance_segmentation(predictions, selected_classes)
    elif prediction_type == 'bounding_box':
        return filter_bounding_box(predictions, selected_classes)
    else:
        # If unknown prediction type, return unfiltered
        return predictions

def filter_semantic_segmentation(predictions, selected_classes):
    """
    Filter semantic segmentation results to include only selected classes.
    
    Args:
        predictions: Semantic segmentation prediction results
        selected_classes: List of class indices to keep
        
    Returns:
        Filtered semantic segmentation results
    """
    # Create a copy of the predictions to avoid modifying the original
    filtered = predictions.copy()
    
    # Get the original mask and classes
    mask = predictions['mask']
    classes = predictions['classes']
    class_names = predictions['class_names']
    
    # Create lists for filtered classes and class names
    filtered_classes = []
    filtered_class_names = []
    
    # Filter classes and class names
    for i, class_id in enumerate(classes):
        if class_id in selected_classes:
            filtered_classes.append(class_id)
            filtered_class_names.append(class_names[i])
    
    # Update the filtered predictions
    filtered['classes'] = filtered_classes
    filtered['class_names'] = filtered_class_names
    
    return filtered

def filter_instance_segmentation(predictions, selected_classes):
    """
    Filter instance segmentation results to include only selected classes.
    
    Args:
        predictions: Instance segmentation prediction results
        selected_classes: List of class indices to keep
        
    Returns:
        Filtered instance segmentation results
    """
    # Create a copy of the predictions to avoid modifying the original
    filtered = predictions.copy()
    
    # Get the original data
    boxes = predictions['boxes']
    masks = predictions['masks']
    labels = predictions['labels']
    scores = predictions['scores']
    class_names = predictions['class_names']
    
    # Create lists for filtered data
    filtered_boxes = []
    filtered_masks = []
    filtered_labels = []
    filtered_scores = []
    filtered_class_names = []
    
    # Filter based on selected classes
    for i, label in enumerate(labels):
        if label in selected_classes:
            filtered_boxes.append(boxes[i])
            filtered_masks.append(masks[i])
            filtered_labels.append(labels[i])
            filtered_scores.append(scores[i])
            filtered_class_names.append(class_names[i])
    
    # Update the filtered predictions
    filtered['boxes'] = filtered_boxes
    filtered['masks'] = filtered_masks
    filtered['labels'] = filtered_labels
    filtered['scores'] = filtered_scores
    filtered['class_names'] = filtered_class_names
    
    return filtered

def filter_bounding_box(predictions, selected_classes):
    """
    Filter bounding box results to include only selected classes.
    
    Args:
        predictions: Bounding box prediction results
        selected_classes: List of class indices to keep
        
    Returns:
        Filtered bounding box results
    """
    # Create a copy of the predictions to avoid modifying the original
    filtered = predictions.copy()
    
    # Get the original data
    boxes = predictions['boxes']
    labels = predictions['labels']
    scores = predictions['scores']
    class_names = predictions['class_names']
    
    # Create lists for filtered data
    filtered_boxes = []
    filtered_labels = []
    filtered_scores = []
    filtered_class_names = []
    
    # Filter based on selected classes
    for i, label in enumerate(labels):
        if label in selected_classes:
            filtered_boxes.append(boxes[i])
            filtered_labels.append(labels[i])
            filtered_scores.append(scores[i])
            filtered_class_names.append(class_names[i])
    
    # Update the filtered predictions
    filtered['boxes'] = filtered_boxes
    filtered['labels'] = filtered_labels
    filtered['scores'] = filtered_scores
    filtered['class_names'] = filtered_class_names
    
    return filtered
