import torch
import torchvision
from torchvision.models.segmentation import deeplabv3_resnet101
from torchvision import transforms
import numpy as np
from PIL import Image

from src.inference.base import BaseInference

class SemanticSegmentation(BaseInference):
    """
    Semantic segmentation inference using DeepLabV3 model.
    """
    
    def __init__(self, device=None):
        """
        Initialize the semantic segmentation model.
        
        Args:
            device: The device to run inference on ('cuda' or 'cpu').
                   If None, will use CUDA if available.
        """
        super().__init__(device)
        self.transform = None
        self.type = 'semantic_segmentation'  # Added type attribute for consistency
        # COCO classes that DeepLabV3 was trained on
        self.class_names = [
            'background', 'aeroplane', 'bicycle', 'bird', 'boat', 'bottle', 'bus',
            'car', 'cat', 'chair', 'cow', 'diningtable', 'dog', 'horse', 'motorbike',
            'person', 'pottedplant', 'sheep', 'sofa', 'train', 'tvmonitor'
        ]
    
    def load_model(self):
        """
        Load the pre-trained DeepLabV3 model.
        """
        self.model = deeplabv3_resnet101(pretrained=True)
        self.model.eval()
        self.model.to(self.device)
        
        # Define the transformation pipeline
        self.transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                                std=[0.229, 0.224, 0.225])
        ])
    
    def preprocess(self, image):
        """
        Preprocess the input image for the model.
        
        Args:
            image: Input image (numpy array or PIL Image)
            
        Returns:
            Preprocessed image tensor
        """
        if isinstance(image, np.ndarray):
            image = Image.fromarray(image)
        
        # Ensure the image is in RGB format
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        # Apply transformations
        input_tensor = self.transform(image)
        # Add batch dimension
        input_batch = input_tensor.unsqueeze(0).to(self.device)
        
        return input_batch
    
    def predict(self, input_batch):
        """
        Run inference on the preprocessed input.
        
        Args:
            input_batch: Preprocessed input tensor
            
        Returns:
            Raw model outputs
        """
        with torch.no_grad():
            outputs = self.model(input_batch)
        
        return outputs
    
    def postprocess(self, outputs):
        """
        Process the raw model outputs into a standardized format.
        
        Args:
            outputs: Raw model outputs
            
        Returns:
            Dictionary containing:
                - 'mask': Segmentation mask as numpy array
                - 'classes': List of class indices present in the mask
                - 'class_names': List of class names present in the mask
        """
        # Extract the segmentation mask from the output dictionary
        output = outputs['out'][0]
        
        # Get the predicted class for each pixel
        mask = torch.argmax(output, dim=0).cpu().numpy()
        
        # Get unique classes in the mask (excluding background class 0 if needed)
        unique_classes = np.unique(mask)
        present_classes = [int(cls) for cls in unique_classes if cls > 0]  # Exclude background if needed
        
        # Get class names for the present classes
        present_class_names = [self.class_names[cls] for cls in present_classes]
        
        return {
            'mask': mask,
            'classes': present_classes,
            'class_names': present_class_names,
            'type': 'semantic_segmentation'
        }
