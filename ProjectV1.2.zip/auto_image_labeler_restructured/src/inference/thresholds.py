"""
Module for managing confidence thresholds for inference results.
"""

def apply_thresholds(predictions, global_threshold=None, class_thresholds=None):
    """
    Apply confidence thresholds to prediction results.
    
    Args:
        predictions: Dictionary containing prediction results
        global_threshold: Global confidence threshold to apply to all classes
        class_thresholds: Dictionary mapping class indices to specific thresholds
        
    Returns:
        Filtered prediction results based on thresholds
    """
    prediction_type = predictions.get('type', '')
    
    # If no thresholds provided, return unmodified predictions
    if global_threshold is None and (class_thresholds is None or not class_thresholds):
        return predictions
    
    # Initialize class_thresholds if None
    if class_thresholds is None:
        class_thresholds = {}
    
    if prediction_type == 'semantic_segmentation':
        # Semantic segmentation doesn't have confidence scores
        return predictions
    elif prediction_type == 'instance_segmentation':
        return apply_thresholds_instance(predictions, global_threshold, class_thresholds)
    elif prediction_type == 'bounding_box':
        return apply_thresholds_bbox(predictions, global_threshold, class_thresholds)
    else:
        # If unknown prediction type, return unfiltered
        return predictions

def apply_thresholds_instance(predictions, global_threshold, class_thresholds):
    """
    Apply confidence thresholds to instance segmentation results.
    
    Args:
        predictions: Instance segmentation prediction results
        global_threshold: Global confidence threshold
        class_thresholds: Dictionary mapping class indices to specific thresholds
        
    Returns:
        Filtered instance segmentation results
    """
    # Create a copy of the predictions to avoid modifying the original
    filtered = predictions.copy()
    
    # Get the original data
    boxes = predictions['boxes']
    masks = predictions['masks']
    labels = predictions['labels']
    scores = predictions['scores']
    class_names = predictions['class_names']
    
    # Create lists for filtered data
    filtered_boxes = []
    filtered_masks = []
    filtered_labels = []
    filtered_scores = []
    filtered_class_names = []
    
    # Apply thresholds
    for i, (label, score) in enumerate(zip(labels, scores)):
        # Determine threshold for this class
        threshold = class_thresholds.get(label, global_threshold)
        
        # If no threshold for this class, use the score as is
        if threshold is None:
            threshold = 0
        
        # Keep only predictions above threshold
        if score >= threshold:
            filtered_boxes.append(boxes[i])
            filtered_masks.append(masks[i])
            filtered_labels.append(labels[i])
            filtered_scores.append(scores[i])
            filtered_class_names.append(class_names[i])
    
    # Update the filtered predictions
    filtered['boxes'] = filtered_boxes
    filtered['masks'] = filtered_masks
    filtered['labels'] = filtered_labels
    filtered['scores'] = filtered_scores
    filtered['class_names'] = filtered_class_names
    
    return filtered

def apply_thresholds_bbox(predictions, global_threshold, class_thresholds):
    """
    Apply confidence thresholds to bounding box results.
    
    Args:
        predictions: Bounding box prediction results
        global_threshold: Global confidence threshold
        class_thresholds: Dictionary mapping class indices to specific thresholds
        
    Returns:
        Filtered bounding box results
    """
    # Create a copy of the predictions to avoid modifying the original
    filtered = predictions.copy()
    
    # Get the original data
    boxes = predictions['boxes']
    labels = predictions['labels']
    scores = predictions['scores']
    class_names = predictions['class_names']
    
    # Create lists for filtered data
    filtered_boxes = []
    filtered_labels = []
    filtered_scores = []
    filtered_class_names = []
    
    # Apply thresholds
    for i, (label, score) in enumerate(zip(labels, scores)):
        # Determine threshold for this class
        threshold = class_thresholds.get(label, global_threshold)
        
        # If no threshold for this class, use the score as is
        if threshold is None:
            threshold = 0
        
        # Keep only predictions above threshold
        if score >= threshold:
            filtered_boxes.append(boxes[i])
            filtered_labels.append(labels[i])
            filtered_scores.append(scores[i])
            filtered_class_names.append(class_names[i])
    
    # Update the filtered predictions
    filtered['boxes'] = filtered_boxes
    filtered['labels'] = filtered_labels
    filtered['scores'] = filtered_scores
    filtered['class_names'] = filtered_class_names
    
    return filtered

def get_available_classes(predictions):
    """
    Get a list of available classes in the predictions.
    
    Args:
        predictions: Dictionary containing prediction results
        
    Returns:
        List of dictionaries with class information {id, name, count}
    """
    prediction_type = predictions.get('type', '')
    
    if prediction_type == 'semantic_segmentation':
        classes = predictions.get('classes', [])
        class_names = predictions.get('class_names', [])
        
        # Count pixels for each class
        mask = predictions.get('mask', None)
        class_counts = {}
        if mask is not None:
            import numpy as np
            unique, counts = np.unique(mask, return_counts=True)
            class_counts = dict(zip(unique, counts))
        
        result = []
        for i, class_id in enumerate(classes):
            if i < len(class_names):
                result.append({
                    'id': int(class_id),
                    'name': class_names[i],
                    'count': class_counts.get(class_id, 0)
                })
        return result
    
    elif prediction_type in ['instance_segmentation', 'bounding_box']:
        labels = predictions.get('labels', [])
        class_names = predictions.get('class_names', [])
        
        # Count instances of each class
        class_counts = {}
        for label in labels:
            class_counts[label] = class_counts.get(label, 0) + 1
        
        # Create unique class list
        unique_classes = {}
        for i, label in enumerate(labels):
            if i < len(class_names) and label not in unique_classes:
                unique_classes[label] = class_names[i]
        
        result = []
        for class_id, name in unique_classes.items():
            result.append({
                'id': int(class_id),
                'name': name,
                'count': class_counts.get(class_id, 0)
            })
        return result
    
    else:
        return []
