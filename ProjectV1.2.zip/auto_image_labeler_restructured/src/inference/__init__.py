from src.inference.base import BaseInference
from src.inference.semantic import SemanticSegmentation
from src.inference.instance import InstanceSegmentation
from src.inference.detection import BoundingBoxDetection

# Factory function to create the appropriate inference model
def create_inference_model(label_type, device=None):
    """
    Create an inference model based on the specified label type.
    
    Args:
        label_type: Type of labeling ('semantic', 'instance', or 'bbox')
        device: Device to run inference on ('cuda' or 'cpu')
        
    Returns:
        An instance of the appropriate inference model
    """
    if label_type == 'semantic':
        return SemanticSegmentation(device=device)
    elif label_type == 'instance':
        return InstanceSegmentation(device=device)
    elif label_type == 'bbox':
        return BoundingBoxDetection(device=device)
    else:
        raise ValueError(f"Unsupported label type: {label_type}")
