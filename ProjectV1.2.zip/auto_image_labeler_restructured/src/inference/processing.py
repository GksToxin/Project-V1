"""
Module for pre-processing and post-processing pipeline options.
"""

import cv2
import numpy as np
from PIL import Image

class PreProcessingPipeline:
    """
    Class for applying pre-processing operations to images before inference.
    """
    
    def __init__(self, options=None):
        """
        Initialize the pre-processing pipeline with options.
        
        Args:
            options: Dictionary of pre-processing options
        """
        self.options = options or {}
        
    def process(self, image):
        """
        Apply pre-processing operations to an image.
        
        Args:
            image: PIL Image object
            
        Returns:
            Processed PIL Image
        """
        # Convert PIL Image to numpy array
        img_np = np.array(image)
        
        # Apply resize if specified
        if self.options.get('resize', False):
            target_size = self.options.get('resize_dimensions', (640, 640))
            img_np = cv2.resize(img_np, target_size, interpolation=cv2.INTER_AREA)
        
        # Apply normalization if specified
        if self.options.get('normalize', False):
            img_np = img_np.astype(np.float32) / 255.0
            
            # Apply mean and std normalization if specified
            if self.options.get('normalize_with_imagenet', False):
                # ImageNet mean and std
                mean = np.array([0.485, 0.456, 0.406])
                std = np.array([0.229, 0.224, 0.225])
                
                # Apply normalization
                img_np = (img_np - mean) / std
        
        # Apply grayscale if specified
        if self.options.get('grayscale', False):
            if len(img_np.shape) == 3 and img_np.shape[2] == 3:
                img_np = cv2.cvtColor(img_np, cv2.COLOR_RGB2GRAY)
                # Convert back to 3 channels if needed
                if self.options.get('maintain_3_channels', True):
                    img_np = np.stack([img_np, img_np, img_np], axis=2)
        
        # Apply gaussian blur if specified
        if self.options.get('gaussian_blur', False):
            kernel_size = self.options.get('blur_kernel_size', 5)
            # Ensure kernel size is odd
            if kernel_size % 2 == 0:
                kernel_size += 1
            img_np = cv2.GaussianBlur(img_np, (kernel_size, kernel_size), 0)
        
        # Convert back to PIL Image
        if img_np.dtype == np.float32:
            # Convert back to uint8 for PIL
            img_np = (img_np * 255).astype(np.uint8)
        
        return Image.fromarray(img_np)

class PostProcessingPipeline:
    """
    Class for applying post-processing operations to predictions after inference.
    """
    
    def __init__(self, options=None):
        """
        Initialize the post-processing pipeline with options.
        
        Args:
            options: Dictionary of post-processing options
        """
        self.options = options or {}
    
    def process(self, predictions):
        """
        Apply post-processing operations to predictions.
        
        Args:
            predictions: Dictionary containing prediction results
            
        Returns:
            Processed predictions
        """
        prediction_type = predictions.get('type', '')
        
        if prediction_type == 'semantic_segmentation':
            return self._process_semantic(predictions)
        elif prediction_type == 'instance_segmentation':
            return self._process_instance(predictions)
        elif prediction_type == 'bounding_box':
            return self._process_bbox(predictions)
        else:
            return predictions
    
    def _process_semantic(self, predictions):
        """Process semantic segmentation predictions."""
        processed = predictions.copy()
        mask = predictions.get('mask', None)
        
        if mask is None:
            return processed
        
        # Apply mask cleanup if specified
        if self.options.get('mask_cleanup', False):
            # Convert to numpy array if not already
            if not isinstance(mask, np.ndarray):
                mask = np.array(mask)
            
            # Apply morphological operations
            kernel_size = self.options.get('morph_kernel_size', 3)
            kernel = np.ones((kernel_size, kernel_size), np.uint8)
            
            if self.options.get('apply_opening', False):
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            
            if self.options.get('apply_closing', False):
                mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            
            processed['mask'] = mask
        
        return processed
    
    def _process_instance(self, predictions):
        """Process instance segmentation predictions."""
        processed = predictions.copy()
        
        # Apply non-maximum suppression if specified
        if self.options.get('apply_nms', False):
            boxes = predictions.get('boxes', [])
            scores = predictions.get('scores', [])
            labels = predictions.get('labels', [])
            masks = predictions.get('masks', [])
            class_names = predictions.get('class_names', [])
            
            if len(boxes) > 0 and len(scores) > 0:
                # Convert to numpy arrays
                boxes_np = np.array(boxes)
                scores_np = np.array(scores)
                labels_np = np.array(labels)
                
                # Apply NMS
                iou_threshold = self.options.get('nms_iou_threshold', 0.5)
                indices = self._non_max_suppression(boxes_np, scores_np, labels_np, iou_threshold)
                
                # Filter predictions
                processed['boxes'] = [boxes[i] for i in indices]
                processed['scores'] = [scores[i] for i in indices]
                processed['labels'] = [labels[i] for i in indices]
                processed['masks'] = [masks[i] for i in indices] if masks else []
                processed['class_names'] = [class_names[i] for i in indices] if class_names else []
        
        # Apply mask cleanup if specified
        if self.options.get('mask_cleanup', False) and 'masks' in processed:
            masks = processed['masks']
            cleaned_masks = []
            
            for mask in masks:
                # Convert to numpy array if not already
                if not isinstance(mask, np.ndarray):
                    mask = np.array(mask)
                
                # Apply morphological operations
                kernel_size = self.options.get('morph_kernel_size', 3)
                kernel = np.ones((kernel_size, kernel_size), np.uint8)
                
                if self.options.get('apply_opening', False):
                    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
                
                if self.options.get('apply_closing', False):
                    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
                
                cleaned_masks.append(mask)
            
            processed['masks'] = cleaned_masks
        
        return processed
    
    def _process_bbox(self, predictions):
        """Process bounding box predictions."""
        processed = predictions.copy()
        
        # Apply non-maximum suppression if specified
        if self.options.get('apply_nms', False):
            boxes = predictions.get('boxes', [])
            scores = predictions.get('scores', [])
            labels = predictions.get('labels', [])
            class_names = predictions.get('class_names', [])
            
            if len(boxes) > 0 and len(scores) > 0:
                # Convert to numpy arrays
                boxes_np = np.array(boxes)
                scores_np = np.array(scores)
                labels_np = np.array(labels)
                
                # Apply NMS
                iou_threshold = self.options.get('nms_iou_threshold', 0.5)
                indices = self._non_max_suppression(boxes_np, scores_np, labels_np, iou_threshold)
                
                # Filter predictions
                processed['boxes'] = [boxes[i] for i in indices]
                processed['scores'] = [scores[i] for i in indices]
                processed['labels'] = [labels[i] for i in indices]
                processed['class_names'] = [class_names[i] for i in indices] if class_names else []
        
        return processed
    
    def _non_max_suppression(self, boxes, scores, labels, iou_threshold):
        """
        Apply non-maximum suppression to boxes.
        
        Args:
            boxes: Numpy array of boxes [x1, y1, x2, y2]
            scores: Numpy array of confidence scores
            labels: Numpy array of class labels
            iou_threshold: IoU threshold for NMS
            
        Returns:
            List of indices of boxes to keep
        """
        # Sort by score
        order = scores.argsort()[::-1]
        keep = []
        
        while order.size > 0:
            i = order[0]
            keep.append(i)
            
            # Compute IoU of the picked box with the rest
            ious = self._box_iou(boxes[i], boxes[order[1:]])
            
            # Identify boxes with IoU over threshold and same class
            inds = np.where(ious <= iou_threshold)[0]
            
            # If using class-aware NMS, also check for same class
            if self.options.get('class_aware_nms', True):
                same_class = labels[order[1:]] == labels[i]
                inds = np.where(np.logical_or(ious <= iou_threshold, ~same_class))[0]
            
            order = order[inds + 1]
        
        return keep
    
    def _box_iou(self, box, boxes):
        """
        Compute IoU between a box and an array of boxes.
        
        Args:
            box: Single box [x1, y1, x2, y2]
            boxes: Array of boxes [N, 4]
            
        Returns:
            Array of IoU values
        """
        # Calculate intersection areas
        x1 = np.maximum(box[0], boxes[:, 0])
        y1 = np.maximum(box[1], boxes[:, 1])
        x2 = np.minimum(box[2], boxes[:, 2])
        y2 = np.minimum(box[3], boxes[:, 3])
        
        intersection = np.maximum(0, x2 - x1) * np.maximum(0, y2 - y1)
        
        # Calculate union areas
        box_area = (box[2] - box[0]) * (box[3] - box[1])
        boxes_area = (boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1])
        union = box_area + boxes_area - intersection
        
        # Calculate IoU
        iou = intersection / union
        
        return iou
