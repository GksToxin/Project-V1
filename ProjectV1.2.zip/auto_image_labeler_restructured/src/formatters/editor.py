"""
Module for interactive correction of predictions.
"""

import numpy as np
import cv2
from PIL import Image

class LabelEditor:
    """
    Class for editing and correcting prediction labels.
    """
    
    def __init__(self, predictions, image):
        """
        Initialize the label editor with predictions and image.
        
        Args:
            predictions: Dictionary containing prediction results
            image: PIL Image object
        """
        self.predictions = predictions
        self.image = image
        self.prediction_type = predictions.get('type', '')
        self.edited = False
    
    def get_editable_data(self):
        """
        Get data in a format suitable for frontend editing.
        
        Returns:
            Dictionary with editable data
        """
        if self.prediction_type == 'semantic_segmentation':
            return self._get_semantic_editable_data()
        elif self.prediction_type == 'instance_segmentation':
            return self._get_instance_editable_data()
        elif self.prediction_type == 'bounding_box':
            return self._get_bbox_editable_data()
        else:
            return {'error': 'Unsupported prediction type'}
    
    def _get_semantic_editable_data(self):
        """Get editable data for semantic segmentation."""
        mask = self.predictions.get('mask', None)
        classes = self.predictions.get('classes', [])
        class_names = self.predictions.get('class_names', [])
        
        if mask is None:
            return {'error': 'No mask data found'}
        
        # Convert mask to colored image for visualization
        colored_mask = self._colorize_mask(mask)
        
        return {
            'type': 'semantic_segmentation',
            'mask': self._encode_mask(mask),
            'colored_mask': self._encode_image(colored_mask),
            'classes': classes,
            'class_names': class_names
        }
    
    def _get_instance_editable_data(self):
        """Get editable data for instance segmentation."""
        boxes = self.predictions.get('boxes', [])
        masks = self.predictions.get('masks', [])
        labels = self.predictions.get('labels', [])
        scores = self.predictions.get('scores', [])
        class_names = self.predictions.get('class_names', [])
        
        instances = []
        for i in range(len(boxes)):
            if i < len(masks) and i < len(labels) and i < len(scores):
                instance = {
                    'id': i,
                    'box': boxes[i],
                    'mask': self._encode_mask(masks[i]),
                    'label': int(labels[i]),
                    'class_name': class_names[i] if i < len(class_names) else f"Class {labels[i]}",
                    'score': float(scores[i])
                }
                instances.append(instance)
        
        return {
            'type': 'instance_segmentation',
            'instances': instances,
            'image_width': self.image.width,
            'image_height': self.image.height
        }
    
    def _get_bbox_editable_data(self):
        """Get editable data for bounding box detection."""
        boxes = self.predictions.get('boxes', [])
        labels = self.predictions.get('labels', [])
        scores = self.predictions.get('scores', [])
        class_names = self.predictions.get('class_names', [])
        
        bboxes = []
        for i in range(len(boxes)):
            if i < len(labels) and i < len(scores):
                bbox = {
                    'id': i,
                    'box': boxes[i],
                    'label': int(labels[i]),
                    'class_name': class_names[i] if i < len(class_names) else f"Class {labels[i]}",
                    'score': float(scores[i])
                }
                bboxes.append(bbox)
        
        return {
            'type': 'bounding_box',
            'bboxes': bboxes,
            'image_width': self.image.width,
            'image_height': self.image.height
        }
    
    def apply_edits(self, edits):
        """
        Apply edits to the predictions.
        
        Args:
            edits: Dictionary containing edit operations
            
        Returns:
            Updated predictions
        """
        edit_type = edits.get('type', '')
        
        if edit_type == 'semantic_segmentation':
            return self._apply_semantic_edits(edits)
        elif edit_type == 'instance_segmentation':
            return self._apply_instance_edits(edits)
        elif edit_type == 'bounding_box':
            return self._apply_bbox_edits(edits)
        else:
            return self.predictions
    
    def _apply_semantic_edits(self, edits):
        """Apply edits to semantic segmentation predictions."""
        # Semantic segmentation editing is more complex and would require
        # pixel-level editing tools, which is beyond the scope of this implementation
        return self.predictions
    
    def _apply_instance_edits(self, edits):
        """Apply edits to instance segmentation predictions."""
        edited_instances = edits.get('instances', [])
        
        if not edited_instances:
            return self.predictions
        
        # Create a copy of the predictions to avoid modifying the original
        edited_predictions = self.predictions.copy()
        
        # Get the original data
        boxes = self.predictions.get('boxes', [])
        masks = self.predictions.get('masks', [])
        labels = self.predictions.get('labels', [])
        scores = self.predictions.get('scores', [])
        class_names = self.predictions.get('class_names', [])
        
        # Create lists for edited data
        edited_boxes = []
        edited_masks = []
        edited_labels = []
        edited_scores = []
        edited_class_names = []
        
        # Process each edited instance
        for instance in edited_instances:
            instance_id = instance.get('id')
            action = instance.get('action', 'update')
            
            if action == 'delete':
                # Skip this instance (effectively deleting it)
                continue
            
            if action == 'update' and 0 <= instance_id < len(boxes):
                # Update the instance with edited values
                box = instance.get('box', boxes[instance_id])
                mask = self._decode_mask(instance.get('mask')) if instance.get('mask') else masks[instance_id]
                label = instance.get('label', labels[instance_id])
                score = instance.get('score', scores[instance_id])
                class_name = instance.get('class_name', class_names[instance_id] if instance_id < len(class_names) else f"Class {label}")
                
                edited_boxes.append(box)
                edited_masks.append(mask)
                edited_labels.append(label)
                edited_scores.append(score)
                edited_class_names.append(class_name)
            
            elif action == 'add':
                # Add a new instance
                box = instance.get('box', [0, 0, 10, 10])
                mask = self._decode_mask(instance.get('mask')) if instance.get('mask') else np.zeros((self.image.height, self.image.width), dtype=np.uint8)
                label = instance.get('label', 0)
                score = instance.get('score', 1.0)
                class_name = instance.get('class_name', f"Class {label}")
                
                edited_boxes.append(box)
                edited_masks.append(mask)
                edited_labels.append(label)
                edited_scores.append(score)
                edited_class_names.append(class_name)
        
        # Update the edited predictions
        edited_predictions['boxes'] = edited_boxes
        edited_predictions['masks'] = edited_masks
        edited_predictions['labels'] = edited_labels
        edited_predictions['scores'] = edited_scores
        edited_predictions['class_names'] = edited_class_names
        
        self.edited = True
        return edited_predictions
    
    def _apply_bbox_edits(self, edits):
        """Apply edits to bounding box predictions."""
        edited_bboxes = edits.get('bboxes', [])
        
        if not edited_bboxes:
            return self.predictions
        
        # Create a copy of the predictions to avoid modifying the original
        edited_predictions = self.predictions.copy()
        
        # Get the original data
        boxes = self.predictions.get('boxes', [])
        labels = self.predictions.get('labels', [])
        scores = self.predictions.get('scores', [])
        class_names = self.predictions.get('class_names', [])
        
        # Create lists for edited data
        edited_boxes = []
        edited_labels = []
        edited_scores = []
        edited_class_names = []
        
        # Process each edited bbox
        for bbox in edited_bboxes:
            bbox_id = bbox.get('id')
            action = bbox.get('action', 'update')
            
            if action == 'delete':
                # Skip this bbox (effectively deleting it)
                continue
            
            if action == 'update' and 0 <= bbox_id < len(boxes):
                # Update the bbox with edited values
                box = bbox.get('box', boxes[bbox_id])
                label = bbox.get('label', labels[bbox_id])
                score = bbox.get('score', scores[bbox_id])
                class_name = bbox.get('class_name', class_names[bbox_id] if bbox_id < len(class_names) else f"Class {label}")
                
                edited_boxes.append(box)
                edited_labels.append(label)
                edited_scores.append(score)
                edited_class_names.append(class_name)
            
            elif action == 'add':
                # Add a new bbox
                box = bbox.get('box', [0, 0, 10, 10])
                label = bbox.get('label', 0)
                score = bbox.get('score', 1.0)
                class_name = bbox.get('class_name', f"Class {label}")
                
                edited_boxes.append(box)
                edited_labels.append(label)
                edited_scores.append(score)
                edited_class_names.append(class_name)
        
        # Update the edited predictions
        edited_predictions['boxes'] = edited_boxes
        edited_predictions['labels'] = edited_labels
        edited_predictions['scores'] = edited_scores
        edited_predictions['class_names'] = edited_class_names
        
        self.edited = True
        return edited_predictions
    
    def _colorize_mask(self, mask):
        """
        Convert a class mask to a colored image for visualization.
        
        Args:
            mask: 2D numpy array with class indices
            
        Returns:
            PIL Image with colored mask
        """
        # Create a colormap
        colormap = np.random.randint(0, 255, size=(256, 3), dtype=np.uint8)
        colormap[0] = [0, 0, 0]  # Background is black
        
        # Apply colormap to mask
        colored_mask = colormap[mask]
        
        # Convert to PIL Image
        return Image.fromarray(colored_mask)
    
    def _encode_mask(self, mask):
        """
        Encode mask as base64 string for transmission to frontend.
        
        Args:
            mask: 2D numpy array
            
        Returns:
            Base64 encoded string
        """
        import base64
        import io
        
        # Convert mask to image
        if isinstance(mask, np.ndarray):
            # Normalize to 0-255 range
            if mask.dtype != np.uint8:
                mask = (mask * 255).astype(np.uint8)
            
            # Convert to PIL Image
            mask_img = Image.fromarray(mask)
        else:
            mask_img = mask
        
        # Encode as PNG
        buffer = io.BytesIO()
        mask_img.save(buffer, format='PNG')
        
        # Convert to base64
        return base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    def _encode_image(self, image):
        """
        Encode image as base64 string for transmission to frontend.
        
        Args:
            image: PIL Image
            
        Returns:
            Base64 encoded string
        """
        import base64
        import io
        
        # Encode as PNG
        buffer = io.BytesIO()
        image.save(buffer, format='PNG')
        
        # Convert to base64
        return base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    def _decode_mask(self, encoded_mask):
        """
        Decode base64 string to mask.
        
        Args:
            encoded_mask: Base64 encoded string
            
        Returns:
            2D numpy array
        """
        import base64
        import io
        
        # Decode base64
        mask_data = base64.b64decode(encoded_mask)
        
        # Convert to PIL Image
        mask_img = Image.open(io.BytesIO(mask_data))
        
        # Convert to numpy array
        return np.array(mask_img)
