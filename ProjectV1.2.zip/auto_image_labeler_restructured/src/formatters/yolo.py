import os
import numpy as np
from PIL import Image

from src.formatters.base import BaseFormatter

class YOLOFormatter(BaseFormatter):
    """
    Formatter for converting model predictions to YOLO format.
    """
    
    def __init__(self):
        """
        Initialize the YOLO formatter.
        """
        super().__init__()
        self.class_map = {}  # Maps class names to YOLO class indices
    
    def _normalize_box(self, box, image_width, image_height):
        """
        Convert absolute coordinates to YOLO format (normalized center x, center y, width, height).
        
        Args:
            box: Bounding box in format [x1, y1, x2, y2]
            image_width: Width of the image
            image_height: Height of the image
            
        Returns:
            Normalized box in YOLO format [center_x, center_y, width, height]
        """
        x1, y1, x2, y2 = box
        
        # Calculate center coordinates
        center_x = (x1 + x2) / 2.0
        center_y = (y1 + y2) / 2.0
        
        # Calculate width and height
        width = x2 - x1
        height = y2 - y1
        
        # Normalize by image dimensions
        center_x /= image_width
        center_y /= image_height
        width /= image_width
        height /= image_height
        
        return [center_x, center_y, width, height]
    
    def _ensure_class_index(self, class_name):
        """
        Ensure the class has an index in the YOLO class map.
        
        Args:
            class_name: Class name
            
        Returns:
            Class index
        """
        if class_name not in self.class_map:
            self.class_map[class_name] = len(self.class_map)
        return self.class_map[class_name]
    
    def format_semantic_segmentation(self, predictions, image_info):
        """
        Format semantic segmentation predictions to YOLO format.
        For semantic segmentation, we extract bounding boxes from the mask.
        
        Args:
            predictions: Semantic segmentation predictions
            image_info: Image metadata
            
        Returns:
            List of YOLO annotations
        """
        mask = predictions['mask']
        classes = predictions['classes']
        class_names = predictions['class_names']
        
        image_width = image_info["width"]
        image_height = image_info["height"]
        
        annotations = []
        
        # Process each class in the mask
        for i, class_id in enumerate(classes):
            # Ensure class has an index
            yolo_class_idx = self._ensure_class_index(class_names[i])
            
            # Create binary mask for this class
            binary_mask = (mask == class_id).astype(np.uint8)
            
            # Skip if no pixels for this class
            if np.sum(binary_mask) == 0:
                continue
            
            # Find contours in the mask to get bounding boxes
            # Since we don't have OpenCV directly, we'll use a simple approach
            # to find the bounding box of the mask
            y_indices, x_indices = np.where(binary_mask > 0)
            if len(y_indices) == 0 or len(x_indices) == 0:
                continue
                
            x1, y1 = np.min(x_indices), np.min(y_indices)
            x2, y2 = np.max(x_indices), np.max(y_indices)
            
            # Convert to YOLO format
            yolo_box = self._normalize_box([x1, y1, x2, y2], image_width, image_height)
            
            # Create annotation
            annotation = {
                "class_idx": yolo_class_idx,
                "box": yolo_box,
                "filename": image_info["filename"]
            }
            
            annotations.append(annotation)
        
        return annotations
    
    def format_instance_segmentation(self, predictions, image_info):
        """
        Format instance segmentation predictions to YOLO format.
        For instance segmentation, we use the bounding boxes.
        
        Args:
            predictions: Instance segmentation predictions
            image_info: Image metadata
            
        Returns:
            List of YOLO annotations
        """
        boxes = predictions['boxes']
        labels = predictions['labels']
        class_names = predictions['class_names']
        
        image_width = image_info["width"]
        image_height = image_info["height"]
        
        annotations = []
        
        # Process each instance
        for i in range(len(boxes)):
            # Ensure class has an index
            yolo_class_idx = self._ensure_class_index(class_names[i])
            
            # Convert to YOLO format
            yolo_box = self._normalize_box(boxes[i], image_width, image_height)
            
            # Create annotation
            annotation = {
                "class_idx": yolo_class_idx,
                "box": yolo_box,
                "filename": image_info["filename"]
            }
            
            annotations.append(annotation)
        
        return annotations
    
    def format_bounding_box(self, predictions, image_info):
        """
        Format bounding box predictions to YOLO format.
        
        Args:
            predictions: Bounding box predictions
            image_info: Image metadata
            
        Returns:
            List of YOLO annotations
        """
        boxes = predictions['boxes']
        class_names = predictions['class_names']
        
        image_width = image_info["width"]
        image_height = image_info["height"]
        
        annotations = []
        
        # Process each bounding box
        for i in range(len(boxes)):
            # Ensure class has an index
            yolo_class_idx = self._ensure_class_index(class_names[i])
            
            # Convert to YOLO format
            yolo_box = self._normalize_box(boxes[i], image_width, image_height)
            
            # Create annotation
            annotation = {
                "class_idx": yolo_class_idx,
                "box": yolo_box,
                "filename": image_info["filename"]
            }
            
            annotations.append(annotation)
        
        return annotations
    
    def format(self, predictions, image_info):
        """
        Convert model predictions to YOLO format.
        
        Args:
            predictions: Model prediction results
            image_info: Dictionary containing image metadata
                        (filename, width, height, etc.)
            
        Returns:
            Formatted annotations in YOLO format
        """
        prediction_type = predictions.get('type', '')
        
        if prediction_type == 'semantic_segmentation':
            return self.format_semantic_segmentation(predictions, image_info)
        elif prediction_type == 'instance_segmentation':
            return self.format_instance_segmentation(predictions, image_info)
        elif prediction_type == 'bounding_box':
            return self.format_bounding_box(predictions, image_info)
        else:
            raise ValueError(f"Unsupported prediction type: {prediction_type}")
    
    def save(self, annotations, output_dir):
        """
        Save the YOLO annotations to the specified output directory.
        
        Args:
            annotations: Formatted annotations
            output_dir: Directory to save the annotations
            
        Returns:
            Path to the saved annotations directory
        """
        # Create labels directory
        labels_dir = os.path.join(output_dir, 'labels')
        os.makedirs(labels_dir, exist_ok=True)
        
        # Group annotations by filename
        annotations_by_file = {}
        for annotation in annotations:
            filename = annotation["filename"]
            if filename not in annotations_by_file:
                annotations_by_file[filename] = []
            annotations_by_file[filename].append(annotation)
        
        # Save annotations for each file
        for filename, file_annotations in annotations_by_file.items():
            # Get base filename without extension
            base_filename = os.path.splitext(os.path.basename(filename))[0]
            output_file = os.path.join(labels_dir, f"{base_filename}.txt")
            
            with open(output_file, 'w') as f:
                for annotation in file_annotations:
                    class_idx = annotation["class_idx"]
                    box = annotation["box"]
                    # YOLO format: <class_idx> <center_x> <center_y> <width> <height>
                    line = f"{class_idx} {box[0]:.6f} {box[1]:.6f} {box[2]:.6f} {box[3]:.6f}\n"
                    f.write(line)
        
        # Save class names to classes.txt
        classes_file = os.path.join(output_dir, 'classes.txt')
        with open(classes_file, 'w') as f:
            for class_name, class_idx in sorted(self.class_map.items(), key=lambda x: x[1]):
                f.write(f"{class_name}\n")
        
        return labels_dir
