from src.formatters.base import BaseFormatter
from src.formatters.coco import COCOFormatter
from src.formatters.yolo import YOLOFormatter

# Factory function to create the appropriate formatter
def create_formatter(format_type):
    """
    Create a formatter based on the specified format type.
    
    Args:
        format_type: Type of format ('coco' or 'yolo')
        
    Returns:
        An instance of the appropriate formatter
    """
    if format_type == 'coco':
        return COCOFormatter()
    elif format_type == 'yolo':
        return YOLOFormatter()
    else:
        raise ValueError(f"Unsupported format type: {format_type}")
