from abc import ABC, abstractmethod
import json
import os
import numpy as np

class BaseFormatter(ABC):
    """
    Base abstract class for all annotation formatters.
    Defines the common interface that all formatters must implement.
    """
    
    def __init__(self):
        """
        Initialize the formatter.
        """
        pass
    
    @abstractmethod
    def format(self, predictions, image_info):
        """
        Convert model predictions to the target annotation format.
        
        Args:
            predictions: Model prediction results
            image_info: Dictionary containing image metadata
                        (filename, width, height, etc.)
            
        Returns:
            Formatted annotations in the target format
        """
        pass
    
    @abstractmethod
    def save(self, annotations, output_dir):
        """
        Save the formatted annotations to the specified output directory.
        
        Args:
            annotations: Formatted annotations
            output_dir: Directory to save the annotations
            
        Returns:
            Path to the saved annotations
        """
        pass
