from flask import Flask
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))  # DON'T CHANGE THIS !!!

from src.routes.main import main_bp
from src.routes.edit import edit_bp

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max upload size

# Register blueprints
app.register_blueprint(main_bp)
app.register_blueprint(edit_bp)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
