"""
Module for REST API endpoints for programmatic access to the labeling system.
"""

from flask import Blueprint, request, jsonify, url_for
import os
import base64
import io
from PIL import Image
import uuid
import json

from src.inference import create_inference_model
from src.formatters import create_formatter
from src.utils.file import create_temp_dir, create_dataset_structure, create_zip_archive, cleanup_temp_dir
from src.utils.image import get_image_info
from src.inference.filtering import filter_predictions_by_classes
from src.inference.thresholds import apply_thresholds
from src.inference.processing import PreProcessingPipeline, PostProcessingPipeline

api_bp = Blueprint('api', __name__)

# Global variables to store API session data
API_TEMP_DIRS = {}
API_SESSION_DATA = {}

@api_bp.route('/label', methods=['POST'])
def label_image():
    """
    API endpoint for labeling images.
    
    Accepts:
    - image: File upload or base64 encoded image
    - label_type: Type of labeling (semantic, instance, bbox)
    - output_format: Format of output (coco, yolo)
    - selected_classes: List of class IDs to include (optional)
    - global_threshold: Global confidence threshold (optional)
    - class_thresholds: Dictionary of class-specific thresholds (optional)
    - preprocessing_options: Dictionary of preprocessing options (optional)
    - postprocessing_options: Dictionary of postprocessing options (optional)
    
    Returns:
    - JSON with labeling results
    """
    # Create a new session
    session_id = str(uuid.uuid4())
    temp_dir = create_temp_dir()
    API_TEMP_DIRS[session_id] = temp_dir
    
    try:
        # Parse request data
        label_type = request.form.get('label_type', 'instance')
        output_format = request.form.get('output_format', 'coco')
        
        # Parse JSON parameters
        selected_classes = json.loads(request.form.get('selected_classes', '[]'))
        global_threshold = float(request.form.get('global_threshold', '0.5'))
        class_thresholds = json.loads(request.form.get('class_thresholds', '{}'))
        preprocessing_options = json.loads(request.form.get('preprocessing_options', '{}'))
        postprocessing_options = json.loads(request.form.get('postprocessing_options', '{}'))
        
        # Create dataset structure
        dataset_dirs = create_dataset_structure(temp_dir)
        
        # Process image
        if 'image' in request.files:
            # Handle file upload
            image_file = request.files['image']
            if not image_file:
                return jsonify({'error': 'No image provided'}), 400
            
            # Save uploaded image
            filename = f"image_{session_id}.jpg"
            file_path = os.path.join(dataset_dirs['images_dir'], filename)
            image_file.save(file_path)
            
            # Open image
            image = Image.open(file_path)
        
        elif 'image_base64' in request.form:
            # Handle base64 encoded image
            image_data = request.form.get('image_base64')
            if not image_data:
                return jsonify({'error': 'No image provided'}), 400
            
            # Decode base64 image
            try:
                image_data = image_data.split(',')[1] if ',' in image_data else image_data
                image_bytes = base64.b64decode(image_data)
                image = Image.open(io.BytesIO(image_bytes))
                
                # Save image
                filename = f"image_{session_id}.jpg"
                file_path = os.path.join(dataset_dirs['images_dir'], filename)
                image.save(file_path)
            except Exception as e:
                return jsonify({'error': f'Invalid base64 image: {str(e)}'}), 400
        
        else:
            return jsonify({'error': 'No image provided'}), 400
        
        # Apply preprocessing
        preprocessor = PreProcessingPipeline(preprocessing_options)
        processed_image = preprocessor.process(image)
        
        # Create inference model
        model = create_inference_model(label_type)
        
        # Run inference
        predictions = model(processed_image)
        
        # Apply postprocessing
        postprocessor = PostProcessingPipeline(postprocessing_options)
        processed_predictions = postprocessor.process(predictions)
        
        # Apply class filtering
        if selected_classes:
            filtered_predictions = filter_predictions_by_classes(processed_predictions, selected_classes)
        else:
            filtered_predictions = processed_predictions
        
        # Apply confidence thresholds
        thresholded_predictions = apply_thresholds(filtered_predictions, global_threshold, class_thresholds)
        
        # Format annotations
        image_info = get_image_info(file_path)
        formatter = create_formatter(output_format)
        annotations = formatter.format(thresholded_predictions, image_info)
        
        # Save annotations
        annotation_path = formatter.save(annotations, dataset_dirs['annotations_dir'])
        
        # Create ZIP archive
        zip_path = create_zip_archive(temp_dir)
        
        # Prepare response
        response = {
            'success': True,
            'session_id': session_id,
            'annotations': annotations,
            'download_url': url_for('api.download_dataset', session_id=session_id, _external=True)
        }
        
        # Store session data for download
        API_SESSION_DATA[session_id] = {
            'label_type': label_type,
            'output_format': output_format,
            'annotations': annotations
        }
        
        return jsonify(response)
    
    except Exception as e:
        # Clean up on error
        cleanup_temp_dir(temp_dir)
        if session_id in API_TEMP_DIRS:
            del API_TEMP_DIRS[session_id]
        if session_id in API_SESSION_DATA:
            del API_SESSION_DATA[session_id]
        
        return jsonify({'error': str(e)}), 500

@api_bp.route('/download/<session_id>', methods=['GET'])
def download_dataset(session_id):
    """Download the labeled dataset as a ZIP file."""
    if session_id not in API_TEMP_DIRS:
        return jsonify({'error': 'Invalid session ID'}), 400
    
    temp_dir = API_TEMP_DIRS[session_id]
    
    # Create ZIP archive if it doesn't exist
    zip_path = f"{temp_dir}.zip"
    if not os.path.exists(zip_path):
        zip_path = create_zip_archive(temp_dir, zip_path)
    
    from flask import send_file
    return send_file(zip_path, as_attachment=True, download_name='labeled_dataset.zip')

@api_bp.route('/cleanup/<session_id>', methods=['POST'])
def cleanup_session(session_id):
    """Clean up temporary files for a session."""
    if session_id in API_TEMP_DIRS:
        temp_dir = API_TEMP_DIRS[session_id]
        cleanup_temp_dir(temp_dir)
        
        # Remove ZIP file if it exists
        zip_path = f"{temp_dir}.zip"
        if os.path.exists(zip_path):
            os.remove(zip_path)
        
        del API_TEMP_DIRS[session_id]
        
        # Clean up session data
        if session_id in API_SESSION_DATA:
            del API_SESSION_DATA[session_id]
        
        return jsonify({'success': True})
    
    return jsonify({'error': 'Invalid session ID'}), 400
